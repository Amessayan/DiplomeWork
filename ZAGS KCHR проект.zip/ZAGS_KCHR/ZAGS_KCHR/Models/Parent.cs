using System;

namespace ZAGS_KCHR.Models
{
    /// <summary>
    /// Модель родителя. Соответствует таблице dbo.Parents.
    /// </summary>
    public class Parent
    {
        public int ParentID { get; set; }
        public string FullName { get; set; }

        /// <summary>Девичья фамилия (актуально для матери).</summary>
        public string MaidenName { get; set; }

        public DateTime? BirthDate { get; set; }
        public string Passport { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Citizenship { get; set; }

        /// <summary>Текстовое представление для выпадающих списков.</summary>
        public override string ToString() => FullName;
    }
}
