using System;

namespace ZAGS_KCHR.Models
{
    /// <summary>
    /// Модель свидетельства о рождении. Таблица dbo.Certificates.
    /// </summary>
    public class Certificate
    {
        public int CertificateID { get; set; }
        public string Series { get; set; }
        public string Number { get; set; }
        public DateTime IssueDate { get; set; }
        public string IssuedBy { get; set; }

        /// <summary>Полный номер свидетельства вида "I-МЮ №123456".</summary>
        public string FullNumber => $"{Series} №{Number}";
    }
}
