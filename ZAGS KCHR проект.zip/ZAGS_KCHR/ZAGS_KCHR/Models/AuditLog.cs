using System;

namespace ZAGS_KCHR.Models
{
    /// <summary>
    /// Запись журнала аудита. Таблица dbo.AuditLogs.
    /// </summary>
    public class AuditLog
    {
        public int LogID { get; set; }
        public int? EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Action { get; set; }
        public DateTime ActionDate { get; set; }
    }
}
