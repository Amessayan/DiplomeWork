using System;

namespace ZAGS_KCHR.Models
{
    /// <summary>
    /// Модель записи о рождении. Соответствует таблице dbo.BirthRecords.
    /// Дополнительно содержит "присоединённые" поля (имена родителей,
    /// данные свидетельства), которые приходят из JOIN-запросов.
    /// </summary>
    public class BirthRecord
    {
        // --- Основные поля таблицы ---
        public int BirthID { get; set; }
        public string ChildLastName { get; set; }
        public string ChildFirstName { get; set; }
        public string ChildMiddleName { get; set; }
        public DateTime BirthDate { get; set; }
        public TimeSpan? BirthTime { get; set; }
        public string BirthPlace { get; set; }
        public string Gender { get; set; }
        public decimal? Weight { get; set; }
        public decimal? Height { get; set; }
        public int? MotherID { get; set; }
        public int? FatherID { get; set; }
        public int? CertificateID { get; set; }
        public int? EmployeeID { get; set; }
        public DateTime RegistrationDate { get; set; }

        // --- Присоединённые поля (read-only, из JOIN) ---
        public string MotherName { get; set; }
        public string FatherName { get; set; }
        public string CertSeries { get; set; }
        public string CertNumber { get; set; }
        public DateTime? CertIssueDate { get; set; }
        public string CertIssuedBy { get; set; }

        // --- Вычисляемые свойства для отображения в DataGridView ---

        /// <summary>ФИО ребёнка одной строкой.</summary>
        public string ChildFullName =>
            $"{ChildLastName} {ChildFirstName} {ChildMiddleName}".Trim();

        /// <summary>Дата и время рождения для таблицы.</summary>
        public string BirthDateTimeText =>
            BirthDate.ToString("dd.MM.yyyy") +
            (BirthTime.HasValue ? "  " + BirthTime.Value.ToString(@"hh\:mm") : "");

        /// <summary>Полный номер свидетельства вида "I-МЮ №123456".</summary>
        public string CertificateFullNumber =>
            string.IsNullOrEmpty(CertNumber) ? "" : $"{CertSeries} №{CertNumber}";
    }
}
