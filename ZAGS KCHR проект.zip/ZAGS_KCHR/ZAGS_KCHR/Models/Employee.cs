using System;

namespace ZAGS_KCHR.Models
{
    /// <summary>
    /// Модель сотрудника (пользователя системы).
    /// Соответствует таблице dbo.Employees.
    /// </summary>
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string FullName { get; set; }
        public string Login { get; set; }
        public string PasswordHash { get; set; }

        /// <summary>Роль: "Администратор" или "Сотрудник".</summary>
        public string Role { get; set; }

        public string Position { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }

        /// <summary>Является ли пользователь администратором (для проверки прав).</summary>
        public bool IsAdmin => string.Equals(Role, "Администратор", StringComparison.OrdinalIgnoreCase);
    }
}
