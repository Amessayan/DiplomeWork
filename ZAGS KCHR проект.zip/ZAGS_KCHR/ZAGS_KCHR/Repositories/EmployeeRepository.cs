using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Repositories
{
    /// <summary>
    /// Репозиторий для работы с сотрудниками (паттерн Repository).
    /// Содержит методы авторизации и CRUD-операции над таблицей Employees.
    /// </summary>
    public class EmployeeRepository
    {
        /// <summary>
        /// Проверяет логин/пароль. Возвращает Employee при успехе, иначе null.
        /// </summary>
        public async Task<Employee> AuthenticateAsync(string login, string password)
        {
            const string sql = @"SELECT EmployeeID, FullName, Login, PasswordHash, Role,
                                        Position, IsActive, CreatedAt
                                 FROM dbo.Employees
                                 WHERE Login = @login AND IsActive = 1";

            var table = await DatabaseHelper.ExecuteQueryAsync(
                sql, CommandType.Text, new SqlParameter("@login", login));

            if (table.Rows.Count == 0) return null;

            var emp = MapRow(table.Rows[0]);
            // Сравниваем хэш введённого пароля с сохранённым
            return PasswordHasher.Verify(password, emp.PasswordHash) ? emp : null;
        }

        /// <summary>Возвращает всех сотрудников.</summary>
        public async Task<List<Employee>> GetAllAsync()
        {
            const string sql = @"SELECT EmployeeID, FullName, Login, PasswordHash, Role,
                                        Position, IsActive, CreatedAt
                                 FROM dbo.Employees ORDER BY FullName";
            var table = await DatabaseHelper.ExecuteQueryAsync(sql);
            var list = new List<Employee>();
            foreach (DataRow row in table.Rows) list.Add(MapRow(row));
            return list;
        }

        /// <summary>Добавляет нового сотрудника. Пароль хэшируется автоматически.</summary>
        public async Task<int> AddAsync(Employee emp, string plainPassword)
        {
            const string sql = @"INSERT INTO dbo.Employees (FullName, Login, PasswordHash, Role, Position, IsActive)
                                 OUTPUT INSERTED.EmployeeID
                                 VALUES (@name, @login, @hash, @role, @pos, @active)";
            var result = await DatabaseHelper.ExecuteScalarAsync(sql, CommandType.Text,
                new SqlParameter("@name", emp.FullName),
                new SqlParameter("@login", emp.Login),
                new SqlParameter("@hash", PasswordHasher.Hash(plainPassword)),
                new SqlParameter("@role", emp.Role),
                new SqlParameter("@pos", (object)emp.Position ?? DBNull.Value),
                new SqlParameter("@active", emp.IsActive));
            return Convert.ToInt32(result);
        }

        /// <summary>Обновляет данные сотрудника. Если plainPassword пуст — пароль не меняется.</summary>
        public async Task UpdateAsync(Employee emp, string plainPassword = null)
        {
            string sql;
            var pars = new List<SqlParameter>
            {
                new SqlParameter("@id", emp.EmployeeID),
                new SqlParameter("@name", emp.FullName),
                new SqlParameter("@login", emp.Login),
                new SqlParameter("@role", emp.Role),
                new SqlParameter("@pos", (object)emp.Position ?? DBNull.Value),
                new SqlParameter("@active", emp.IsActive)
            };

            if (string.IsNullOrEmpty(plainPassword))
            {
                sql = @"UPDATE dbo.Employees SET FullName=@name, Login=@login, Role=@role,
                               Position=@pos, IsActive=@active WHERE EmployeeID=@id";
            }
            else
            {
                sql = @"UPDATE dbo.Employees SET FullName=@name, Login=@login, Role=@role,
                               Position=@pos, IsActive=@active, PasswordHash=@hash WHERE EmployeeID=@id";
                pars.Add(new SqlParameter("@hash", PasswordHasher.Hash(plainPassword)));
            }

            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text, pars.ToArray());
        }

        /// <summary>Удаляет сотрудника по ID.</summary>
        public async Task DeleteAsync(int employeeId)
        {
            const string sql = "DELETE FROM dbo.Employees WHERE EmployeeID=@id";
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text,
                new SqlParameter("@id", employeeId));
        }

        /// <summary>Преобразует строку DataRow в объект Employee.</summary>
        private Employee MapRow(DataRow row) => new Employee
        {
            EmployeeID   = Convert.ToInt32(row["EmployeeID"]),
            FullName     = row["FullName"].ToString(),
            Login        = row["Login"].ToString(),
            PasswordHash = row["PasswordHash"].ToString(),
            Role         = row["Role"].ToString(),
            Position     = row["Position"] == DBNull.Value ? null : row["Position"].ToString(),
            IsActive     = Convert.ToBoolean(row["IsActive"]),
            CreatedAt    = Convert.ToDateTime(row["CreatedAt"])
        };
    }
}
