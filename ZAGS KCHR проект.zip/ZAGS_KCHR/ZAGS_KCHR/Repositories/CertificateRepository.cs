using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Repositories
{
    /// <summary>
    /// Репозиторий для работы со свидетельствами (таблица Certificates).
    /// </summary>
    public class CertificateRepository
    {
        /// <summary>Возвращает все свидетельства.</summary>
        public async Task<List<Certificate>> GetAllAsync()
        {
            const string sql = @"SELECT CertificateID, Series, Number, IssueDate, IssuedBy
                                 FROM dbo.Certificates ORDER BY CertificateID DESC";
            var table = await DatabaseHelper.ExecuteQueryAsync(sql);
            var list = new List<Certificate>();
            foreach (DataRow row in table.Rows) list.Add(MapRow(row));
            return list;
        }

        /// <summary>Добавляет свидетельство, возвращает новый ID.</summary>
        public async Task<int> AddAsync(Certificate c)
        {
            const string sql = @"INSERT INTO dbo.Certificates (Series, Number, IssueDate, IssuedBy)
                                 OUTPUT INSERTED.CertificateID
                                 VALUES (@series, @num, @date, @by)";
            var result = await DatabaseHelper.ExecuteScalarAsync(sql, CommandType.Text,
                new SqlParameter("@series", c.Series),
                new SqlParameter("@num", c.Number),
                new SqlParameter("@date", c.IssueDate),
                new SqlParameter("@by", c.IssuedBy));
            return Convert.ToInt32(result);
        }

        /// <summary>Удаляет свидетельство по ID.</summary>
        public async Task DeleteAsync(int id)
        {
            const string sql = "DELETE FROM dbo.Certificates WHERE CertificateID=@id";
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text,
                new SqlParameter("@id", id));
        }

        /// <summary>
        /// Генерирует следующий уникальный номер свидетельства.
        /// Берёт максимальный существующий номер и увеличивает на 1.
        /// </summary>
        public async Task<string> GenerateNextNumberAsync()
        {
            const string sql = @"SELECT ISNULL(MAX(CAST(Number AS INT)), 123455) + 1
                                 FROM dbo.Certificates
                                 WHERE ISNUMERIC(Number) = 1";
            var result = await DatabaseHelper.ExecuteScalarAsync(sql);
            return result.ToString();
        }

        private Certificate MapRow(DataRow row) => new Certificate
        {
            CertificateID = Convert.ToInt32(row["CertificateID"]),
            Series        = row["Series"].ToString(),
            Number        = row["Number"].ToString(),
            IssueDate     = Convert.ToDateTime(row["IssueDate"]),
            IssuedBy      = row["IssuedBy"].ToString()
        };
    }
}
