using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Repositories
{
    /// <summary>
    /// Репозиторий для построения отчётов (через хранимые процедуры).
    /// Возвращает готовые DataTable для отображения и построения диаграмм.
    /// </summary>
    public class ReportRepository
    {
        /// <summary>Количество рождений по месяцам.</summary>
        public Task<DataTable> BirthsByMonthAsync() =>
            DatabaseHelper.ExecuteQueryAsync("dbo.sp_ReportBirthsByMonth", CommandType.StoredProcedure);

        /// <summary>Распределение по полу.</summary>
        public Task<DataTable> ByGenderAsync() =>
            DatabaseHelper.ExecuteQueryAsync("dbo.sp_ReportByGender", CommandType.StoredProcedure);

        /// <summary>Статистика по сотрудникам.</summary>
        public Task<DataTable> ByEmployeeAsync() =>
            DatabaseHelper.ExecuteQueryAsync("dbo.sp_ReportByEmployee", CommandType.StoredProcedure);

        /// <summary>Статистика по местам/городам рождения.</summary>
        public Task<DataTable> ByPlaceAsync() =>
            DatabaseHelper.ExecuteQueryAsync("dbo.sp_ReportByPlace", CommandType.StoredProcedure);

        /// <summary>Сводные показатели для дашборда.</summary>
        public async Task<(int total, int male, int female, int thisMonth)> GetDashboardStatsAsync()
        {
            const string sql = @"
                SELECT
                  (SELECT COUNT(*) FROM dbo.BirthRecords) AS Total,
                  (SELECT COUNT(*) FROM dbo.BirthRecords WHERE Gender = N'Мужской') AS Male,
                  (SELECT COUNT(*) FROM dbo.BirthRecords WHERE Gender = N'Женский') AS Female,
                  (SELECT COUNT(*) FROM dbo.BirthRecords
                     WHERE YEAR(BirthDate)=YEAR(GETDATE()) AND MONTH(BirthDate)=MONTH(GETDATE())) AS ThisMonth";
            var table = await DatabaseHelper.ExecuteQueryAsync(sql);
            var r = table.Rows[0];
            return (Convert.ToInt32(r["Total"]), Convert.ToInt32(r["Male"]),
                    Convert.ToInt32(r["Female"]), Convert.ToInt32(r["ThisMonth"]));
        }
    }

    /// <summary>
    /// Репозиторий журнала аудита (таблица AuditLogs).
    /// </summary>
    public class AuditRepository
    {
        /// <summary>Записывает действие в журнал аудита.</summary>
        public async Task LogAsync(int? employeeId, string action)
        {
            const string sql = "INSERT INTO dbo.AuditLogs (EmployeeID, Action) VALUES (@eid, @act)";
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text,
                new SqlParameter("@eid", (object)employeeId ?? DBNull.Value),
                new SqlParameter("@act", action));
        }

        /// <summary>Возвращает последние N записей журнала.</summary>
        public async Task<List<AuditLog>> GetRecentAsync(int top = 200)
        {
            string sql = $@"SELECT TOP {top} a.LogID, a.EmployeeID, e.FullName AS EmployeeName,
                                  a.Action, a.ActionDate
                           FROM dbo.AuditLogs a
                           LEFT JOIN dbo.Employees e ON a.EmployeeID = e.EmployeeID
                           ORDER BY a.ActionDate DESC";
            var table = await DatabaseHelper.ExecuteQueryAsync(sql);
            var list = new List<AuditLog>();
            foreach (DataRow row in table.Rows)
            {
                list.Add(new AuditLog
                {
                    LogID        = Convert.ToInt32(row["LogID"]),
                    EmployeeID   = row["EmployeeID"] == DBNull.Value ? (int?)null : Convert.ToInt32(row["EmployeeID"]),
                    EmployeeName = row["EmployeeName"] == DBNull.Value ? "(система)" : row["EmployeeName"].ToString(),
                    Action       = row["Action"].ToString(),
                    ActionDate   = Convert.ToDateTime(row["ActionDate"])
                });
            }
            return list;
        }
    }
}
