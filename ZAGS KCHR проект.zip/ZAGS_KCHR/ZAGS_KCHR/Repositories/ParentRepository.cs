using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Repositories
{
    /// <summary>
    /// Репозиторий для работы с родителями (таблица Parents).
    /// </summary>
    public class ParentRepository
    {
        /// <summary>Возвращает всех родителей (с необязательным поиском по ФИО).</summary>
        public async Task<List<Parent>> GetAllAsync(string search = null)
        {
            const string sql = @"SELECT ParentID, FullName, MaidenName, BirthDate,
                                        Passport, Address, Phone, Citizenship
                                 FROM dbo.Parents
                                 WHERE (@s IS NULL OR FullName LIKE '%' + @s + '%')
                                 ORDER BY FullName";
            var table = await DatabaseHelper.ExecuteQueryAsync(sql, CommandType.Text,
                new SqlParameter("@s", (object)search ?? DBNull.Value));

            var list = new List<Parent>();
            foreach (DataRow row in table.Rows) list.Add(MapRow(row));
            return list;
        }

        /// <summary>Добавляет родителя, возвращает новый ID.</summary>
        public async Task<int> AddAsync(Parent p)
        {
            const string sql = @"INSERT INTO dbo.Parents
                                   (FullName, MaidenName, BirthDate, Passport, Address, Phone, Citizenship)
                                 OUTPUT INSERTED.ParentID
                                 VALUES (@name, @maiden, @bd, @pass, @addr, @phone, @cit)";
            var result = await DatabaseHelper.ExecuteScalarAsync(sql, CommandType.Text, BuildParams(p));
            return Convert.ToInt32(result);
        }

        /// <summary>Обновляет данные родителя.</summary>
        public async Task UpdateAsync(Parent p)
        {
            const string sql = @"UPDATE dbo.Parents SET
                                   FullName=@name, MaidenName=@maiden, BirthDate=@bd,
                                   Passport=@pass, Address=@addr, Phone=@phone, Citizenship=@cit
                                 WHERE ParentID=@id";
            var pars = new List<SqlParameter>(BuildParams(p)) { new SqlParameter("@id", p.ParentID) };
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text, pars.ToArray());
        }

        /// <summary>Удаляет родителя по ID.</summary>
        public async Task DeleteAsync(int parentId)
        {
            const string sql = "DELETE FROM dbo.Parents WHERE ParentID=@id";
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text,
                new SqlParameter("@id", parentId));
        }

        private SqlParameter[] BuildParams(Parent p) => new[]
        {
            new SqlParameter("@name",   p.FullName),
            new SqlParameter("@maiden", (object)p.MaidenName ?? DBNull.Value),
            new SqlParameter("@bd",     (object)p.BirthDate ?? DBNull.Value),
            new SqlParameter("@pass",   (object)p.Passport ?? DBNull.Value),
            new SqlParameter("@addr",   (object)p.Address ?? DBNull.Value),
            new SqlParameter("@phone",  (object)p.Phone ?? DBNull.Value),
            new SqlParameter("@cit",    (object)p.Citizenship ?? DBNull.Value)
        };

        private Parent MapRow(DataRow row) => new Parent
        {
            ParentID    = Convert.ToInt32(row["ParentID"]),
            FullName    = row["FullName"].ToString(),
            MaidenName  = row["MaidenName"] == DBNull.Value ? null : row["MaidenName"].ToString(),
            BirthDate   = row["BirthDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["BirthDate"]),
            Passport    = row["Passport"] == DBNull.Value ? null : row["Passport"].ToString(),
            Address     = row["Address"] == DBNull.Value ? null : row["Address"].ToString(),
            Phone       = row["Phone"] == DBNull.Value ? null : row["Phone"].ToString(),
            Citizenship = row["Citizenship"] == DBNull.Value ? null : row["Citizenship"].ToString()
        };
    }
}
