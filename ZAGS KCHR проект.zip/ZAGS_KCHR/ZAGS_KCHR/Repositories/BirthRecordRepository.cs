using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Repositories
{
    /// <summary>
    /// Репозиторий для записей о рождении (таблица BirthRecords).
    /// Поиск выполняется через хранимую процедуру sp_SearchBirths.
    /// </summary>
    public class BirthRecordRepository
    {
        /// <summary>
        /// Поиск и фильтрация записей. Все параметры необязательны (null = без фильтра).
        /// </summary>
        public async Task<List<BirthRecord>> SearchAsync(
            string search = null, DateTime? from = null, DateTime? to = null, string gender = null)
        {
            var pars = new[]
            {
                new SqlParameter("@Search",   (object)search ?? DBNull.Value),
                new SqlParameter("@DateFrom", (object)from ?? DBNull.Value),
                new SqlParameter("@DateTo",   (object)to ?? DBNull.Value),
                new SqlParameter("@Gender",   (object)gender ?? DBNull.Value)
            };

            var table = await DatabaseHelper.ExecuteQueryAsync(
                "dbo.sp_SearchBirths", CommandType.StoredProcedure, pars);

            var list = new List<BirthRecord>();
            foreach (DataRow row in table.Rows) list.Add(MapRow(row));
            return list;
        }

        /// <summary>Добавляет запись о рождении, возвращает новый ID.</summary>
        public async Task<int> AddAsync(BirthRecord b)
        {
            const string sql = @"INSERT INTO dbo.BirthRecords
                  (ChildLastName, ChildFirstName, ChildMiddleName, BirthDate, BirthTime,
                   BirthPlace, Gender, Weight, Height, MotherID, FatherID, CertificateID, EmployeeID)
                  OUTPUT INSERTED.BirthID
                  VALUES (@ln, @fn, @mn, @bd, @bt, @place, @gender, @w, @h, @mid, @fid, @cid, @eid)";
            var result = await DatabaseHelper.ExecuteScalarAsync(sql, CommandType.Text, BuildParams(b));
            return Convert.ToInt32(result);
        }

        /// <summary>Обновляет запись о рождении.</summary>
        public async Task UpdateAsync(BirthRecord b)
        {
            const string sql = @"UPDATE dbo.BirthRecords SET
                   ChildLastName=@ln, ChildFirstName=@fn, ChildMiddleName=@mn,
                   BirthDate=@bd, BirthTime=@bt, BirthPlace=@place, Gender=@gender,
                   Weight=@w, Height=@h, MotherID=@mid, FatherID=@fid,
                   CertificateID=@cid, EmployeeID=@eid
                 WHERE BirthID=@id";
            var pars = new List<SqlParameter>(BuildParams(b)) { new SqlParameter("@id", b.BirthID) };
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text, pars.ToArray());
        }

        /// <summary>Удаляет запись о рождении по ID.</summary>
        public async Task DeleteAsync(int birthId)
        {
            const string sql = "DELETE FROM dbo.BirthRecords WHERE BirthID=@id";
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text,
                new SqlParameter("@id", birthId));
        }

        /// <summary>Привязывает свидетельство к записи о рождении.</summary>
        public async Task AttachCertificateAsync(int birthId, int certificateId)
        {
            const string sql = "UPDATE dbo.BirthRecords SET CertificateID=@cid WHERE BirthID=@id";
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text,
                new SqlParameter("@cid", certificateId),
                new SqlParameter("@id", birthId));
        }

        private SqlParameter[] BuildParams(BirthRecord b) => new[]
        {
            new SqlParameter("@ln",     b.ChildLastName),
            new SqlParameter("@fn",     b.ChildFirstName),
            new SqlParameter("@mn",     (object)b.ChildMiddleName ?? DBNull.Value),
            new SqlParameter("@bd",     b.BirthDate),
            new SqlParameter("@bt",     (object)b.BirthTime ?? DBNull.Value),
            new SqlParameter("@place",  (object)b.BirthPlace ?? DBNull.Value),
            new SqlParameter("@gender", b.Gender),
            new SqlParameter("@w",      (object)b.Weight ?? DBNull.Value),
            new SqlParameter("@h",      (object)b.Height ?? DBNull.Value),
            new SqlParameter("@mid",    (object)b.MotherID ?? DBNull.Value),
            new SqlParameter("@fid",    (object)b.FatherID ?? DBNull.Value),
            new SqlParameter("@cid",    (object)b.CertificateID ?? DBNull.Value),
            new SqlParameter("@eid",    (object)b.EmployeeID ?? DBNull.Value)
        };

        private BirthRecord MapRow(DataRow row) => new BirthRecord
        {
            BirthID          = Convert.ToInt32(row["BirthID"]),
            ChildLastName    = row["ChildLastName"].ToString(),
            ChildFirstName   = row["ChildFirstName"].ToString(),
            ChildMiddleName  = row["ChildMiddleName"] == DBNull.Value ? null : row["ChildMiddleName"].ToString(),
            BirthDate        = Convert.ToDateTime(row["BirthDate"]),
            BirthTime        = row["BirthTime"] == DBNull.Value ? (TimeSpan?)null : (TimeSpan)row["BirthTime"],
            BirthPlace       = row["BirthPlace"] == DBNull.Value ? null : row["BirthPlace"].ToString(),
            Gender           = row["Gender"].ToString(),
            Weight           = row["Weight"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(row["Weight"]),
            Height           = row["Height"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(row["Height"]),
            MotherID         = row["MotherID"] == DBNull.Value ? (int?)null : Convert.ToInt32(row["MotherID"]),
            FatherID         = row["FatherID"] == DBNull.Value ? (int?)null : Convert.ToInt32(row["FatherID"]),
            CertificateID    = row["CertificateID"] == DBNull.Value ? (int?)null : Convert.ToInt32(row["CertificateID"]),
            EmployeeID       = row["EmployeeID"] == DBNull.Value ? (int?)null : Convert.ToInt32(row["EmployeeID"]),
            RegistrationDate = Convert.ToDateTime(row["RegistrationDate"]),
            MotherName       = row.Table.Columns.Contains("MotherName") && row["MotherName"] != DBNull.Value ? row["MotherName"].ToString() : null,
            FatherName       = row.Table.Columns.Contains("FatherName") && row["FatherName"] != DBNull.Value ? row["FatherName"].ToString() : null,
            CertSeries       = row.Table.Columns.Contains("Series") && row["Series"] != DBNull.Value ? row["Series"].ToString() : null,
            CertNumber       = row.Table.Columns.Contains("Number") && row["Number"] != DBNull.Value ? row["Number"].ToString() : null,
            CertIssueDate    = row.Table.Columns.Contains("IssueDate") && row["IssueDate"] != DBNull.Value ? Convert.ToDateTime(row["IssueDate"]) : (DateTime?)null,
            CertIssuedBy     = row.Table.Columns.Contains("IssuedBy") && row["IssuedBy"] != DBNull.Value ? row["IssuedBy"].ToString() : null
        };
    }
}
