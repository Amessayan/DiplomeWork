using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace ZAGS_KCHR.Utils
{
    /// <summary>
    /// Базовый класс слоя доступа к данным (Data Access Layer).
    /// Инкапсулирует работу с подключением к SQL Server и выполнение
    /// команд через ADO.NET. Строка подключения берётся из App.config.
    /// </summary>
    public static class DatabaseHelper
    {
        /// <summary>
        /// Строка подключения, читаемая из секции connectionStrings в App.config.
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                var cs = ConfigurationManager.ConnectionStrings["ZAGSConnection"];
                if (cs == null)
                    throw new ConfigurationErrorsException(
                        "В App.config не найдена строка подключения 'ZAGSConnection'.");
                return cs.ConnectionString;
            }
        }

        /// <summary>Создаёт новое открытое подключение к БД.</summary>
        public static SqlConnection CreateConnection()
        {
            var connection = new SqlConnection(ConnectionString);
            connection.Open();
            return connection;
        }

        /// <summary>Создаёт новое открытое подключение асинхронно.</summary>
        public static async Task<SqlConnection> CreateConnectionAsync()
        {
            var connection = new SqlConnection(ConnectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            return connection;
        }

        /// <summary>
        /// Выполняет запрос и возвращает результат в виде DataTable (асинхронно).
        /// </summary>
        public static async Task<DataTable> ExecuteQueryAsync(
            string sql, CommandType type = CommandType.Text, params SqlParameter[] parameters)
        {
            var table = new DataTable();
            using (var conn = await CreateConnectionAsync().ConfigureAwait(false))
            using (var cmd = new SqlCommand(sql, conn) { CommandType = type })
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                using (var reader = await cmd.ExecuteReaderAsync().ConfigureAwait(false))
                {
                    table.Load(reader);
                }
            }
            return table;
        }

        /// <summary>
        /// Выполняет INSERT/UPDATE/DELETE и возвращает число затронутых строк.
        /// </summary>
        public static async Task<int> ExecuteNonQueryAsync(
            string sql, CommandType type = CommandType.Text, params SqlParameter[] parameters)
        {
            using (var conn = await CreateConnectionAsync().ConfigureAwait(false))
            using (var cmd = new SqlCommand(sql, conn) { CommandType = type })
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                return await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Выполняет запрос и возвращает скалярное значение (например, новый ID).
        /// </summary>
        public static async Task<object> ExecuteScalarAsync(
            string sql, CommandType type = CommandType.Text, params SqlParameter[] parameters)
        {
            using (var conn = await CreateConnectionAsync().ConfigureAwait(false))
            using (var cmd = new SqlCommand(sql, conn) { CommandType = type })
            {
                if (parameters != null) cmd.Parameters.AddRange(parameters);
                return await cmd.ExecuteScalarAsync().ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Проверяет доступность БД. Возвращает true, если подключение успешно.
        /// </summary>
        public static bool TestConnection(out string error)
        {
            error = null;
            try
            {
                using (var conn = CreateConnection()) { /* открылось — значит ОК */ }
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }
    }
}
