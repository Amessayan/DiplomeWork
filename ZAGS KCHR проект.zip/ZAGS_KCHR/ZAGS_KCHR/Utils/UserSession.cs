using ZAGS_KCHR.Models;

namespace ZAGS_KCHR.Utils
{
    /// <summary>
    /// Глобальная сессия текущего авторизованного пользователя.
    /// Используется для отображения имени и проверки прав по ролям.
    /// </summary>
    public static class UserSession
    {
        /// <summary>Текущий вошедший сотрудник (null, если не авторизован).</summary>
        public static Employee CurrentUser { get; set; }

        /// <summary>Признак того, что пользователь авторизован.</summary>
        public static bool IsAuthenticated => CurrentUser != null;

        /// <summary>Является ли текущий пользователь администратором.</summary>
        public static bool IsAdmin => CurrentUser != null && CurrentUser.IsAdmin;

        /// <summary>Завершить сессию (выход).</summary>
        public static void Clear() => CurrentUser = null;
    }
}
