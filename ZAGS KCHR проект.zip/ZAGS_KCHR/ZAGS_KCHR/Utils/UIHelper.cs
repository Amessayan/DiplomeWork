using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ZAGS_KCHR.Utils
{
    /// <summary>
    /// Вспомогательные методы для построения современного интерфейса:
    /// скруглённые углы, стилизация кнопок и DataGridView, карточки-панели.
    /// </summary>
    public static class UIHelper
    {
        // Win32-функция для скругления углов элементов управления
        [System.Runtime.InteropServices.DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse);

        /// <summary>Применяет скругление углов к произвольному элементу управления.</summary>
        public static void ApplyRoundCorners(Control control, int radius = 10)
        {
            if (control.Width <= 0 || control.Height <= 0) return;
            control.Region = Region.FromHrgn(
                CreateRoundRectRgn(0, 0, control.Width, control.Height, radius, radius));
        }

        /// <summary>Возвращает путь скруглённого прямоугольника (для отрисовки).</summary>
        public static GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            int d = radius * 2;
            var path = new GraphicsPath();
            if (radius <= 0) { path.AddRectangle(bounds); path.CloseFigure(); return path; }
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        /// <summary>Стилизует кнопку как основную (бордовую) или второстепенную (бежевую).</summary>
        public static void StylePrimaryButton(Button btn, bool primary = true)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = primary ? 0 : 1;
            btn.Font = AppTheme.BodyB;
            btn.Cursor = Cursors.Hand;
            btn.UseVisualStyleBackColor = false;

            if (primary)
            {
                btn.BackColor = AppTheme.Bordeaux;
                btn.ForeColor = AppTheme.White;
                btn.FlatAppearance.MouseOverBackColor = AppTheme.BordeauxDark;
                btn.FlatAppearance.MouseDownBackColor = AppTheme.BordeauxLight;
            }
            else
            {
                btn.BackColor = AppTheme.BeigeCard;
                btn.ForeColor = AppTheme.Bordeaux;
                btn.FlatAppearance.BorderColor = AppTheme.BorderColor;
                btn.FlatAppearance.MouseOverBackColor = AppTheme.Selection;
            }
        }

        /// <summary>Стилизует золотую (акцентную) кнопку.</summary>
        public static void StyleGoldButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Font = AppTheme.BodyB;
            btn.Cursor = Cursors.Hand;
            btn.BackColor = AppTheme.Gold;
            btn.ForeColor = AppTheme.White;
            btn.UseVisualStyleBackColor = false;
            btn.FlatAppearance.MouseOverBackColor = AppTheme.GoldDark;
        }

        /// <summary>Применяет современный стиль к таблице DataGridView.</summary>
        public static void StyleGrid(DataGridView grid)
        {
            grid.BorderStyle = BorderStyle.None;
            grid.BackgroundColor = AppTheme.White;
            grid.GridColor = AppTheme.BorderColor;
            grid.EnableHeadersVisualStyles = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.AllowUserToResizeRows = false;
            grid.ReadOnly = true;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
            grid.RowHeadersVisible = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            grid.Font = AppTheme.Body;

            // Шапка
            grid.ColumnHeadersDefaultCellStyle.BackColor = AppTheme.BeigeCard;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = AppTheme.Bordeaux;
            grid.ColumnHeadersDefaultCellStyle.Font = AppTheme.BodyB;
            grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(8, 0, 0, 0);
            grid.ColumnHeadersHeight = 44;
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;

            // Строки
            grid.RowTemplate.Height = 40;
            grid.DefaultCellStyle.SelectionBackColor = AppTheme.Selection;
            grid.DefaultCellStyle.SelectionForeColor = AppTheme.TextDark;
            grid.DefaultCellStyle.Padding = new Padding(8, 0, 0, 0);
            grid.DefaultCellStyle.ForeColor = AppTheme.TextDark;
            grid.AlternatingRowsDefaultCellStyle.BackColor = AppTheme.RowAlt;
        }

        /// <summary>Рисует мягкую тень под панелью (вызывать из обработчика Paint родителя).</summary>
        public static void DrawCardShadow(Graphics g, Rectangle bounds, int radius = 12)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            for (int i = 4; i > 0; i--)
            {
                using (var pen = new Pen(Color.FromArgb(8 * i, 60, 40, 30), 1))
                {
                    var r = new Rectangle(bounds.X - i, bounds.Y - i,
                                          bounds.Width + i * 2, bounds.Height + i * 2);
                    using (var path = RoundedRect(r, radius + i))
                        g.DrawPath(pen, path);
                }
            }
        }
    }
}
