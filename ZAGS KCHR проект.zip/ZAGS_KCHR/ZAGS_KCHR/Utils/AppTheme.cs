using System.Drawing;

namespace ZAGS_KCHR.Utils
{
    /// <summary>
    /// Централизованная цветовая палитра и шрифты приложения.
    /// Стиль государственных систем РФ: бордовый, золотой, белый, бежевый.
    /// </summary>
    public static class AppTheme
    {
        // --- Основные цвета ---
        public static readonly Color Bordeaux      = Color.FromArgb(122, 22, 38);   // основной бордовый
        public static readonly Color BordeauxDark  = Color.FromArgb(94, 16, 29);    // тёмный бордовый (наведение)
        public static readonly Color BordeauxLight = Color.FromArgb(150, 40, 56);   // светлый бордовый
        public static readonly Color Gold          = Color.FromArgb(199, 161, 92);  // золотой
        public static readonly Color GoldDark      = Color.FromArgb(170, 132, 66);  // тёмный золотой
        public static readonly Color White         = Color.White;
        public static readonly Color Beige         = Color.FromArgb(248, 243, 234); // светло-бежевый фон
        public static readonly Color BeigeCard     = Color.FromArgb(252, 249, 243); // карточки
        public static readonly Color BorderColor   = Color.FromArgb(225, 215, 198); // границы
        public static readonly Color TextDark      = Color.FromArgb(45, 35, 30);    // основной текст
        public static readonly Color TextGray      = Color.FromArgb(120, 110, 100); // вторичный текст
        public static readonly Color RowAlt        = Color.FromArgb(250, 246, 239); // чередование строк таблицы
        public static readonly Color Selection     = Color.FromArgb(243, 230, 210); // выделение строки

        // --- Шрифты ---
        public const string FontFamily = "Segoe UI";

        public static Font H1     => new Font(FontFamily, 18F, FontStyle.Bold);
        public static Font H2     => new Font(FontFamily, 14F, FontStyle.Bold);
        public static Font H3     => new Font(FontFamily, 11F, FontStyle.Bold);
        public static Font Body   => new Font(FontFamily, 10F, FontStyle.Regular);
        public static Font BodyB  => new Font(FontFamily, 10F, FontStyle.Bold);
        public static Font Small  => new Font(FontFamily, 8.5F, FontStyle.Regular);
        public static Font MenuFont => new Font(FontFamily, 11F, FontStyle.Regular);
    }
}
