using System;
using System.Security.Cryptography;
using System.Text;

namespace ZAGS_KCHR.Utils
{
    /// <summary>
    /// Утилита для безопасного хэширования паролей алгоритмом SHA-256.
    /// В БД хранится не сам пароль, а его хэш (uppercase hex).
    /// </summary>
    public static class PasswordHasher
    {
        /// <summary>Возвращает SHA-256 хэш строки в верхнем регистре (HEX).</summary>
        public static string Hash(string password)
        {
            if (password == null) password = string.Empty;
            using (var sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                var sb = new StringBuilder(bytes.Length * 2);
                foreach (byte b in bytes)
                    sb.Append(b.ToString("X2")); // X2 = два символа верхнего регистра
                return sb.ToString();
            }
        }

        /// <summary>Сравнивает введённый пароль с сохранённым хэшем.</summary>
        public static bool Verify(string password, string storedHash)
        {
            if (string.IsNullOrEmpty(storedHash)) return false;
            return string.Equals(Hash(password), storedHash, StringComparison.OrdinalIgnoreCase);
        }
    }
}
