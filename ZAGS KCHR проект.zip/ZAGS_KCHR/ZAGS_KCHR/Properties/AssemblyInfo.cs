using System.Reflection;
using System.Runtime.InteropServices;

// Общая информация о сборке
[assembly: AssemblyTitle("АИС управления ЗАГС КЧР")]
[assembly: AssemblyDescription("Автоматизированная информационная система управления ЗАГС Карачаево-Черкесской Республики")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Управление ЗАГС КЧР")]
[assembly: AssemblyProduct("ZAGS_KCHR")]
[assembly: AssemblyCopyright("© 2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Невидимость сборки для COM
[assembly: ComVisible(false)]

// GUID для идентификации библиотеки типов (если проект открыт через COM)
[assembly: Guid("a3f5c8e1-2b4d-4f6a-9c8e-1d2b3f4a5c6d")]

// Версия сборки
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
