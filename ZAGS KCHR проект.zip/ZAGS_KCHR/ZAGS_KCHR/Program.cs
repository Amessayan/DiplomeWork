using System;
using System.Windows.Forms;
using ZAGS_KCHR.Forms;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR
{
    /// <summary>
    /// Точка входа в приложение «АИС управления ЗАГС КЧР».
    /// Последовательность запуска:
    ///   1) Splash screen (заставка с проверкой соединения с БД);
    ///   2) Форма авторизации (LoginForm);
    ///   3) Главное окно (MainForm).
    /// </summary>
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // Включаем современную отрисовку элементов управления
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Глобальный перехват необработанных исключений
            Application.ThreadException += (s, e) =>
                MessageBox.Show("Произошла ошибка: " + e.Exception.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

            // 1. Заставка
            using (var splash = new SplashForm())
            {
                splash.ShowDialog();
            }

            // 2. Авторизация
            using (var login = new LoginForm())
            {
                if (login.ShowDialog() != DialogResult.OK || !UserSession.IsAuthenticated)
                    return; // пользователь закрыл окно входа

                // 3. Главное окно
                Application.Run(new MainForm());
            }
        }
    }
}
