/* =====================================================================
   АВТОМАТИЗИРОВАННАЯ ИНФОРМАЦИОННАЯ СИСТЕМА УПРАВЛЕНИЯ ЗАГС КЧР
   Скрипт создания базы данных ZAGS_KCHR_DB для Microsoft SQL Server
   ---------------------------------------------------------------------
   Содержит: таблицы, первичные/внешние ключи, индексы, ограничения,
             триггеры, представления, хранимые процедуры и тестовые данные.
   Запуск:   откройте файл в SSMS и выполните (F5).
   ===================================================================== */

-- 1. Создание базы данных --------------------------------------------------
IF DB_ID('ZAGS_KCHR_DB') IS NOT NULL
BEGIN
    -- Закрываем активные подключения и удаляем старую БД (для чистой установки)
    ALTER DATABASE ZAGS_KCHR_DB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ZAGS_KCHR_DB;
END
GO

CREATE DATABASE ZAGS_KCHR_DB;
GO

USE ZAGS_KCHR_DB;
GO

/* =====================================================================
   2. ТАБЛИЦЫ
   ===================================================================== */

-- 2.1 Сотрудники (пользователи системы) -----------------------------------
CREATE TABLE dbo.Employees
(
    EmployeeID    INT IDENTITY(1,1) NOT NULL,
    FullName      NVARCHAR(150)     NOT NULL,
    Login         NVARCHAR(50)      NOT NULL,
    PasswordHash  NVARCHAR(256)     NOT NULL,   -- SHA-256 хэш пароля
    Role          NVARCHAR(30)      NOT NULL,   -- 'Администратор' | 'Сотрудник'
    Position      NVARCHAR(100)     NULL,
    IsActive      BIT               NOT NULL CONSTRAINT DF_Employees_IsActive DEFAULT(1),
    CreatedAt     DATETIME          NOT NULL CONSTRAINT DF_Employees_CreatedAt DEFAULT(GETDATE()),
    CONSTRAINT PK_Employees PRIMARY KEY (EmployeeID),
    CONSTRAINT UQ_Employees_Login UNIQUE (Login),
    CONSTRAINT CK_Employees_Role CHECK (Role IN (N'Администратор', N'Сотрудник'))
);
GO

-- 2.2 Родители ------------------------------------------------------------
CREATE TABLE dbo.Parents
(
    ParentID     INT IDENTITY(1,1) NOT NULL,
    FullName     NVARCHAR(150)     NOT NULL,
    MaidenName   NVARCHAR(100)     NULL,        -- девичья фамилия (для матери)
    BirthDate    DATE              NULL,
    Passport     NVARCHAR(20)      NULL,        -- серия и номер паспорта
    Address      NVARCHAR(250)     NULL,
    Phone        NVARCHAR(20)      NULL,
    Citizenship  NVARCHAR(50)      NULL CONSTRAINT DF_Parents_Citizenship DEFAULT(N'Российская Федерация'),
    CONSTRAINT PK_Parents PRIMARY KEY (ParentID)
);
GO

-- 2.3 Свидетельства -------------------------------------------------------
CREATE TABLE dbo.Certificates
(
    CertificateID INT IDENTITY(1,1) NOT NULL,
    Series        NVARCHAR(15)      NOT NULL,
    Number        NVARCHAR(15)      NOT NULL,
    IssueDate     DATE              NOT NULL CONSTRAINT DF_Cert_IssueDate DEFAULT(GETDATE()),
    IssuedBy      NVARCHAR(200)     NOT NULL CONSTRAINT DF_Cert_IssuedBy DEFAULT(N'Управление ЗАГС КЧР'),
    CONSTRAINT PK_Certificates PRIMARY KEY (CertificateID),
    CONSTRAINT UQ_Certificates_SeriesNumber UNIQUE (Series, Number)
);
GO

-- 2.4 Записи о рождении ---------------------------------------------------
CREATE TABLE dbo.BirthRecords
(
    BirthID          INT IDENTITY(1,1) NOT NULL,
    ChildLastName    NVARCHAR(80)      NOT NULL,
    ChildFirstName   NVARCHAR(80)      NOT NULL,
    ChildMiddleName  NVARCHAR(80)      NULL,
    BirthDate        DATE              NOT NULL,
    BirthTime        TIME(0)           NULL,
    BirthPlace       NVARCHAR(200)     NULL,
    Gender           NVARCHAR(10)      NOT NULL,   -- 'Мужской' | 'Женский'
    Weight           DECIMAL(5,2)      NULL,       -- граммы
    Height           DECIMAL(5,2)      NULL,       -- сантиметры
    MotherID         INT               NULL,
    FatherID         INT               NULL,
    CertificateID    INT               NULL,
    RegistrationDate DATETIME          NOT NULL CONSTRAINT DF_Birth_RegDate DEFAULT(GETDATE()),
    EmployeeID       INT               NULL,
    CONSTRAINT PK_BirthRecords PRIMARY KEY (BirthID),
    CONSTRAINT CK_Birth_Gender CHECK (Gender IN (N'Мужской', N'Женский')),
    -- Внешние ключи (связи 1:M)
    CONSTRAINT FK_Birth_Mother      FOREIGN KEY (MotherID)      REFERENCES dbo.Parents(ParentID),
    CONSTRAINT FK_Birth_Father      FOREIGN KEY (FatherID)      REFERENCES dbo.Parents(ParentID),
    CONSTRAINT FK_Birth_Certificate FOREIGN KEY (CertificateID) REFERENCES dbo.Certificates(CertificateID),
    CONSTRAINT FK_Birth_Employee    FOREIGN KEY (EmployeeID)    REFERENCES dbo.Employees(EmployeeID)
);
GO

-- 2.5 Журнал аудита -------------------------------------------------------
CREATE TABLE dbo.AuditLogs
(
    LogID      INT IDENTITY(1,1) NOT NULL,
    EmployeeID INT               NULL,
    Action     NVARCHAR(300)     NOT NULL,
    ActionDate DATETIME          NOT NULL CONSTRAINT DF_Audit_Date DEFAULT(GETDATE()),
    CONSTRAINT PK_AuditLogs PRIMARY KEY (LogID),
    CONSTRAINT FK_Audit_Employee FOREIGN KEY (EmployeeID) REFERENCES dbo.Employees(EmployeeID)
);
GO

/* =====================================================================
   3. ИНДЕКСЫ (ускоряют поиск и фильтрацию)
   ===================================================================== */
CREATE INDEX IX_Birth_BirthDate   ON dbo.BirthRecords(BirthDate);
CREATE INDEX IX_Birth_LastName    ON dbo.BirthRecords(ChildLastName);
CREATE INDEX IX_Birth_Gender      ON dbo.BirthRecords(Gender);
CREATE INDEX IX_Parents_FullName  ON dbo.Parents(FullName);
GO

/* =====================================================================
   4. ТРИГГЕР аудита: фиксирует добавление записей о рождении
   ===================================================================== */
CREATE TRIGGER trg_BirthRecords_Insert
ON dbo.BirthRecords
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.AuditLogs (EmployeeID, Action)
    SELECT i.EmployeeID,
           N'Добавлена запись о рождении: ' + i.ChildLastName + N' ' + i.ChildFirstName
    FROM inserted i;
END
GO

/* =====================================================================
   5. ПРЕДСТАВЛЕНИЕ: полная информация о рождениях с родителями
   ===================================================================== */
CREATE VIEW dbo.vw_BirthFull
AS
SELECT  b.BirthID,
        b.ChildLastName + N' ' + b.ChildFirstName + N' ' + ISNULL(b.ChildMiddleName, N'') AS ChildFullName,
        b.BirthDate,
        b.BirthTime,
        b.BirthPlace,
        b.Gender,
        m.FullName  AS MotherName,
        f.FullName  AS FatherName,
        c.Series,
        c.Number,
        c.IssueDate,
        b.RegistrationDate,
        e.FullName  AS EmployeeName
FROM        dbo.BirthRecords b
LEFT JOIN   dbo.Parents      m ON b.MotherID = m.ParentID
LEFT JOIN   dbo.Parents      f ON b.FatherID = f.ParentID
LEFT JOIN   dbo.Certificates c ON b.CertificateID = c.CertificateID
LEFT JOIN   dbo.Employees    e ON b.EmployeeID = e.EmployeeID;
GO

/* =====================================================================
   6. ХРАНИМЫЕ ПРОЦЕДУРЫ
   ===================================================================== */

-- 6.1 Поиск/фильтрация записей о рождении ---------------------------------
CREATE PROCEDURE dbo.sp_SearchBirths
    @Search   NVARCHAR(200) = NULL,
    @DateFrom DATE          = NULL,
    @DateTo   DATE          = NULL,
    @Gender   NVARCHAR(10)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT  b.BirthID,
            b.ChildLastName, b.ChildFirstName, b.ChildMiddleName,
            b.BirthDate, b.BirthTime, b.BirthPlace, b.Gender,
            b.Weight, b.Height,
            b.MotherID, b.FatherID, b.CertificateID, b.EmployeeID,
            b.RegistrationDate,
            m.FullName AS MotherName,
            f.FullName AS FatherName,
            c.Series, c.Number, c.IssueDate, c.IssuedBy
    FROM        dbo.BirthRecords b
    LEFT JOIN   dbo.Parents      m ON b.MotherID = m.ParentID
    LEFT JOIN   dbo.Parents      f ON b.FatherID = f.ParentID
    LEFT JOIN   dbo.Certificates c ON b.CertificateID = c.CertificateID
    WHERE (@Search   IS NULL
              OR b.ChildLastName  LIKE '%' + @Search + '%'
              OR b.ChildFirstName LIKE '%' + @Search + '%'
              OR c.Number         LIKE '%' + @Search + '%')
      AND (@DateFrom IS NULL OR b.BirthDate >= @DateFrom)
      AND (@DateTo   IS NULL OR b.BirthDate <= @DateTo)
      AND (@Gender   IS NULL OR b.Gender = @Gender)
    ORDER BY b.BirthDate DESC;
END
GO

-- 6.2 Отчёт: количество рождений по месяцам -------------------------------
CREATE PROCEDURE dbo.sp_ReportBirthsByMonth
AS
BEGIN
    SET NOCOUNT ON;
    SELECT  YEAR(BirthDate)  AS [Год],
            MONTH(BirthDate) AS [Месяц],
            COUNT(*)         AS [Количество]
    FROM    dbo.BirthRecords
    GROUP BY YEAR(BirthDate), MONTH(BirthDate)
    ORDER BY [Год], [Месяц];
END
GO

-- 6.3 Отчёт: распределение по полу ----------------------------------------
CREATE PROCEDURE dbo.sp_ReportByGender
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Gender AS [Пол], COUNT(*) AS [Количество]
    FROM   dbo.BirthRecords
    GROUP BY Gender;
END
GO

-- 6.4 Отчёт: по сотрудникам -----------------------------------------------
CREATE PROCEDURE dbo.sp_ReportByEmployee
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ISNULL(e.FullName, N'(не указан)') AS [Сотрудник],
           COUNT(*)                           AS [Зарегистрировано]
    FROM        dbo.BirthRecords b
    LEFT JOIN   dbo.Employees    e ON b.EmployeeID = e.EmployeeID
    GROUP BY e.FullName
    ORDER BY [Зарегистрировано] DESC;
END
GO

-- 6.5 Отчёт: по местам/городам рождения -----------------------------------
CREATE PROCEDURE dbo.sp_ReportByPlace
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ISNULL(BirthPlace, N'(не указано)') AS [Место рождения],
           COUNT(*)                            AS [Количество]
    FROM   dbo.BirthRecords
    GROUP BY BirthPlace
    ORDER BY [Количество] DESC;
END
GO

/* =====================================================================
   7. ТЕСТОВЫЕ ДАННЫЕ
   ===================================================================== */

-- 7.1 Сотрудники. Пароли — SHA-256.
--     Логин: admin    Пароль: admin123  (Администратор)
--     Логин: ivanova  Пароль: 12345     (Сотрудник)
INSERT INTO dbo.Employees (FullName, Login, PasswordHash, Role, Position)
VALUES
 (N'Администратор Системы', N'admin',
  N'240BE518FABD2724DDB6F04EEB1DA5967448D7E831C08C8FA822809F74C720A9', N'Администратор', N'Системный администратор'),
 (N'Иванова Ирина Игоревна', N'ivanova',
  N'5994471ABB01112AFCC18159F6CC74B4F511B99806DA59B3CAF5A9C173CACFC5', N'Сотрудник', N'Сотрудник ЗАГС');
GO

-- 7.2 Родители
INSERT INTO dbo.Parents (FullName, MaidenName, BirthDate, Passport, Address, Phone, Citizenship) VALUES
 (N'Иванова Мария Петровна',     N'Соколова',  '1992-03-15', N'9100 123456', N'г. Черкесск, ул. Ленина, 10', N'+79280000001', N'Российская Федерация'),
 (N'Иванов Сергей Викторович',   NULL,         '1989-07-22', N'9100 654321', N'г. Черкесск, ул. Ленина, 10', N'+79280000002', N'Российская Федерация'),
 (N'Смирнова Ольга Андреевна',   N'Белова',    '1994-11-02', N'9101 222333', N'г. Карачаевск, ул. Мира, 5',  N'+79280000003', N'Российская Федерация'),
 (N'Смирнов Дмитрий Алексеевич', NULL,         '1990-01-19', N'9101 333222', N'г. Карачаевск, ул. Мира, 5',  N'+79280000004', N'Российская Федерация'),
 (N'Кузнецова Елена Игоревна',   N'Орлова',    '1995-06-30', N'9102 444555', N'г. Черкесск, пр. Победы, 21',  N'+79280000005', N'Российская Федерация'),
 (N'Кузнецов Алексей Юрьевич',   NULL,         '1988-09-14', N'9102 555444', N'г. Черкесск, пр. Победы, 21',  N'+79280000006', N'Российская Федерация');
GO

-- 7.3 Свидетельства
INSERT INTO dbo.Certificates (Series, Number, IssueDate, IssuedBy) VALUES
 (N'I-МЮ', N'123456', '2024-01-16', N'Управление ЗАГС КЧР'),
 (N'I-МЮ', N'123457', '2024-01-21', N'Управление ЗАГС КЧР'),
 (N'I-МЮ', N'123458', '2024-01-26', N'Управление ЗАГС КЧР');
GO

-- 7.4 Записи о рождении
INSERT INTO dbo.BirthRecords
 (ChildLastName, ChildFirstName, ChildMiddleName, BirthDate, BirthTime, BirthPlace,
  Gender, Weight, Height, MotherID, FatherID, CertificateID, EmployeeID)
VALUES
 (N'Иванов',   N'Артём',   N'Сергеевич',  '2024-01-15', '10:35', N'г. Черкесск, ГКБ №1',  N'Мужской', 3450, 52, 1, 2, 1, 2),
 (N'Смирнова', N'Анна',    N'Дмитриевна', '2024-01-20', '14:20', N'г. Карачаевск, ЦРБ',   N'Женский', 3200, 50, 3, 4, 2, 2),
 (N'Кузнецов', N'Матвей',  N'Алексеевич', '2024-01-25', '09:15', N'г. Черкесск, ГКБ №2',  N'Мужской', 3600, 53, 5, 6, 3, 2);
GO

PRINT N'>>> База данных ZAGS_KCHR_DB успешно создана и заполнена тестовыми данными.';
GO
