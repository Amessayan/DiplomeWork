/* =====================================================================
   ПРИМЕРЫ SQL-ЗАПРОСОВ К БАЗЕ ДАННЫХ ZAGS_KCHR_DB
   (для демонстрации на защите дипломной работы)
   ===================================================================== */
USE ZAGS_KCHR_DB;
GO

/* ---------- SELECT: все записи о рождении ---------- */
SELECT * FROM dbo.BirthRecords;

/* ---------- SELECT + JOIN: ребёнок и его родители ---------- */
SELECT  b.ChildLastName, b.ChildFirstName,
        m.FullName AS Мать,
        f.FullName AS Отец
FROM        dbo.BirthRecords b
LEFT JOIN   dbo.Parents m ON b.MotherID = m.ParentID
LEFT JOIN   dbo.Parents f ON b.FatherID = f.ParentID;

/* ---------- Поиск ребёнка по фамилии ---------- */
SELECT * FROM dbo.BirthRecords
WHERE ChildLastName LIKE N'Иван%';

/* ---------- Фильтр по дате рождения ---------- */
SELECT * FROM dbo.BirthRecords
WHERE BirthDate BETWEEN '2024-01-01' AND '2024-12-31'
ORDER BY BirthDate DESC;

/* ---------- GROUP BY: статистика по полу ---------- */
SELECT Gender AS Пол, COUNT(*) AS Количество
FROM   dbo.BirthRecords
GROUP BY Gender;

/* ---------- GROUP BY: рождения по месяцам ---------- */
SELECT YEAR(BirthDate) AS Год, MONTH(BirthDate) AS Месяц, COUNT(*) AS Кол
FROM   dbo.BirthRecords
GROUP BY YEAR(BirthDate), MONTH(BirthDate)
ORDER BY Год, Месяц;

/* ---------- INSERT: новый родитель ---------- */
INSERT INTO dbo.Parents (FullName, BirthDate, Citizenship)
VALUES (N'Петрова Анна Ивановна', '1996-05-12', N'Российская Федерация');

/* ---------- UPDATE: изменение телефона ---------- */
UPDATE dbo.Parents
SET Phone = N'+79280001122'
WHERE FullName = N'Петрова Анна Ивановна';

/* ---------- DELETE: удаление родителя ---------- */
DELETE FROM dbo.Parents
WHERE FullName = N'Петрова Анна Ивановна';

/* ---------- Использование представления ---------- */
SELECT * FROM dbo.vw_BirthFull;

/* ---------- Вызов хранимых процедур ---------- */
EXEC dbo.sp_SearchBirths @Search = N'Иванов';
EXEC dbo.sp_SearchBirths @DateFrom = '2024-01-01', @DateTo = '2024-02-01';
EXEC dbo.sp_ReportBirthsByMonth;
EXEC dbo.sp_ReportByGender;
EXEC dbo.sp_ReportByEmployee;
EXEC dbo.sp_ReportByPlace;
GO
