namespace ZAGS_KCHR.Forms.Views
{
    partial class ParentForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label lblMaiden;
        private System.Windows.Forms.TextBox txtMaiden;
        private System.Windows.Forms.CheckBox chkBirthDate;
        private System.Windows.Forms.DateTimePicker dtBirthDate;
        private System.Windows.Forms.Label lblPassport;
        private System.Windows.Forms.TextBox txtPassport;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblCitizenship;
        private System.Windows.Forms.TextBox txtCitizenship;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblHeader = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.lblMaiden = new System.Windows.Forms.Label();
            this.txtMaiden = new System.Windows.Forms.TextBox();
            this.chkBirthDate = new System.Windows.Forms.CheckBox();
            this.dtBirthDate = new System.Windows.Forms.DateTimePicker();
            this.lblPassport = new System.Windows.Forms.Label();
            this.txtPassport = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblCitizenship = new System.Windows.Forms.Label();
            this.txtCitizenship = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            //
            // lblHeader
            //
            this.lblHeader.AutoSize = true;
            this.lblHeader.Location = new System.Drawing.Point(24, 18);
            this.lblHeader.Text = "Данные родителя";
            //
            // lblFullName
            //
            this.lblFullName.AutoSize = true;
            this.lblFullName.Location = new System.Drawing.Point(24, 60);
            this.lblFullName.Text = "ФИО *";
            //
            // txtFullName
            //
            this.txtFullName.Location = new System.Drawing.Point(24, 82);
            this.txtFullName.Size = new System.Drawing.Size(420, 27);
            this.txtFullName.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblMaiden
            //
            this.lblMaiden.AutoSize = true;
            this.lblMaiden.Location = new System.Drawing.Point(24, 122);
            this.lblMaiden.Text = "Девичья фамилия";
            //
            // txtMaiden
            //
            this.txtMaiden.Location = new System.Drawing.Point(24, 144);
            this.txtMaiden.Size = new System.Drawing.Size(200, 27);
            this.txtMaiden.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // chkBirthDate
            //
            this.chkBirthDate.AutoSize = true;
            this.chkBirthDate.Location = new System.Drawing.Point(244, 124);
            this.chkBirthDate.Text = "Дата рождения";
            this.chkBirthDate.CheckedChanged += new System.EventHandler(this.chkBirthDate_CheckedChanged);
            //
            // dtBirthDate
            //
            this.dtBirthDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtBirthDate.Location = new System.Drawing.Point(244, 144);
            this.dtBirthDate.Size = new System.Drawing.Size(200, 27);
            //
            // lblPassport
            //
            this.lblPassport.AutoSize = true;
            this.lblPassport.Location = new System.Drawing.Point(24, 184);
            this.lblPassport.Text = "Паспорт";
            //
            // txtPassport
            //
            this.txtPassport.Location = new System.Drawing.Point(24, 206);
            this.txtPassport.Size = new System.Drawing.Size(200, 27);
            this.txtPassport.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblPhone
            //
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(244, 184);
            this.lblPhone.Text = "Телефон";
            //
            // txtPhone
            //
            this.txtPhone.Location = new System.Drawing.Point(244, 206);
            this.txtPhone.Size = new System.Drawing.Size(200, 27);
            this.txtPhone.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblCitizenship
            //
            this.lblCitizenship.AutoSize = true;
            this.lblCitizenship.Location = new System.Drawing.Point(24, 246);
            this.lblCitizenship.Text = "Гражданство";
            //
            // txtCitizenship
            //
            this.txtCitizenship.Location = new System.Drawing.Point(24, 268);
            this.txtCitizenship.Size = new System.Drawing.Size(200, 27);
            this.txtCitizenship.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblAddress
            //
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(24, 308);
            this.lblAddress.Text = "Адрес";
            //
            // txtAddress
            //
            this.txtAddress.Location = new System.Drawing.Point(24, 330);
            this.txtAddress.Size = new System.Drawing.Size(420, 27);
            this.txtAddress.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // btnSave
            //
            this.btnSave.Location = new System.Drawing.Point(194, 384);
            this.btnSave.Size = new System.Drawing.Size(120, 40);
            this.btnSave.Text = "Сохранить";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            //
            // btnCancel
            //
            this.btnCancel.Location = new System.Drawing.Point(324, 384);
            this.btnCancel.Size = new System.Drawing.Size(120, 40);
            this.btnCancel.Text = "Отмена";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            //
            // ParentForm
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(470, 446);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.lblFullName);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.lblMaiden);
            this.Controls.Add(this.txtMaiden);
            this.Controls.Add(this.chkBirthDate);
            this.Controls.Add(this.dtBirthDate);
            this.Controls.Add(this.lblPassport);
            this.Controls.Add(this.txtPassport);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.lblCitizenship);
            this.Controls.Add(this.txtCitizenship);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Name = "ParentForm";
            this.Text = "Родитель";
            this.Load += new System.EventHandler(this.ParentForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
