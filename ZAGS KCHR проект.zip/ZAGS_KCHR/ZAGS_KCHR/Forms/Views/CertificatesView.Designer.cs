namespace ZAGS_KCHR.Forms.Views
{
    partial class CertificatesView
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSeries;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFull;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIssueDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIssuedBy;
        private System.Windows.Forms.Label lblCount;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.grid = new System.Windows.Forms.DataGridView();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSeries = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFull = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIssueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colIssuedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(28, 22);
            this.lblTitle.Text = "Свидетельства";
            //
            // btnRefresh
            //
            this.btnRefresh.Location = new System.Drawing.Point(28, 64);
            this.btnRefresh.Size = new System.Drawing.Size(120, 34);
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            //
            // btnDelete
            //
            this.btnDelete.Location = new System.Drawing.Point(160, 64);
            this.btnDelete.Size = new System.Drawing.Size(120, 34);
            this.btnDelete.Text = "Удалить";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            //
            // grid
            //
            this.grid.Location = new System.Drawing.Point(28, 112);
            this.grid.Size = new System.Drawing.Size(1128, 460);
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colId, this.colSeries, this.colNumber, this.colFull,
                this.colIssueDate, this.colIssuedBy });
            //
            this.colId.HeaderText = "ID";
            this.colId.FillWeight = 30F;
            this.colSeries.HeaderText = "Серия";
            this.colSeries.FillWeight = 60F;
            this.colNumber.HeaderText = "Номер";
            this.colNumber.FillWeight = 80F;
            this.colFull.HeaderText = "Полный номер";
            this.colFull.FillWeight = 110F;
            this.colIssueDate.HeaderText = "Дата выдачи";
            this.colIssueDate.FillWeight = 90F;
            this.colIssuedBy.HeaderText = "Кем выдано";
            this.colIssuedBy.FillWeight = 180F;
            //
            // lblCount
            //
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(28, 584);
            this.lblCount.Text = "Всего свидетельств: 0";
            //
            // CertificatesView
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.lblCount);
            this.Name = "CertificatesView";
            this.Size = new System.Drawing.Size(1200, 620);
            this.Load += new System.EventHandler(this.CertificatesView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
