namespace ZAGS_KCHR.Forms.Views
{
    partial class UsersView
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLogin;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRole;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPosition;
        private System.Windows.Forms.DataGridViewTextBoxColumn colActive;
        private System.Windows.Forms.Panel panelEdit;
        private System.Windows.Forms.Label lblEditTitle;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.CheckBox chkShowPassword;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.CheckBox chkActive;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grid = new System.Windows.Forms.DataGridView();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLogin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPosition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colActive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelEdit = new System.Windows.Forms.Panel();
            this.lblEditTitle = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.lblLogin = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.chkShowPassword = new System.Windows.Forms.CheckBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.cmbRole = new System.Windows.Forms.ComboBox();
            this.lblPosition = new System.Windows.Forms.Label();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.chkActive = new System.Windows.Forms.CheckBox();
            this.lblHint = new System.Windows.Forms.Label();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.panelEdit.SuspendLayout();
            this.SuspendLayout();
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(28, 22);
            this.lblTitle.Text = "Пользователи";
            //
            // grid
            //
            this.grid.Location = new System.Drawing.Point(28, 70);
            this.grid.Size = new System.Drawing.Size(720, 510);
            this.grid.ReadOnly = true;
            this.grid.MultiSelect = false;
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colId, this.colName, this.colLogin, this.colRole,
                this.colPosition, this.colActive });
            this.grid.SelectionChanged += new System.EventHandler(this.grid_SelectionChanged);
            //
            this.colId.HeaderText = "ID";
            this.colId.FillWeight = 30F;
            this.colName.HeaderText = "ФИО";
            this.colName.FillWeight = 140F;
            this.colLogin.HeaderText = "Логин";
            this.colLogin.FillWeight = 80F;
            this.colRole.HeaderText = "Роль";
            this.colRole.FillWeight = 90F;
            this.colPosition.HeaderText = "Должность";
            this.colPosition.FillWeight = 110F;
            this.colActive.HeaderText = "Активен";
            this.colActive.FillWeight = 60F;
            //
            // panelEdit
            //
            this.panelEdit.Location = new System.Drawing.Point(768, 70);
            this.panelEdit.Size = new System.Drawing.Size(388, 510);
            this.panelEdit.BackColor = System.Drawing.Color.FromArgb(252, 249, 243);
            this.panelEdit.Controls.Add(this.lblEditTitle);
            this.panelEdit.Controls.Add(this.lblFullName);
            this.panelEdit.Controls.Add(this.txtFullName);
            this.panelEdit.Controls.Add(this.lblLogin);
            this.panelEdit.Controls.Add(this.txtLogin);
            this.panelEdit.Controls.Add(this.lblPassword);
            this.panelEdit.Controls.Add(this.txtPassword);
            this.panelEdit.Controls.Add(this.chkShowPassword);
            this.panelEdit.Controls.Add(this.lblRole);
            this.panelEdit.Controls.Add(this.cmbRole);
            this.panelEdit.Controls.Add(this.lblPosition);
            this.panelEdit.Controls.Add(this.txtPosition);
            this.panelEdit.Controls.Add(this.chkActive);
            this.panelEdit.Controls.Add(this.lblHint);
            this.panelEdit.Controls.Add(this.btnNew);
            this.panelEdit.Controls.Add(this.btnSave);
            this.panelEdit.Controls.Add(this.btnDelete);
            //
            // lblEditTitle
            //
            this.lblEditTitle.AutoSize = true;
            this.lblEditTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblEditTitle.Location = new System.Drawing.Point(20, 16);
            this.lblEditTitle.Text = "Карточка пользователя";
            //
            // lblFullName
            //
            this.lblFullName.AutoSize = true;
            this.lblFullName.Location = new System.Drawing.Point(20, 54);
            this.lblFullName.Text = "ФИО *";
            //
            // txtFullName
            //
            this.txtFullName.Location = new System.Drawing.Point(20, 76);
            this.txtFullName.Size = new System.Drawing.Size(348, 27);
            this.txtFullName.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblLogin
            //
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(20, 114);
            this.lblLogin.Text = "Логин *";
            //
            // txtLogin
            //
            this.txtLogin.Location = new System.Drawing.Point(20, 136);
            this.txtLogin.Size = new System.Drawing.Size(348, 27);
            this.txtLogin.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblPassword
            //
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(20, 174);
            this.lblPassword.Text = "Пароль";
            //
            // txtPassword
            //
            this.txtPassword.Location = new System.Drawing.Point(20, 196);
            this.txtPassword.Size = new System.Drawing.Size(348, 27);
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // chkShowPassword
            //
            this.chkShowPassword.AutoSize = true;
            this.chkShowPassword.Location = new System.Drawing.Point(20, 228);
            this.chkShowPassword.Text = "Показать пароль";
            this.chkShowPassword.CheckedChanged += new System.EventHandler(this.chkShowPassword_CheckedChanged);
            //
            // lblRole
            //
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(20, 258);
            this.lblRole.Text = "Роль";
            //
            // cmbRole
            //
            this.cmbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRole.Location = new System.Drawing.Point(20, 280);
            this.cmbRole.Size = new System.Drawing.Size(348, 28);
            this.cmbRole.Items.AddRange(new object[] { "Сотрудник", "Администратор" });
            //
            // lblPosition
            //
            this.lblPosition.AutoSize = true;
            this.lblPosition.Location = new System.Drawing.Point(20, 320);
            this.lblPosition.Text = "Должность";
            //
            // txtPosition
            //
            this.txtPosition.Location = new System.Drawing.Point(20, 342);
            this.txtPosition.Size = new System.Drawing.Size(348, 27);
            this.txtPosition.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // chkActive
            //
            this.chkActive.AutoSize = true;
            this.chkActive.Checked = true;
            this.chkActive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkActive.Location = new System.Drawing.Point(20, 380);
            this.chkActive.Text = "Активен";
            //
            // lblHint
            //
            this.lblHint.Location = new System.Drawing.Point(20, 406);
            this.lblHint.Size = new System.Drawing.Size(348, 36);
            this.lblHint.ForeColor = System.Drawing.Color.FromArgb(120, 110, 100);
            this.lblHint.Text = "";
            //
            // btnNew
            //
            this.btnNew.Location = new System.Drawing.Point(20, 452);
            this.btnNew.Size = new System.Drawing.Size(110, 40);
            this.btnNew.Text = "Новый";
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            //
            // btnSave
            //
            this.btnSave.Location = new System.Drawing.Point(138, 452);
            this.btnSave.Size = new System.Drawing.Size(110, 40);
            this.btnSave.Text = "Сохранить";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            //
            // btnDelete
            //
            this.btnDelete.Location = new System.Drawing.Point(256, 452);
            this.btnDelete.Size = new System.Drawing.Size(110, 40);
            this.btnDelete.Text = "Удалить";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            //
            // UsersView
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.panelEdit);
            this.Name = "UsersView";
            this.Size = new System.Drawing.Size(1200, 620);
            this.Load += new System.EventHandler(this.UsersView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.panelEdit.ResumeLayout(false);
            this.panelEdit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
