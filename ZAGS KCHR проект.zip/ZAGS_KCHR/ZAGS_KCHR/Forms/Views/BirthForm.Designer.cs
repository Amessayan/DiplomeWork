namespace ZAGS_KCHR.Forms.Views
{
    partial class BirthForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblMiddleName;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.Label lblBirthDate;
        private System.Windows.Forms.DateTimePicker dtBirthDate;
        private System.Windows.Forms.Label lblBirthTime;
        private System.Windows.Forms.DateTimePicker dtBirthTime;
        private System.Windows.Forms.Label lblPlace;
        private System.Windows.Forms.TextBox txtPlace;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.NumericUpDown numWeight;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.NumericUpDown numHeight;
        private System.Windows.Forms.Label lblMother;
        private System.Windows.Forms.ComboBox cmbMother;
        private System.Windows.Forms.Label lblFather;
        private System.Windows.Forms.ComboBox cmbFather;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblHeader = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblMiddleName = new System.Windows.Forms.Label();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.lblBirthDate = new System.Windows.Forms.Label();
            this.dtBirthDate = new System.Windows.Forms.DateTimePicker();
            this.lblBirthTime = new System.Windows.Forms.Label();
            this.dtBirthTime = new System.Windows.Forms.DateTimePicker();
            this.lblPlace = new System.Windows.Forms.Label();
            this.txtPlace = new System.Windows.Forms.TextBox();
            this.lblGender = new System.Windows.Forms.Label();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.lblWeight = new System.Windows.Forms.Label();
            this.numWeight = new System.Windows.Forms.NumericUpDown();
            this.lblHeight = new System.Windows.Forms.Label();
            this.numHeight = new System.Windows.Forms.NumericUpDown();
            this.lblMother = new System.Windows.Forms.Label();
            this.cmbMother = new System.Windows.Forms.ComboBox();
            this.lblFather = new System.Windows.Forms.Label();
            this.cmbFather = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numWeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHeight)).BeginInit();
            this.SuspendLayout();
            //
            // lblHeader
            //
            this.lblHeader.AutoSize = true;
            this.lblHeader.Location = new System.Drawing.Point(24, 18);
            this.lblHeader.Text = "Данные о рождении";
            //
            // lblLastName
            //
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(24, 62);
            this.lblLastName.Text = "Фамилия ребёнка *";
            //
            // txtLastName
            //
            this.txtLastName.Location = new System.Drawing.Point(24, 84);
            this.txtLastName.Size = new System.Drawing.Size(250, 27);
            this.txtLastName.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblFirstName
            //
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(290, 62);
            this.lblFirstName.Text = "Имя *";
            //
            // txtFirstName
            //
            this.txtFirstName.Location = new System.Drawing.Point(290, 84);
            this.txtFirstName.Size = new System.Drawing.Size(200, 27);
            this.txtFirstName.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblMiddleName
            //
            this.lblMiddleName.AutoSize = true;
            this.lblMiddleName.Location = new System.Drawing.Point(506, 62);
            this.lblMiddleName.Text = "Отчество";
            //
            // txtMiddleName
            //
            this.txtMiddleName.Location = new System.Drawing.Point(506, 84);
            this.txtMiddleName.Size = new System.Drawing.Size(200, 27);
            this.txtMiddleName.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblBirthDate
            //
            this.lblBirthDate.AutoSize = true;
            this.lblBirthDate.Location = new System.Drawing.Point(24, 124);
            this.lblBirthDate.Text = "Дата рождения *";
            //
            // dtBirthDate
            //
            this.dtBirthDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtBirthDate.Location = new System.Drawing.Point(24, 146);
            this.dtBirthDate.Size = new System.Drawing.Size(150, 27);
            //
            // lblBirthTime
            //
            this.lblBirthTime.AutoSize = true;
            this.lblBirthTime.Location = new System.Drawing.Point(190, 124);
            this.lblBirthTime.Text = "Время";
            //
            // dtBirthTime
            //
            this.dtBirthTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtBirthTime.ShowUpDown = true;
            this.dtBirthTime.Location = new System.Drawing.Point(190, 146);
            this.dtBirthTime.Size = new System.Drawing.Size(100, 27);
            //
            // lblPlace
            //
            this.lblPlace.AutoSize = true;
            this.lblPlace.Location = new System.Drawing.Point(306, 124);
            this.lblPlace.Text = "Место рождения";
            //
            // txtPlace
            //
            this.txtPlace.Location = new System.Drawing.Point(306, 146);
            this.txtPlace.Size = new System.Drawing.Size(400, 27);
            this.txtPlace.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblGender
            //
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(24, 186);
            this.lblGender.Text = "Пол *";
            //
            // cmbGender
            //
            this.cmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGender.Location = new System.Drawing.Point(24, 208);
            this.cmbGender.Size = new System.Drawing.Size(150, 28);
            this.cmbGender.Items.AddRange(new object[] { "Мужской", "Женский" });
            //
            // lblWeight
            //
            this.lblWeight.AutoSize = true;
            this.lblWeight.Location = new System.Drawing.Point(190, 186);
            this.lblWeight.Text = "Вес, г";
            //
            // numWeight
            //
            this.numWeight.Location = new System.Drawing.Point(190, 208);
            this.numWeight.Size = new System.Drawing.Size(100, 27);
            this.numWeight.Maximum = new decimal(new int[] { 9000, 0, 0, 0 });
            this.numWeight.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblHeight
            //
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(306, 186);
            this.lblHeight.Text = "Рост, см";
            //
            // numHeight
            //
            this.numHeight.Location = new System.Drawing.Point(306, 208);
            this.numHeight.Size = new System.Drawing.Size(100, 27);
            this.numHeight.Maximum = new decimal(new int[] { 80, 0, 0, 0 });
            this.numHeight.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblMother
            //
            this.lblMother.AutoSize = true;
            this.lblMother.Location = new System.Drawing.Point(24, 248);
            this.lblMother.Text = "Мать";
            //
            // cmbMother
            //
            this.cmbMother.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMother.Location = new System.Drawing.Point(24, 270);
            this.cmbMother.Size = new System.Drawing.Size(330, 28);
            //
            // lblFather
            //
            this.lblFather.AutoSize = true;
            this.lblFather.Location = new System.Drawing.Point(376, 248);
            this.lblFather.Text = "Отец";
            //
            // cmbFather
            //
            this.cmbFather.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFather.Location = new System.Drawing.Point(376, 270);
            this.cmbFather.Size = new System.Drawing.Size(330, 28);
            //
            // btnSave
            //
            this.btnSave.Location = new System.Drawing.Point(456, 330);
            this.btnSave.Size = new System.Drawing.Size(120, 40);
            this.btnSave.Text = "Сохранить";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            //
            // btnCancel
            //
            this.btnCancel.Location = new System.Drawing.Point(586, 330);
            this.btnCancel.Size = new System.Drawing.Size(120, 40);
            this.btnCancel.Text = "Отмена";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            //
            // BirthForm
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(732, 392);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.lblMiddleName);
            this.Controls.Add(this.txtMiddleName);
            this.Controls.Add(this.lblBirthDate);
            this.Controls.Add(this.dtBirthDate);
            this.Controls.Add(this.lblBirthTime);
            this.Controls.Add(this.dtBirthTime);
            this.Controls.Add(this.lblPlace);
            this.Controls.Add(this.txtPlace);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.numWeight);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.numHeight);
            this.Controls.Add(this.lblMother);
            this.Controls.Add(this.cmbMother);
            this.Controls.Add(this.lblFather);
            this.Controls.Add(this.cmbFather);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Name = "BirthForm";
            this.Text = "Запись о рождении";
            this.Load += new System.EventHandler(this.BirthForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numWeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHeight)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
