using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Раздел «Родители». CRUD-операции над данными родителей.
    /// </summary>
    public partial class ParentsView : UserControl
    {
        private readonly ParentRepository _repo = new ParentRepository();
        private List<Parent> _items = new List<Parent>();

        public ParentsView()
        {
            InitializeComponent();
            StyleView();
        }

        private async void ParentsView_Load(object sender, EventArgs e) => await LoadAsync();

        private void StyleView()
        {
            BackColor = AppTheme.Beige;
            lblTitle.Font = AppTheme.H1;
            lblTitle.ForeColor = AppTheme.Bordeaux;
            UIHelper.StyleGrid(grid);
            UIHelper.StylePrimaryButton(btnAdd);
            UIHelper.StylePrimaryButton(btnEdit, false);
            UIHelper.StylePrimaryButton(btnDelete, false);
            UIHelper.StyleGoldButton(btnRefresh);
            UIHelper.StylePrimaryButton(btnSearch);
        }

        private async System.Threading.Tasks.Task LoadAsync()
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                string search = string.IsNullOrWhiteSpace(txtSearch.Text) ? null : txtSearch.Text.Trim();
                _items = await _repo.GetAllAsync(search);

                grid.Rows.Clear();
                foreach (var p in _items)
                {
                    int idx = grid.Rows.Add(
                        p.ParentID,
                        p.FullName,
                        p.MaidenName,
                        p.BirthDate?.ToString("dd.MM.yyyy"),
                        p.Passport,
                        p.Phone,
                        p.Citizenship,
                        p.Address);
                    grid.Rows[idx].Tag = p;
                }
                lblCount.Text = $"Всего родителей: {_items.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { Cursor = Cursors.Default; }
        }

        private Parent Selected =>
            grid.SelectedRows.Count > 0 ? grid.SelectedRows[0].Tag as Parent : null;

        private async void btnSearch_Click(object sender, EventArgs e) => await LoadAsync();
        private async void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            await LoadAsync();
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            using (var f = new ParentForm())
                if (f.ShowDialog() == DialogResult.OK) await LoadAsync();
        }

        private async void btnEdit_Click(object sender, EventArgs e)
        {
            if (Selected == null)
            {
                MessageBox.Show("Выберите родителя.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            using (var f = new ParentForm(Selected))
                if (f.ShowDialog() == DialogResult.OK) await LoadAsync();
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            var p = Selected;
            if (p == null)
            {
                MessageBox.Show("Выберите родителя.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show($"Удалить родителя «{p.FullName}»?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

            try
            {
                await _repo.DeleteAsync(p.ParentID);
                await LoadAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Невозможно удалить (возможно, родитель привязан к записи):\n"
                    + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void grid_DoubleClick(object sender, EventArgs e) => btnEdit_Click(sender, e);
    }
}
