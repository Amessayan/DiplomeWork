using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Services;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Раздел «Администрирование» (только для администратора).
    /// Резервное копирование / восстановление БД и просмотр журнала аудита.
    /// </summary>
    public partial class AdminView : UserControl
    {
        private readonly ExportService _export = new ExportService();
        private readonly AuditRepository _audit = new AuditRepository();

        public AdminView()
        {
            InitializeComponent();
            StyleView();
        }

        private async void AdminView_Load(object sender, EventArgs e) => await LoadAuditAsync();

        private void StyleView()
        {
            BackColor = AppTheme.Beige;
            lblTitle.Font = AppTheme.H1;
            lblTitle.ForeColor = AppTheme.Bordeaux;
            lblBackupTitle.Font = AppTheme.H3;
            lblAuditTitle.Font = AppTheme.H3;
            UIHelper.StyleGrid(grid);
            UIHelper.StylePrimaryButton(btnBackup);
            UIHelper.StylePrimaryButton(btnRestore, false);
            UIHelper.StyleGoldButton(btnRefreshAudit);
        }

        private async System.Threading.Tasks.Task LoadAuditAsync()
        {
            try
            {
                List<AuditLog> logs = await _audit.GetRecentAsync(200);
                grid.Rows.Clear();
                foreach (var l in logs)
                {
                    grid.Rows.Add(
                        l.LogID,
                        l.ActionDate.ToString("dd.MM.yyyy HH:mm:ss"),
                        l.EmployeeName,
                        l.Action);
                }
                lblCount.Text = $"Записей в журнале: {logs.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки журнала:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnBackup_Click(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog
            {
                Filter = "Резервная копия (*.bak)|*.bak",
                FileName = $"ZAGS_KCHR_DB_{DateTime.Now:yyyyMMdd_HHmm}.bak"
            })
            {
                if (sfd.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Cursor = Cursors.WaitCursor;
                    await _export.BackupDatabaseAsync(sfd.FileName);
                    MessageBox.Show("Резервная копия создана:\n" + sfd.FileName,
                        "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка резервного копирования:\n" + ex.Message,
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally { Cursor = Cursors.Default; }
            }
        }

        private async void btnRestore_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(
                "Восстановление заменит текущие данные данными из копии. Продолжить?",
                "Подтверждение", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes) return;

            using (var ofd = new OpenFileDialog
            {
                Filter = "Резервная копия (*.bak)|*.bak"
            })
            {
                if (ofd.ShowDialog() != DialogResult.OK) return;
                try
                {
                    Cursor = Cursors.WaitCursor;
                    await _export.RestoreDatabaseAsync(ofd.FileName);
                    MessageBox.Show("База данных восстановлена.", "Готово",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    await LoadAuditAsync();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка восстановления:\n" + ex.Message,
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally { Cursor = Cursors.Default; }
            }
        }

        private async void btnRefreshAudit_Click(object sender, EventArgs e)
            => await LoadAuditAsync();
    }
}
