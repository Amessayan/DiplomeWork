using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Раздел «Отчёты». Формирует четыре аналитических отчёта:
    /// по месяцам, по полу, по сотрудникам, по местам рождения.
    /// Данные показываются таблицей и продублированы диаграммой.
    /// </summary>
    public partial class ReportsView : UserControl
    {
        private readonly ReportRepository _reports = new ReportRepository();
        private DataTable _current = new DataTable();

        public ReportsView()
        {
            InitializeComponent();
            BackColor = AppTheme.Beige;
            DoubleBuffered = true;
            lblTitle.Font = AppTheme.H1;
            lblTitle.ForeColor = AppTheme.Bordeaux;

            UIHelper.StyleGrid(grid);
            UIHelper.StylePrimaryButton(btnMonth);
            UIHelper.StylePrimaryButton(btnGender, false);
            UIHelper.StylePrimaryButton(btnEmployee, false);
            UIHelper.StylePrimaryButton(btnPlace, false);
        }

        private async void ReportsView_Load(object sender, EventArgs e)
            => await ShowReport(_reports.BirthsByMonthAsync(), "Рождения по месяцам");

        private async void btnMonth_Click(object sender, EventArgs e)
            => await ShowReport(_reports.BirthsByMonthAsync(), "Рождения по месяцам");

        private async void btnGender_Click(object sender, EventArgs e)
            => await ShowReport(_reports.ByGenderAsync(), "Рождения по полу");

        private async void btnEmployee_Click(object sender, EventArgs e)
            => await ShowReport(_reports.ByEmployeeAsync(), "Записи по сотрудникам");

        private async void btnPlace_Click(object sender, EventArgs e)
            => await ShowReport(_reports.ByPlaceAsync(), "Рождения по местам");

        /// <summary>Загружает отчёт, выводит его в таблицу и строит диаграмму.</summary>
        private async System.Threading.Tasks.Task ShowReport(
            System.Threading.Tasks.Task<DataTable> task, string title)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                _current = await task;
                lblReportName.Text = title;

                grid.DataSource = null;
                grid.DataSource = _current;
                grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                panelChart.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка формирования отчёта:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { Cursor = Cursors.Default; }
        }

        /// <summary>Рисует горизонтальную/столбчатую диаграмму по данным отчёта.</summary>
        private void panelChart_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            var rect = new Rectangle(0, 0, panelChart.Width - 1, panelChart.Height - 1);
            using (var path = UIHelper.RoundedRect(rect, 14))
            using (var bg = new SolidBrush(AppTheme.BeigeCard))
            using (var pen = new Pen(AppTheme.BorderColor, 1))
            {
                g.FillPath(bg, path);
                g.DrawPath(pen, path);
            }

            if (_current == null || _current.Rows.Count == 0 || _current.Columns.Count < 2)
            {
                using (var f = AppTheme.Body)
                using (var b = new SolidBrush(AppTheme.TextGray))
                    g.DrawString("Нет данных для диаграммы", f, b, 30, 40);
                return;
            }

            int valueCol = _current.Columns.Count - 1;
            int max = 1;
            foreach (DataRow r in _current.Rows)
            {
                if (int.TryParse(r[valueCol].ToString(), out int v) && v > max) max = v;
            }

            int top = 40, left = 180, right = 40;
            int rows = _current.Rows.Count;
            int barH = Math.Min(34, (panelChart.Height - top - 20) / Math.Max(rows, 1) - 10);
            int plotW = panelChart.Width - left - right;

            using (var barBrush = new SolidBrush(AppTheme.Bordeaux))
            using (var lblFont = AppTheme.Body)
            using (var lblBrush = new SolidBrush(AppTheme.TextDark))
            using (var valBrush = new SolidBrush(AppTheme.Gold))
            {
                for (int i = 0; i < rows; i++)
                {
                    var row = _current.Rows[i];
                    string label = row[0].ToString();
                    if (label.Length > 24) label = label.Substring(0, 24) + "…";
                    int.TryParse(row[valueCol].ToString(), out int v);

                    int y = top + i * (barH + 12);
                    float w = max == 0 ? 0 : (float)v / max * plotW;

                    // Подпись категории
                    g.DrawString(label, lblFont, lblBrush, 16, y + barH / 2 - 9);

                    // Столбец
                    using (var bp = UIHelper.RoundedRect(
                        new Rectangle(left, y, (int)Math.Max(w, 2), barH), 5))
                        g.FillPath(barBrush, bp);

                    // Значение
                    g.DrawString(v.ToString(), lblFont, valBrush, left + w + 8, y + barH / 2 - 9);
                }
            }
        }
    }
}
