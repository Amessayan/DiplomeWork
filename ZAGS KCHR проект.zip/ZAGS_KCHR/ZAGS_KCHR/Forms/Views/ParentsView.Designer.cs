namespace ZAGS_KCHR.Forms.Views
{
    partial class ParentsView
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaiden;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBirth;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPassport;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPhone;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCitizenship;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAddress;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblCount;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.grid = new System.Windows.Forms.DataGridView();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaiden = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBirth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPassport = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPhone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCitizenship = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblCount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(28, 22);
            this.lblTitle.Text = "Родители";
            //
            // txtSearch
            //
            this.txtSearch.Location = new System.Drawing.Point(28, 70);
            this.txtSearch.Size = new System.Drawing.Size(360, 27);
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // btnSearch
            //
            this.btnSearch.Location = new System.Drawing.Point(400, 68);
            this.btnSearch.Size = new System.Drawing.Size(110, 32);
            this.btnSearch.Text = "Поиск";
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            //
            // btnRefresh
            //
            this.btnRefresh.Location = new System.Drawing.Point(520, 68);
            this.btnRefresh.Size = new System.Drawing.Size(110, 32);
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            //
            // grid
            //
            this.grid.Location = new System.Drawing.Point(28, 112);
            this.grid.Size = new System.Drawing.Size(1128, 420);
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colId, this.colName, this.colMaiden, this.colBirth,
                this.colPassport, this.colPhone, this.colCitizenship, this.colAddress });
            this.grid.DoubleClick += new System.EventHandler(this.grid_DoubleClick);
            //
            this.colId.HeaderText = "ID";
            this.colId.FillWeight = 30F;
            this.colName.HeaderText = "ФИО";
            this.colName.FillWeight = 150F;
            this.colMaiden.HeaderText = "Девичья фамилия";
            this.colMaiden.FillWeight = 110F;
            this.colBirth.HeaderText = "Дата рождения";
            this.colBirth.FillWeight = 90F;
            this.colPassport.HeaderText = "Паспорт";
            this.colPassport.FillWeight = 90F;
            this.colPhone.HeaderText = "Телефон";
            this.colPhone.FillWeight = 90F;
            this.colCitizenship.HeaderText = "Гражданство";
            this.colCitizenship.FillWeight = 90F;
            this.colAddress.HeaderText = "Адрес";
            this.colAddress.FillWeight = 160F;
            //
            // btnAdd
            //
            this.btnAdd.Location = new System.Drawing.Point(28, 548);
            this.btnAdd.Size = new System.Drawing.Size(150, 44);
            this.btnAdd.Text = "Добавить";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            //
            // btnEdit
            //
            this.btnEdit.Location = new System.Drawing.Point(190, 548);
            this.btnEdit.Size = new System.Drawing.Size(150, 44);
            this.btnEdit.Text = "Редактировать";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            //
            // btnDelete
            //
            this.btnDelete.Location = new System.Drawing.Point(352, 548);
            this.btnDelete.Size = new System.Drawing.Size(150, 44);
            this.btnDelete.Text = "Удалить";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            //
            // lblCount
            //
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(540, 562);
            this.lblCount.Text = "Всего родителей: 0";
            //
            // ParentsView
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblCount);
            this.Name = "ParentsView";
            this.Size = new System.Drawing.Size(1200, 620);
            this.Load += new System.EventHandler(this.ParentsView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
