using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Раздел «Дашборд». Показывает ключевые показатели в виде карточек
    /// и столбчатую диаграмму рождений по месяцам (отрисовка вручную, без
    /// внешних библиотек — для максимальной переносимости проекта).
    /// </summary>
    public partial class DashboardView : UserControl
    {
        private readonly ReportRepository _reports = new ReportRepository();
        private DataTable _byMonth = new DataTable();

        public DashboardView()
        {
            InitializeComponent();
            BackColor = AppTheme.Beige;
            DoubleBuffered = true;
            lblTitle.Font = AppTheme.H1;
            lblTitle.ForeColor = AppTheme.Bordeaux;
            lblChartTitle.Font = AppTheme.H3;
            lblChartTitle.ForeColor = AppTheme.TextDark;
        }

        private async void DashboardView_Load(object sender, EventArgs e)
        {
            try
            {
                var stats = await _reports.GetDashboardStatsAsync();
                SetCard(cardTotal, "Всего записей", stats.total.ToString());
                SetCard(cardMonth, "За текущий месяц", stats.thisMonth.ToString());
                SetCard(cardMale, "Мальчиков", stats.male.ToString());
                SetCard(cardFemale, "Девочек", stats.female.ToString());

                _byMonth = await _reports.BirthsByMonthAsync();
                panelChart.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить статистику:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>Записывает значения в карточку показателя.</summary>
        private void SetCard(Panel card, string caption, string value)
        {
            // Tag хранит подпись и значение для отрисовки в Paint
            card.Tag = new[] { caption, value };
            card.Invalidate();
        }

        /// <summary>Отрисовка карточки показателя.</summary>
        private void Card_Paint(object sender, PaintEventArgs e)
        {
            var card = sender as Panel;
            if (card == null) return;
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            var rect = new Rectangle(0, 0, card.Width - 1, card.Height - 1);
            using (var path = UIHelper.RoundedRect(rect, 14))
            using (var bg = new SolidBrush(AppTheme.BeigeCard))
            using (var pen = new Pen(AppTheme.BorderColor, 1))
            {
                g.FillPath(bg, path);
                g.DrawPath(pen, path);
            }

            // Золотая полоса слева
            using (var goldBrush = new SolidBrush(AppTheme.Gold))
            using (var stripe = UIHelper.RoundedRect(new Rectangle(0, 0, 8, card.Height - 1), 4))
                g.FillPath(goldBrush, stripe);

            var data = card.Tag as string[];
            if (data == null) return;

            using (var capFont = AppTheme.Body)
            using (var valFont = new Font(AppTheme.FontFamily, 30F, FontStyle.Bold))
            using (var capBrush = new SolidBrush(AppTheme.TextGray))
            using (var valBrush = new SolidBrush(AppTheme.Bordeaux))
            {
                g.DrawString(data[0], capFont, capBrush, 24, 20);
                g.DrawString(data[1], valFont, valBrush, 22, 46);
            }
        }

        /// <summary>Отрисовка столбчатой диаграммы рождений по месяцам.</summary>
        private void panelChart_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            var rect = new Rectangle(0, 0, panelChart.Width - 1, panelChart.Height - 1);
            using (var path = UIHelper.RoundedRect(rect, 14))
            using (var bg = new SolidBrush(AppTheme.BeigeCard))
            using (var pen = new Pen(AppTheme.BorderColor, 1))
            {
                g.FillPath(bg, path);
                g.DrawPath(pen, path);
            }

            if (_byMonth == null || _byMonth.Rows.Count == 0)
            {
                using (var f = AppTheme.Body)
                using (var b = new SolidBrush(AppTheme.TextGray))
                    g.DrawString("Нет данных для отображения", f, b, 40, 60);
                return;
            }

            // Геометрия области графика
            int left = 50, right = 30, top = 50, bottom = 40;
            int plotW = panelChart.Width - left - right;
            int plotH = panelChart.Height - top - bottom;

            // Максимум для масштабирования
            int max = 1;
            foreach (DataRow r in _byMonth.Rows)
            {
                int v = Convert.ToInt32(r[r.Table.Columns.Count - 1]);
                if (v > max) max = v;
            }

            // Оси
            using (var axis = new Pen(AppTheme.BorderColor, 1.5f))
            {
                g.DrawLine(axis, left, top, left, top + plotH);
                g.DrawLine(axis, left, top + plotH, left + plotW, top + plotH);
            }

            int n = _byMonth.Rows.Count;
            float slot = (float)plotW / n;
            float barW = Math.Min(48, slot * 0.6f);

            using (var barBrush = new SolidBrush(AppTheme.Bordeaux))
            using (var lblFont = AppTheme.Small)
            using (var lblBrush = new SolidBrush(AppTheme.TextGray))
            using (var valBrush = new SolidBrush(AppTheme.Bordeaux))
            {
                for (int i = 0; i < n; i++)
                {
                    var row = _byMonth.Rows[i];
                    int v = Convert.ToInt32(row[row.Table.Columns.Count - 1]);
                    string label = row[0].ToString();
                    if (label.Length > 7) label = label.Substring(0, 7);

                    float h = max == 0 ? 0 : (float)v / max * (plotH - 10);
                    float x = left + slot * i + (slot - barW) / 2;
                    float y = top + plotH - h;

                    using (var barPath = UIHelper.RoundedRect(
                        new Rectangle((int)x, (int)y, (int)barW, (int)h), 4))
                        g.FillPath(barBrush, barPath);

                    // Значение над столбцом
                    var vs = v.ToString();
                    var vsz = g.MeasureString(vs, lblFont);
                    g.DrawString(vs, lblFont, valBrush, x + barW / 2 - vsz.Width / 2, y - 16);

                    // Подпись месяца
                    var lsz = g.MeasureString(label, lblFont);
                    g.DrawString(label, lblFont, lblBrush,
                        x + barW / 2 - lsz.Width / 2, top + plotH + 6);
                }
            }
        }
    }
}
