namespace ZAGS_KCHR.Forms.Views
{
    partial class DashboardView
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel cardTotal;
        private System.Windows.Forms.Panel cardMonth;
        private System.Windows.Forms.Panel cardMale;
        private System.Windows.Forms.Panel cardFemale;
        private System.Windows.Forms.Label lblChartTitle;
        private System.Windows.Forms.Panel panelChart;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.cardTotal = new System.Windows.Forms.Panel();
            this.cardMonth = new System.Windows.Forms.Panel();
            this.cardMale = new System.Windows.Forms.Panel();
            this.cardFemale = new System.Windows.Forms.Panel();
            this.lblChartTitle = new System.Windows.Forms.Label();
            this.panelChart = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(28, 22);
            this.lblTitle.Text = "Дашборд";
            //
            // cardTotal
            //
            this.cardTotal.Location = new System.Drawing.Point(28, 70);
            this.cardTotal.Size = new System.Drawing.Size(270, 120);
            this.cardTotal.Paint += new System.Windows.Forms.PaintEventHandler(this.Card_Paint);
            //
            // cardMonth
            //
            this.cardMonth.Location = new System.Drawing.Point(314, 70);
            this.cardMonth.Size = new System.Drawing.Size(270, 120);
            this.cardMonth.Paint += new System.Windows.Forms.PaintEventHandler(this.Card_Paint);
            //
            // cardMale
            //
            this.cardMale.Location = new System.Drawing.Point(600, 70);
            this.cardMale.Size = new System.Drawing.Size(270, 120);
            this.cardMale.Paint += new System.Windows.Forms.PaintEventHandler(this.Card_Paint);
            //
            // cardFemale
            //
            this.cardFemale.Location = new System.Drawing.Point(886, 70);
            this.cardFemale.Size = new System.Drawing.Size(270, 120);
            this.cardFemale.Paint += new System.Windows.Forms.PaintEventHandler(this.Card_Paint);
            //
            // lblChartTitle
            //
            this.lblChartTitle.AutoSize = true;
            this.lblChartTitle.Location = new System.Drawing.Point(28, 214);
            this.lblChartTitle.Text = "Рождения по месяцам";
            //
            // panelChart
            //
            this.panelChart.Location = new System.Drawing.Point(28, 240);
            this.panelChart.Size = new System.Drawing.Size(1128, 360);
            this.panelChart.Paint += new System.Windows.Forms.PaintEventHandler(this.panelChart_Paint);
            //
            // DashboardView
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.cardTotal);
            this.Controls.Add(this.cardMonth);
            this.Controls.Add(this.cardMale);
            this.Controls.Add(this.cardFemale);
            this.Controls.Add(this.lblChartTitle);
            this.Controls.Add(this.panelChart);
            this.Name = "DashboardView";
            this.Size = new System.Drawing.Size(1200, 640);
            this.Load += new System.EventHandler(this.DashboardView_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
