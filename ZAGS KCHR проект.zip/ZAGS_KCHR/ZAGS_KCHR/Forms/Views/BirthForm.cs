using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Services;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Диалоговая форма создания/редактирования записи о рождении.
    /// Содержит все поля согласно техническому заданию.
    /// </summary>
    public partial class BirthForm : Form
    {
        private readonly BirthService _service = new BirthService();
        private readonly ParentRepository _parents = new ParentRepository();

        private readonly BirthRecord _record;
        private List<Parent> _parentList = new List<Parent>();

        /// <summary>Конструктор для создания новой записи.</summary>
        public BirthForm() : this(null) { }

        /// <summary>Конструктор для редактирования существующей записи.</summary>
        public BirthForm(BirthRecord record)
        {
            InitializeComponent();
            _record = record;
            StyleForm();
        }

        private async void BirthForm_Load(object sender, EventArgs e)
        {
            await LoadParentsAsync();
            cmbGender.SelectedIndex = 0;

            if (_record != null)
            {
                Text = "Редактирование записи о рождении";
                FillFromRecord();
            }
            else
            {
                Text = "Новая запись о рождении";
                dtBirthDate.Value = DateTime.Today;
            }
        }

        private void StyleForm()
        {
            BackColor = AppTheme.Beige;
            UIHelper.StylePrimaryButton(btnSave);
            UIHelper.StylePrimaryButton(btnCancel, false);
            lblHeader.ForeColor = AppTheme.Bordeaux;
            lblHeader.Font = AppTheme.H2;
        }

        /// <summary>Загружает список родителей в выпадающие списки.</summary>
        private async System.Threading.Tasks.Task LoadParentsAsync()
        {
            try
            {
                _parentList = await _parents.GetAllAsync();

                cmbMother.Items.Clear();
                cmbFather.Items.Clear();
                cmbMother.Items.Add("(не указана)");
                cmbFather.Items.Add("(не указан)");
                foreach (var p in _parentList)
                {
                    cmbMother.Items.Add(p);
                    cmbFather.Items.Add(p);
                }
                cmbMother.SelectedIndex = 0;
                cmbFather.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить список родителей:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>Заполняет поля формы данными редактируемой записи.</summary>
        private void FillFromRecord()
        {
            txtLastName.Text = _record.ChildLastName;
            txtFirstName.Text = _record.ChildFirstName;
            txtMiddleName.Text = _record.ChildMiddleName;
            dtBirthDate.Value = _record.BirthDate == default(DateTime) ? DateTime.Today : _record.BirthDate;
            if (_record.BirthTime.HasValue)
            {
                dtBirthTime.Value = DateTime.Today.Add(_record.BirthTime.Value);
            }
            txtPlace.Text = _record.BirthPlace;
            cmbGender.SelectedIndex = _record.Gender == "Женский" ? 1 : 0;
            if (_record.Weight.HasValue) numWeight.Value = _record.Weight.Value;
            if (_record.Height.HasValue) numHeight.Value = _record.Height.Value;

            SelectParent(cmbMother, _record.MotherID);
            SelectParent(cmbFather, _record.FatherID);
        }

        private void SelectParent(ComboBox cmb, int? parentId)
        {
            if (!parentId.HasValue) { cmb.SelectedIndex = 0; return; }
            for (int i = 1; i < cmb.Items.Count; i++)
            {
                if (cmb.Items[i] is Parent p && p.ParentID == parentId.Value)
                {
                    cmb.SelectedIndex = i; return;
                }
            }
            cmb.SelectedIndex = 0;
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            var rec = _record ?? new BirthRecord();
            rec.ChildLastName = txtLastName.Text.Trim();
            rec.ChildFirstName = txtFirstName.Text.Trim();
            rec.ChildMiddleName = txtMiddleName.Text.Trim();
            rec.BirthDate = dtBirthDate.Value.Date;
            rec.BirthTime = dtBirthTime.Value.TimeOfDay;
            rec.BirthPlace = txtPlace.Text.Trim();
            rec.Gender = cmbGender.SelectedIndex == 1 ? "Женский" : "Мужской";
            rec.Weight = numWeight.Value > 0 ? numWeight.Value : (decimal?)null;
            rec.Height = numHeight.Value > 0 ? numHeight.Value : (decimal?)null;
            rec.MotherID = (cmbMother.SelectedItem as Parent)?.ParentID;
            rec.FatherID = (cmbFather.SelectedItem as Parent)?.ParentID;

            // Валидация через бизнес-логику
            string error = _service.Validate(rec);
            if (error != null)
            {
                MessageBox.Show(error, "Проверка данных",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                btnSave.Enabled = false;
                await _service.SaveAsync(rec);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = true;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
