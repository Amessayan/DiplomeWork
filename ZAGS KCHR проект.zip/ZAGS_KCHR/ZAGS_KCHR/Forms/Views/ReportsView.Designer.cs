namespace ZAGS_KCHR.Forms.Views
{
    partial class ReportsView
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnMonth;
        private System.Windows.Forms.Button btnGender;
        private System.Windows.Forms.Button btnEmployee;
        private System.Windows.Forms.Button btnPlace;
        private System.Windows.Forms.Label lblReportName;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.Panel panelChart;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnMonth = new System.Windows.Forms.Button();
            this.btnGender = new System.Windows.Forms.Button();
            this.btnEmployee = new System.Windows.Forms.Button();
            this.btnPlace = new System.Windows.Forms.Button();
            this.lblReportName = new System.Windows.Forms.Label();
            this.grid = new System.Windows.Forms.DataGridView();
            this.panelChart = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(28, 22);
            this.lblTitle.Text = "Отчёты";
            //
            // btnMonth
            //
            this.btnMonth.Location = new System.Drawing.Point(28, 64);
            this.btnMonth.Size = new System.Drawing.Size(180, 40);
            this.btnMonth.Text = "По месяцам";
            this.btnMonth.Click += new System.EventHandler(this.btnMonth_Click);
            //
            // btnGender
            //
            this.btnGender.Location = new System.Drawing.Point(220, 64);
            this.btnGender.Size = new System.Drawing.Size(180, 40);
            this.btnGender.Text = "По полу";
            this.btnGender.Click += new System.EventHandler(this.btnGender_Click);
            //
            // btnEmployee
            //
            this.btnEmployee.Location = new System.Drawing.Point(412, 64);
            this.btnEmployee.Size = new System.Drawing.Size(180, 40);
            this.btnEmployee.Text = "По сотрудникам";
            this.btnEmployee.Click += new System.EventHandler(this.btnEmployee_Click);
            //
            // btnPlace
            //
            this.btnPlace.Location = new System.Drawing.Point(604, 64);
            this.btnPlace.Size = new System.Drawing.Size(180, 40);
            this.btnPlace.Text = "По местам";
            this.btnPlace.Click += new System.EventHandler(this.btnPlace_Click);
            //
            // lblReportName
            //
            this.lblReportName.AutoSize = true;
            this.lblReportName.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblReportName.Location = new System.Drawing.Point(28, 122);
            this.lblReportName.Text = "—";
            //
            // grid
            //
            this.grid.Location = new System.Drawing.Point(28, 150);
            this.grid.Size = new System.Drawing.Size(540, 430);
            this.grid.ReadOnly = true;
            this.grid.AllowUserToAddRows = false;
            //
            // panelChart
            //
            this.panelChart.Location = new System.Drawing.Point(588, 150);
            this.panelChart.Size = new System.Drawing.Size(568, 430);
            this.panelChart.Paint += new System.Windows.Forms.PaintEventHandler(this.panelChart_Paint);
            //
            // ReportsView
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnMonth);
            this.Controls.Add(this.btnGender);
            this.Controls.Add(this.btnEmployee);
            this.Controls.Add(this.btnPlace);
            this.Controls.Add(this.lblReportName);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.panelChart);
            this.Name = "ReportsView";
            this.Size = new System.Drawing.Size(1200, 620);
            this.Load += new System.EventHandler(this.ReportsView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
