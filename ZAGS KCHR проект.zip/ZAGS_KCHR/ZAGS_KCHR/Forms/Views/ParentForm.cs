using System;
using System.Windows.Forms;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Диалог создания/редактирования данных родителя.
    /// </summary>
    public partial class ParentForm : Form
    {
        private readonly ParentRepository _repo = new ParentRepository();
        private readonly Parent _parent;

        public ParentForm() : this(null) { }

        public ParentForm(Parent parent)
        {
            InitializeComponent();
            _parent = parent;
            BackColor = AppTheme.Beige;
            UIHelper.StylePrimaryButton(btnSave);
            UIHelper.StylePrimaryButton(btnCancel, false);
            lblHeader.ForeColor = AppTheme.Bordeaux;
            lblHeader.Font = AppTheme.H2;
        }

        private void ParentForm_Load(object sender, EventArgs e)
        {
            chkBirthDate.Checked = false;
            dtBirthDate.Enabled = false;

            if (_parent != null)
            {
                Text = "Редактирование родителя";
                txtFullName.Text = _parent.FullName;
                txtMaiden.Text = _parent.MaidenName;
                if (_parent.BirthDate.HasValue)
                {
                    chkBirthDate.Checked = true;
                    dtBirthDate.Enabled = true;
                    dtBirthDate.Value = _parent.BirthDate.Value;
                }
                txtPassport.Text = _parent.Passport;
                txtPhone.Text = _parent.Phone;
                txtCitizenship.Text = _parent.Citizenship;
                txtAddress.Text = _parent.Address;
            }
            else
            {
                Text = "Новый родитель";
                txtCitizenship.Text = "РФ";
            }
        }

        private void chkBirthDate_CheckedChanged(object sender, EventArgs e)
            => dtBirthDate.Enabled = chkBirthDate.Checked;

        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                MessageBox.Show("Укажите ФИО родителя.", "Проверка данных",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var p = _parent ?? new Parent();
            p.FullName = txtFullName.Text.Trim();
            p.MaidenName = txtMaiden.Text.Trim();
            p.BirthDate = chkBirthDate.Checked ? dtBirthDate.Value.Date : (DateTime?)null;
            p.Passport = txtPassport.Text.Trim();
            p.Phone = txtPhone.Text.Trim();
            p.Citizenship = txtCitizenship.Text.Trim();
            p.Address = txtAddress.Text.Trim();

            try
            {
                btnSave.Enabled = false;
                if (p.ParentID == 0) await _repo.AddAsync(p);
                else await _repo.UpdateAsync(p);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = true;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
