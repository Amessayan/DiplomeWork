namespace ZAGS_KCHR.Forms.Views
{
    partial class AdminView
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblBackupTitle;
        private System.Windows.Forms.Button btnBackup;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Label lblAuditTitle;
        private System.Windows.Forms.Button btnRefreshAudit;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colUser;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAction;
        private System.Windows.Forms.Label lblCount;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblBackupTitle = new System.Windows.Forms.Label();
            this.btnBackup = new System.Windows.Forms.Button();
            this.btnRestore = new System.Windows.Forms.Button();
            this.lblAuditTitle = new System.Windows.Forms.Label();
            this.btnRefreshAudit = new System.Windows.Forms.Button();
            this.grid = new System.Windows.Forms.DataGridView();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colUser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(28, 22);
            this.lblTitle.Text = "Администрирование";
            //
            // lblBackupTitle
            //
            this.lblBackupTitle.AutoSize = true;
            this.lblBackupTitle.Location = new System.Drawing.Point(28, 70);
            this.lblBackupTitle.Text = "Резервное копирование базы данных";
            //
            // btnBackup
            //
            this.btnBackup.Location = new System.Drawing.Point(28, 100);
            this.btnBackup.Size = new System.Drawing.Size(240, 44);
            this.btnBackup.Text = "Создать резервную копию";
            this.btnBackup.Click += new System.EventHandler(this.btnBackup_Click);
            //
            // btnRestore
            //
            this.btnRestore.Location = new System.Drawing.Point(284, 100);
            this.btnRestore.Size = new System.Drawing.Size(240, 44);
            this.btnRestore.Text = "Восстановить из копии";
            this.btnRestore.Click += new System.EventHandler(this.btnRestore_Click);
            //
            // lblAuditTitle
            //
            this.lblAuditTitle.AutoSize = true;
            this.lblAuditTitle.Location = new System.Drawing.Point(28, 168);
            this.lblAuditTitle.Text = "Журнал действий (аудит)";
            //
            // btnRefreshAudit
            //
            this.btnRefreshAudit.Location = new System.Drawing.Point(320, 162);
            this.btnRefreshAudit.Size = new System.Drawing.Size(140, 32);
            this.btnRefreshAudit.Text = "Обновить";
            this.btnRefreshAudit.Click += new System.EventHandler(this.btnRefreshAudit_Click);
            //
            // grid
            //
            this.grid.Location = new System.Drawing.Point(28, 204);
            this.grid.Size = new System.Drawing.Size(1128, 360);
            this.grid.ReadOnly = true;
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colId, this.colDate, this.colUser, this.colAction });
            //
            this.colId.HeaderText = "ID";
            this.colId.FillWeight = 30F;
            this.colDate.HeaderText = "Дата и время";
            this.colDate.FillWeight = 100F;
            this.colUser.HeaderText = "Пользователь";
            this.colUser.FillWeight = 120F;
            this.colAction.HeaderText = "Действие";
            this.colAction.FillWeight = 320F;
            //
            // lblCount
            //
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(28, 574);
            this.lblCount.Text = "Записей в журнале: 0";
            //
            // AdminView
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblBackupTitle);
            this.Controls.Add(this.btnBackup);
            this.Controls.Add(this.btnRestore);
            this.Controls.Add(this.lblAuditTitle);
            this.Controls.Add(this.btnRefreshAudit);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.lblCount);
            this.Name = "AdminView";
            this.Size = new System.Drawing.Size(1200, 600);
            this.Load += new System.EventHandler(this.AdminView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
