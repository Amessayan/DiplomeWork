using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Services;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Главный раздел «Записи о рождениях».
    /// Содержит панель поиска и фильтров, таблицу записей, ряд кнопок действий,
    /// а также информационные панели с примером SQL-запроса и схемой БД
    /// (как на утверждённом макете интерфейса).
    /// </summary>
    public partial class BirthsView : UserControl
    {
        private readonly BirthService _service = new BirthService();
        private readonly PrintService _print = new PrintService();
        private readonly ExportService _export = new ExportService();

        private List<BirthRecord> _records = new List<BirthRecord>();

        public BirthsView()
        {
            InitializeComponent();
            StyleView();
        }

        private async void BirthsView_Load(object sender, EventArgs e)
        {
            await LoadDataAsync();
        }

        /// <summary>Применяет фирменное оформление ко всем элементам раздела.</summary>
        private void StyleView()
        {
            BackColor = AppTheme.Beige;

            lblTitle.Font = AppTheme.H1;
            lblTitle.ForeColor = AppTheme.Bordeaux;

            // Стилизация таблицы
            UIHelper.StyleGrid(grid);

            // Кнопки действий
            UIHelper.StylePrimaryButton(btnAdd);
            UIHelper.StylePrimaryButton(btnEdit, false);
            UIHelper.StylePrimaryButton(btnDelete, false);
            UIHelper.StylePrimaryButton(btnCertificate, false);
            UIHelper.StylePrimaryButton(btnPrint, false);
            UIHelper.StyleGoldButton(btnExportExcel);
            UIHelper.StyleGoldButton(btnExportCsv);
            UIHelper.StyleGoldButton(btnExportSql);

            UIHelper.StylePrimaryButton(btnSearch);
            UIHelper.StyleGoldButton(btnReset);
        }

        /// <summary>Загружает записи из БД с учётом фильтров.</summary>
        private async System.Threading.Tasks.Task LoadDataAsync()
        {
            try
            {
                Cursor = Cursors.WaitCursor;

                string search = txtSearch.Text?.Trim();
                if (string.IsNullOrWhiteSpace(search)) search = null;

                DateTime? from = chkDateFilter.Checked ? dtFrom.Value.Date : (DateTime?)null;
                DateTime? to = chkDateFilter.Checked ? dtTo.Value.Date : (DateTime?)null;

                string gender = null;
                if (cmbGender.SelectedIndex == 1) gender = "Мужской";
                else if (cmbGender.SelectedIndex == 2) gender = "Женский";

                _records = await _service.SearchAsync(search, from, to, gender);

                // Доп. фильтр по месту рождения (выполняется на стороне клиента)
                string place = txtPlace.Text?.Trim();
                if (!string.IsNullOrWhiteSpace(place))
                {
                    _records = _records
                        .Where(r => (r.BirthPlace ?? "").IndexOf(place, StringComparison.OrdinalIgnoreCase) >= 0)
                        .ToList();
                }

                BindGrid();
                lblCount.Text = $"Найдено записей: {_records.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить данные:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        /// <summary>Заполняет таблицу данными.</summary>
        private void BindGrid()
        {
            grid.Rows.Clear();
            int i = 1;
            foreach (var r in _records)
            {
                int idx = grid.Rows.Add(
                    i++,
                    r.ChildFullName,
                    r.BirthDateTimeText,
                    r.BirthPlace,
                    r.MotherName,
                    r.FatherName,
                    r.CertificateFullNumber);
                grid.Rows[idx].Tag = r;
            }
        }

        /// <summary>Возвращает выделенную запись или null.</summary>
        private BirthRecord SelectedRecord =>
            grid.SelectedRows.Count > 0 ? grid.SelectedRows[0].Tag as BirthRecord : null;

        // --- Обработчики панели поиска ---

        private async void btnSearch_Click(object sender, EventArgs e) => await LoadDataAsync();

        private async void btnReset_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            txtPlace.Clear();
            chkDateFilter.Checked = false;
            cmbGender.SelectedIndex = 0;
            await LoadDataAsync();
        }

        private async void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; await LoadDataAsync(); }
        }

        // --- Кнопки действий ---

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            using (var f = new BirthForm())
            {
                if (f.ShowDialog() == DialogResult.OK) await LoadDataAsync();
            }
        }

        private async void btnEdit_Click(object sender, EventArgs e)
        {
            var rec = SelectedRecord;
            if (rec == null) { Warn("Выберите запись для редактирования."); return; }

            using (var f = new BirthForm(rec))
            {
                if (f.ShowDialog() == DialogResult.OK) await LoadDataAsync();
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            var rec = SelectedRecord;
            if (rec == null) { Warn("Выберите запись для удаления."); return; }

            if (MessageBox.Show($"Удалить запись о рождении «{rec.ChildFullName}»?",
                "Подтверждение удаления", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes) return;

            try
            {
                await _service.DeleteAsync(rec);
                await LoadDataAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnCertificate_Click(object sender, EventArgs e)
        {
            var rec = SelectedRecord;
            if (rec == null) { Warn("Выберите запись для формирования свидетельства."); return; }

            if (!string.IsNullOrEmpty(rec.CertNumber))
            {
                if (MessageBox.Show("Для этой записи уже есть свидетельство. Сформировать новое?",
                    "Свидетельство", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) != DialogResult.Yes) return;
            }

            try
            {
                var cert = await _service.GenerateCertificateAsync(rec);
                MessageBox.Show($"Свидетельство сформировано:\n{cert.FullNumber}",
                    "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
                await LoadDataAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка формирования свидетельства:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            var rec = SelectedRecord;
            if (rec == null) { Warn("Выберите запись для печати."); return; }
            if (string.IsNullOrEmpty(rec.CertNumber))
            {
                Warn("Сначала сформируйте свидетельство для этой записи."); return;
            }

            try { _print.PreviewCertificate(rec); }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка печати:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExportExcel_Click(object sender, EventArgs e) => Export("excel");
        private void btnExportCsv_Click(object sender, EventArgs e) => Export("csv");
        private void btnExportSql_Click(object sender, EventArgs e) => Export("sql");

        /// <summary>Универсальный экспорт данных в выбранный формат.</summary>
        private async void Export(string kind)
        {
            try
            {
                using (var sfd = new SaveFileDialog())
                {
                    switch (kind)
                    {
                        case "excel":
                            sfd.Filter = "Excel XML (*.xls)|*.xls";
                            sfd.FileName = "Записи_о_рождениях.xls";
                            break;
                        case "csv":
                            sfd.Filter = "CSV (*.csv)|*.csv";
                            sfd.FileName = "Записи_о_рождениях.csv";
                            break;
                        case "sql":
                            sfd.Filter = "Резервная копия БД (*.bak)|*.bak";
                            sfd.FileName = "ZAGS_KCHR_DB.bak";
                            break;
                    }

                    if (sfd.ShowDialog() != DialogResult.OK) return;

                    Cursor = Cursors.WaitCursor;
                    switch (kind)
                    {
                        case "excel": _export.ExportBirthsToExcel(_records, sfd.FileName); break;
                        case "csv": _export.ExportBirthsToCsv(_records, sfd.FileName); break;
                        case "sql": await _export.BackupDatabaseAsync(sfd.FileName); break;
                    }

                    MessageBox.Show("Экспорт выполнен успешно:\n" + sfd.FileName,
                        "Экспорт", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка экспорта:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { Cursor = Cursors.Default; }
        }

        private void grid_DoubleClick(object sender, EventArgs e) => btnEdit_Click(sender, e);

        private void Warn(string text) =>
            MessageBox.Show(text, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);

        // --- Отрисовка карточек-подсказок (SQL и схема БД) как на макете ---

        private void panelSqlCard_Paint(object sender, PaintEventArgs e)
            => DrawCard(sender as Control, e);

        private void panelSchemaCard_Paint(object sender, PaintEventArgs e)
            => DrawCard(sender as Control, e);

        private void DrawCard(Control card, PaintEventArgs e)
        {
            if (card == null) return;
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, card.Width - 1, card.Height - 1);
            using (var path = UIHelper.RoundedRect(rect, 12))
            using (var bg = new SolidBrush(AppTheme.BeigeCard))
            using (var pen = new Pen(AppTheme.BorderColor, 1))
            {
                g.FillPath(bg, path);
                g.DrawPath(pen, path);
            }
        }
    }
}
