namespace ZAGS_KCHR.Forms.Views
{
    partial class BirthsView
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panelFilters;
        private System.Windows.Forms.Label lblSearchCap;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.CheckBox chkDateFilter;
        private System.Windows.Forms.DateTimePicker dtFrom;
        private System.Windows.Forms.Label lblDateSep;
        private System.Windows.Forms.DateTimePicker dtTo;
        private System.Windows.Forms.Label lblPlaceCap;
        private System.Windows.Forms.TextBox txtPlace;
        private System.Windows.Forms.Label lblGenderCap;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnReset;

        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colChild;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBirth;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPlace;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMother;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFather;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCert;

        private System.Windows.Forms.Panel panelActions;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCertificate;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.Button btnExportCsv;
        private System.Windows.Forms.Button btnExportSql;
        private System.Windows.Forms.Label lblCount;

        private System.Windows.Forms.Panel panelSqlCard;
        private System.Windows.Forms.Label lblSqlTitle;
        private System.Windows.Forms.TextBox txtSql;
        private System.Windows.Forms.Panel panelSchemaCard;
        private System.Windows.Forms.Label lblSchemaTitle;
        private System.Windows.Forms.Label lblSchema;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelFilters = new System.Windows.Forms.Panel();
            this.lblSearchCap = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.chkDateFilter = new System.Windows.Forms.CheckBox();
            this.dtFrom = new System.Windows.Forms.DateTimePicker();
            this.lblDateSep = new System.Windows.Forms.Label();
            this.dtTo = new System.Windows.Forms.DateTimePicker();
            this.lblPlaceCap = new System.Windows.Forms.Label();
            this.txtPlace = new System.Windows.Forms.TextBox();
            this.lblGenderCap = new System.Windows.Forms.Label();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.grid = new System.Windows.Forms.DataGridView();
            this.colNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colChild = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBirth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPlace = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMother = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFather = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCert = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelActions = new System.Windows.Forms.Panel();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnCertificate = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnExportCsv = new System.Windows.Forms.Button();
            this.btnExportSql = new System.Windows.Forms.Button();
            this.lblCount = new System.Windows.Forms.Label();
            this.panelSqlCard = new System.Windows.Forms.Panel();
            this.lblSqlTitle = new System.Windows.Forms.Label();
            this.txtSql = new System.Windows.Forms.TextBox();
            this.panelSchemaCard = new System.Windows.Forms.Panel();
            this.lblSchemaTitle = new System.Windows.Forms.Label();
            this.lblSchema = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(28, 22);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "Записи о рождениях";
            //
            // panelFilters
            //
            this.panelFilters.Location = new System.Drawing.Point(28, 64);
            this.panelFilters.Name = "panelFilters";
            this.panelFilters.Size = new System.Drawing.Size(1180, 78);
            this.panelFilters.Controls.Add(this.lblSearchCap);
            this.panelFilters.Controls.Add(this.txtSearch);
            this.panelFilters.Controls.Add(this.chkDateFilter);
            this.panelFilters.Controls.Add(this.dtFrom);
            this.panelFilters.Controls.Add(this.lblDateSep);
            this.panelFilters.Controls.Add(this.dtTo);
            this.panelFilters.Controls.Add(this.lblPlaceCap);
            this.panelFilters.Controls.Add(this.txtPlace);
            this.panelFilters.Controls.Add(this.lblGenderCap);
            this.panelFilters.Controls.Add(this.cmbGender);
            this.panelFilters.Controls.Add(this.btnSearch);
            this.panelFilters.Controls.Add(this.btnReset);
            //
            // lblSearchCap
            //
            this.lblSearchCap.AutoSize = true;
            this.lblSearchCap.Location = new System.Drawing.Point(2, 6);
            this.lblSearchCap.Text = "Поиск";
            //
            // txtSearch
            //
            this.txtSearch.Location = new System.Drawing.Point(4, 30);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(330, 27);
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            //
            // chkDateFilter
            //
            this.chkDateFilter.AutoSize = true;
            this.chkDateFilter.Location = new System.Drawing.Point(350, 8);
            this.chkDateFilter.Text = "Дата рождения";
            //
            // dtFrom
            //
            this.dtFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtFrom.Location = new System.Drawing.Point(352, 30);
            this.dtFrom.Size = new System.Drawing.Size(120, 27);
            this.dtFrom.Value = new System.DateTime(2024, 1, 1, 0, 0, 0, 0);
            //
            // lblDateSep
            //
            this.lblDateSep.AutoSize = true;
            this.lblDateSep.Location = new System.Drawing.Point(478, 34);
            this.lblDateSep.Text = "по";
            //
            // dtTo
            //
            this.dtTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtTo.Location = new System.Drawing.Point(504, 30);
            this.dtTo.Size = new System.Drawing.Size(120, 27);
            this.dtTo.Value = new System.DateTime(2024, 12, 31, 0, 0, 0, 0);
            //
            // lblPlaceCap
            //
            this.lblPlaceCap.AutoSize = true;
            this.lblPlaceCap.Location = new System.Drawing.Point(642, 6);
            this.lblPlaceCap.Text = "Место рождения";
            //
            // txtPlace
            //
            this.txtPlace.Location = new System.Drawing.Point(644, 30);
            this.txtPlace.Name = "txtPlace";
            this.txtPlace.Size = new System.Drawing.Size(170, 27);
            this.txtPlace.Font = new System.Drawing.Font("Segoe UI", 10F);
            //
            // lblGenderCap
            //
            this.lblGenderCap.AutoSize = true;
            this.lblGenderCap.Location = new System.Drawing.Point(824, 6);
            this.lblGenderCap.Text = "Пол ребёнка";
            //
            // cmbGender
            //
            this.cmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGender.Location = new System.Drawing.Point(826, 30);
            this.cmbGender.Size = new System.Drawing.Size(120, 28);
            this.cmbGender.Items.AddRange(new object[] { "Все", "Мужской", "Женский" });
            this.cmbGender.SelectedIndex = 0;
            //
            // btnSearch
            //
            this.btnSearch.Location = new System.Drawing.Point(966, 28);
            this.btnSearch.Size = new System.Drawing.Size(100, 32);
            this.btnSearch.Text = "Найти";
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            //
            // btnReset
            //
            this.btnReset.Location = new System.Drawing.Point(1074, 28);
            this.btnReset.Size = new System.Drawing.Size(100, 32);
            this.btnReset.Text = "Сбросить";
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            //
            // grid
            //
            this.grid.Location = new System.Drawing.Point(28, 152);
            this.grid.Name = "grid";
            this.grid.Size = new System.Drawing.Size(1180, 250);
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colNo, this.colChild, this.colBirth, this.colPlace,
                this.colMother, this.colFather, this.colCert });
            this.grid.DoubleClick += new System.EventHandler(this.grid_DoubleClick);
            //
            this.colNo.HeaderText = "№";
            this.colNo.FillWeight = 35F;
            this.colChild.HeaderText = "ФИО ребёнка";
            this.colChild.FillWeight = 160F;
            this.colBirth.HeaderText = "Дата и время рождения";
            this.colBirth.FillWeight = 130F;
            this.colPlace.HeaderText = "Место рождения";
            this.colPlace.FillWeight = 150F;
            this.colMother.HeaderText = "ФИО матери";
            this.colMother.FillWeight = 160F;
            this.colFather.HeaderText = "ФИО отца";
            this.colFather.FillWeight = 160F;
            this.colCert.HeaderText = "№ свидетельства";
            this.colCert.FillWeight = 120F;
            //
            // panelActions
            //
            this.panelActions.Location = new System.Drawing.Point(28, 414);
            this.panelActions.Name = "panelActions";
            this.panelActions.Size = new System.Drawing.Size(1180, 96);
            this.panelActions.Controls.Add(this.btnAdd);
            this.panelActions.Controls.Add(this.btnEdit);
            this.panelActions.Controls.Add(this.btnDelete);
            this.panelActions.Controls.Add(this.btnCertificate);
            this.panelActions.Controls.Add(this.btnPrint);
            this.panelActions.Controls.Add(this.btnExportExcel);
            this.panelActions.Controls.Add(this.btnExportCsv);
            this.panelActions.Controls.Add(this.btnExportSql);
            this.panelActions.Controls.Add(this.lblCount);
            //
            // btnAdd
            //
            this.btnAdd.Location = new System.Drawing.Point(0, 0);
            this.btnAdd.Size = new System.Drawing.Size(150, 64);
            this.btnAdd.Text = "Добавить запись";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            //
            // btnEdit
            //
            this.btnEdit.Location = new System.Drawing.Point(162, 0);
            this.btnEdit.Size = new System.Drawing.Size(140, 64);
            this.btnEdit.Text = "Редактировать";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            //
            // btnDelete
            //
            this.btnDelete.Location = new System.Drawing.Point(314, 0);
            this.btnDelete.Size = new System.Drawing.Size(120, 64);
            this.btnDelete.Text = "Удалить";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            //
            // btnCertificate
            //
            this.btnCertificate.Location = new System.Drawing.Point(446, 0);
            this.btnCertificate.Size = new System.Drawing.Size(170, 64);
            this.btnCertificate.Text = "Сформировать\nсвидетельство";
            this.btnCertificate.Click += new System.EventHandler(this.btnCertificate_Click);
            //
            // btnPrint
            //
            this.btnPrint.Location = new System.Drawing.Point(628, 0);
            this.btnPrint.Size = new System.Drawing.Size(120, 64);
            this.btnPrint.Text = "Печать";
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            //
            // btnExportExcel
            //
            this.btnExportExcel.Location = new System.Drawing.Point(760, 0);
            this.btnExportExcel.Size = new System.Drawing.Size(130, 64);
            this.btnExportExcel.Text = "Экспорт в Excel";
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            //
            // btnExportCsv
            //
            this.btnExportCsv.Location = new System.Drawing.Point(902, 0);
            this.btnExportCsv.Size = new System.Drawing.Size(120, 64);
            this.btnExportCsv.Text = "Экспорт в CSV";
            this.btnExportCsv.Click += new System.EventHandler(this.btnExportCsv_Click);
            //
            // btnExportSql
            //
            this.btnExportSql.Location = new System.Drawing.Point(1034, 0);
            this.btnExportSql.Size = new System.Drawing.Size(140, 64);
            this.btnExportSql.Text = "Экспорт в SQL";
            this.btnExportSql.Click += new System.EventHandler(this.btnExportSql_Click);
            //
            // lblCount
            //
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(2, 72);
            this.lblCount.Text = "Найдено записей: 0";
            //
            // panelSqlCard
            //
            this.panelSqlCard.Location = new System.Drawing.Point(28, 522);
            this.panelSqlCard.Name = "panelSqlCard";
            this.panelSqlCard.Size = new System.Drawing.Size(566, 230);
            this.panelSqlCard.Controls.Add(this.lblSqlTitle);
            this.panelSqlCard.Controls.Add(this.txtSql);
            this.panelSqlCard.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSqlCard_Paint);
            //
            // lblSqlTitle
            //
            this.lblSqlTitle.AutoSize = true;
            this.lblSqlTitle.Location = new System.Drawing.Point(16, 12);
            this.lblSqlTitle.Text = "SQL-запрос (пример)";
            //
            // txtSql
            //
            this.txtSql.Location = new System.Drawing.Point(16, 44);
            this.txtSql.Multiline = true;
            this.txtSql.ReadOnly = true;
            this.txtSql.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSql.Size = new System.Drawing.Size(534, 168);
            this.txtSql.BackColor = System.Drawing.Color.White;
            this.txtSql.Font = new System.Drawing.Font("Consolas", 9F);
            this.txtSql.Text = "SELECT b.BirthID, b.ChildLastName, b.ChildFirstName, b.ChildMiddleName,\r\n" +
                "       b.BirthDate, b.BirthTime, b.BirthPlace,\r\n" +
                "       m.FullName AS MotherName, f.FullName AS FatherName,\r\n" +
                "       c.Series, c.Number\r\n" +
                "FROM dbo.BirthRecords b\r\n" +
                "LEFT JOIN dbo.Parents m ON b.MotherID = m.ParentID\r\n" +
                "LEFT JOIN dbo.Parents f ON b.FatherID = f.ParentID\r\n" +
                "LEFT JOIN dbo.Certificates c ON b.CertificateID = c.CertificateID\r\n" +
                "WHERE b.BirthDate BETWEEN '2024-01-01' AND '2024-12-31'\r\n" +
                "ORDER BY b.BirthDate DESC;";
            //
            // panelSchemaCard
            //
            this.panelSchemaCard.Location = new System.Drawing.Point(620, 522);
            this.panelSchemaCard.Name = "panelSchemaCard";
            this.panelSchemaCard.Size = new System.Drawing.Size(588, 230);
            this.panelSchemaCard.Controls.Add(this.lblSchemaTitle);
            this.panelSchemaCard.Controls.Add(this.lblSchema);
            this.panelSchemaCard.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSchemaCard_Paint);
            //
            // lblSchemaTitle
            //
            this.lblSchemaTitle.AutoSize = true;
            this.lblSchemaTitle.Location = new System.Drawing.Point(16, 12);
            this.lblSchemaTitle.Text = "Схема базы данных (SQL)";
            //
            // lblSchema
            //
            this.lblSchema.Location = new System.Drawing.Point(16, 44);
            this.lblSchema.Size = new System.Drawing.Size(556, 172);
            this.lblSchema.Text =
                "BirthRecords (Рождения)  PK: BirthID\r\n" +
                "    FK MotherID → Parents.ParentID   (1:M)\r\n" +
                "    FK FatherID → Parents.ParentID   (1:M)\r\n" +
                "    FK CertificateID → Certificates.CertificateID  (0:1)\r\n" +
                "    FK EmployeeID → Employees.EmployeeID  (1:M)\r\n\r\n" +
                "Parents (Родители)  PK: ParentID\r\n" +
                "Certificates (Свидетельства)  PK: CertificateID\r\n" +
                "Employees (Сотрудники)  PK: EmployeeID\r\n" +
                "AuditLogs (Журнал)  PK: LogID  FK: EmployeeID";
            //
            // BirthsView
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.panelFilters);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.panelActions);
            this.Controls.Add(this.panelSqlCard);
            this.Controls.Add(this.panelSchemaCard);
            this.Name = "BirthsView";
            this.Size = new System.Drawing.Size(1240, 780);
            this.Load += new System.EventHandler(this.BirthsView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
