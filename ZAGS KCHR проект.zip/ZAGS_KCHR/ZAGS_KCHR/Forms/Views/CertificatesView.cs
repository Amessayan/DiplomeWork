using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Раздел «Свидетельства». Просмотр выданных свидетельств о рождении.
    /// </summary>
    public partial class CertificatesView : UserControl
    {
        private readonly CertificateRepository _repo = new CertificateRepository();
        private List<Certificate> _items = new List<Certificate>();

        public CertificatesView()
        {
            InitializeComponent();
            BackColor = AppTheme.Beige;
            lblTitle.Font = AppTheme.H1;
            lblTitle.ForeColor = AppTheme.Bordeaux;
            UIHelper.StyleGrid(grid);
            UIHelper.StyleGoldButton(btnRefresh);
            UIHelper.StylePrimaryButton(btnDelete, false);
        }

        private async void CertificatesView_Load(object sender, EventArgs e) => await LoadAsync();

        private async System.Threading.Tasks.Task LoadAsync()
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                _items = await _repo.GetAllAsync();
                grid.Rows.Clear();
                foreach (var c in _items)
                {
                    int idx = grid.Rows.Add(
                        c.CertificateID,
                        c.Series,
                        c.Number,
                        c.FullNumber,
                        c.IssueDate.ToString("dd.MM.yyyy"),
                        c.IssuedBy);
                    grid.Rows[idx].Tag = c;
                }
                lblCount.Text = $"Всего свидетельств: {_items.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { Cursor = Cursors.Default; }
        }

        private async void btnRefresh_Click(object sender, EventArgs e) => await LoadAsync();

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            var c = grid.SelectedRows.Count > 0 ? grid.SelectedRows[0].Tag as Certificate : null;
            if (c == null)
            {
                MessageBox.Show("Выберите свидетельство.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show($"Удалить свидетельство {c.FullNumber}?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

            try
            {
                await _repo.DeleteAsync(c.CertificateID);
                await LoadAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Невозможно удалить (свидетельство может быть привязано к записи):\n"
                    + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
