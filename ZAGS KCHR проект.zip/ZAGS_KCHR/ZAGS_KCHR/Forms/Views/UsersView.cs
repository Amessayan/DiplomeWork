using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms.Views
{
    /// <summary>
    /// Раздел «Пользователи» (доступен только администратору).
    /// Управление учётными записями сотрудников: добавление, изменение, удаление.
    /// </summary>
    public partial class UsersView : UserControl
    {
        private readonly EmployeeRepository _repo = new EmployeeRepository();
        private List<Employee> _items = new List<Employee>();
        private Employee _editing;

        public UsersView()
        {
            InitializeComponent();
            StyleView();
        }

        private async void UsersView_Load(object sender, EventArgs e)
        {
            cmbRole.SelectedIndex = 0;
            await LoadAsync();
        }

        private void StyleView()
        {
            BackColor = AppTheme.Beige;
            lblTitle.Font = AppTheme.H1;
            lblTitle.ForeColor = AppTheme.Bordeaux;
            UIHelper.StyleGrid(grid);
            UIHelper.StylePrimaryButton(btnSave);
            UIHelper.StylePrimaryButton(btnNew, false);
            UIHelper.StylePrimaryButton(btnDelete, false);
        }

        private async System.Threading.Tasks.Task LoadAsync()
        {
            try
            {
                _items = await _repo.GetAllAsync();
                grid.Rows.Clear();
                foreach (var emp in _items)
                {
                    int idx = grid.Rows.Add(
                        emp.EmployeeID, emp.FullName, emp.Login, emp.Role,
                        emp.Position, emp.IsActive ? "Да" : "Нет");
                    grid.Rows[idx].Tag = emp;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки:\n" + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void grid_SelectionChanged(object sender, EventArgs e)
        {
            if (grid.SelectedRows.Count == 0) return;
            _editing = grid.SelectedRows[0].Tag as Employee;
            if (_editing == null) return;

            txtFullName.Text = _editing.FullName;
            txtLogin.Text = _editing.Login;
            txtPassword.Text = "";
            cmbRole.SelectedItem = _editing.Role;
            if (cmbRole.SelectedIndex < 0) cmbRole.SelectedIndex = 1;
            txtPosition.Text = _editing.Position;
            chkActive.Checked = _editing.IsActive;
            lblHint.Text = "Оставьте пароль пустым, чтобы не менять его.";
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            _editing = null;
            txtFullName.Clear();
            txtLogin.Clear();
            txtPassword.Clear();
            txtPosition.Clear();
            cmbRole.SelectedIndex = 0;
            chkActive.Checked = true;
            lblHint.Text = "Создание нового пользователя.";
            txtFullName.Focus();
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text) ||
                string.IsNullOrWhiteSpace(txtLogin.Text))
            {
                MessageBox.Show("Заполните ФИО и логин.", "Проверка данных",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (_editing == null && string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Для нового пользователя укажите пароль.", "Проверка данных",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var emp = _editing ?? new Employee();
            emp.FullName = txtFullName.Text.Trim();
            emp.Login = txtLogin.Text.Trim();
            emp.Role = cmbRole.SelectedItem?.ToString() ?? "Сотрудник";
            emp.Position = txtPosition.Text.Trim();
            emp.IsActive = chkActive.Checked;

            try
            {
                btnSave.Enabled = false;
                if (emp.EmployeeID == 0)
                    await _repo.AddAsync(emp, txtPassword.Text);
                else
                    await _repo.UpdateAsync(emp,
                        string.IsNullOrWhiteSpace(txtPassword.Text) ? null : txtPassword.Text);

                await LoadAsync();
                btnNew_Click(sender, e);
                MessageBox.Show("Сохранено.", "Готово",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения (возможно, логин занят):\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { btnSave.Enabled = true; }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (_editing == null || _editing.EmployeeID == 0)
            {
                MessageBox.Show("Выберите пользователя.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (_editing.EmployeeID == UserSession.CurrentUser?.EmployeeID)
            {
                MessageBox.Show("Нельзя удалить текущего пользователя.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (MessageBox.Show($"Удалить пользователя «{_editing.FullName}»?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

            try
            {
                await _repo.DeleteAsync(_editing.EmployeeID);
                await LoadAsync();
                btnNew_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Невозможно удалить (есть связанные записи):\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
            => txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
    }
}
