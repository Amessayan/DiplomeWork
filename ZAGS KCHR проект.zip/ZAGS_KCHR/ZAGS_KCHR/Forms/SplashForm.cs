using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms
{
    /// <summary>
    /// Заставка приложения (splash screen).
    /// Отображается при запуске, показывает логотип и статус проверки БД.
    /// </summary>
    public partial class SplashForm : Form
    {
        private Timer _timer;
        private int _progress;

        public SplashForm()
        {
            InitializeComponent();
            // Двойная буферизация — чтобы анимация была плавной без мерцания
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer, true);
        }

        private void SplashForm_Load(object sender, EventArgs e)
        {
            _timer = new Timer { Interval = 30 };
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            _progress += 2;
            lblStatus.Text = _progress < 50
                ? "Инициализация системы..."
                : "Проверка соединения с базой данных...";

            Invalidate(); // перерисовать прогресс-бар

            if (_progress >= 100)
            {
                _timer.Stop();
                Close();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Фон-градиент (бордовый)
            using (var brush = new LinearGradientBrush(ClientRectangle,
                AppTheme.Bordeaux, AppTheme.BordeauxDark, 90f))
            {
                g.FillRectangle(brush, ClientRectangle);
            }

            // Эмблема (стилизованный двуглавый орёл — упрощённый круг с короной)
            DrawEmblem(g, Width / 2, 90);

            // Прогресс-бар
            int barW = 360, barH = 6;
            int barX = (Width - barW) / 2, barY = Height - 70;
            using (var back = new SolidBrush(Color.FromArgb(80, 255, 255, 255)))
            using (var fore = new SolidBrush(AppTheme.Gold))
            {
                using (var p = UIHelper.RoundedRect(new Rectangle(barX, barY, barW, barH), 3))
                    g.FillPath(back, p);
                int fillW = (int)(barW * (_progress / 100f));
                using (var p = UIHelper.RoundedRect(new Rectangle(barX, barY, fillW, barH), 3))
                    g.FillPath(fore, p);
            }
        }

        /// <summary>Рисует упрощённую эмблему ЗАГС.</summary>
        private void DrawEmblem(Graphics g, int cx, int cy)
        {
            using (var goldPen = new Pen(AppTheme.Gold, 3))
            using (var goldBrush = new SolidBrush(AppTheme.Gold))
            using (var whiteBrush = new SolidBrush(Color.White))
            {
                // Внешний круг
                g.DrawEllipse(goldPen, cx - 45, cy - 45, 90, 90);
                // Внутренний герб (книга — символ записи актов)
                g.FillRectangle(whiteBrush, cx - 22, cy - 14, 44, 30);
                using (var linePen = new Pen(AppTheme.Bordeaux, 1.5f))
                {
                    g.DrawLine(linePen, cx, cy - 14, cx, cy + 16);
                    for (int i = -8; i <= 8; i += 6)
                    {
                        g.DrawLine(linePen, cx - 18, cy + i, cx - 3, cy + i);
                        g.DrawLine(linePen, cx + 3, cy + i, cx + 18, cy + i);
                    }
                }
            }
        }
    }
}
