using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms
{
    /// <summary>
    /// Форма авторизации пользователя.
    /// Проверяет логин/пароль через EmployeeRepository и заполняет UserSession.
    /// </summary>
    public partial class LoginForm : Form
    {
        private readonly EmployeeRepository _employees = new EmployeeRepository();

        public LoginForm()
        {
            InitializeComponent();
            ApplyStyle();
        }

        /// <summary>Применяет цветовую тему к элементам формы.</summary>
        private void ApplyStyle()
        {
            UIHelper.StylePrimaryButton(btnLogin);
            txtPassword.UseSystemPasswordChar = true;

            // Enter в полях запускает вход
            txtLogin.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) txtPassword.Focus(); };
            txtPassword.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) btnLogin.PerformClick(); };
        }

        /// <summary>Отрисовка левой бордовой панели с эмблемой.</summary>
        private void panelLeft_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var brush = new LinearGradientBrush(panelLeft.ClientRectangle,
                AppTheme.Bordeaux, AppTheme.BordeauxDark, 90f))
            {
                g.FillRectangle(brush, panelLeft.ClientRectangle);
            }

            // Эмблема
            int cx = panelLeft.Width / 2, cy = 120;
            using (var goldPen = new Pen(AppTheme.Gold, 3))
            using (var whiteBrush = new SolidBrush(Color.White))
            {
                g.DrawEllipse(goldPen, cx - 42, cy - 42, 84, 84);
                g.FillRectangle(whiteBrush, cx - 20, cy - 13, 40, 28);
                using (var linePen = new Pen(AppTheme.Bordeaux, 1.5f))
                {
                    g.DrawLine(linePen, cx, cy - 13, cx, cy + 15);
                    for (int i = -7; i <= 7; i += 6)
                    {
                        g.DrawLine(linePen, cx - 16, cy + i, cx - 3, cy + i);
                        g.DrawLine(linePen, cx + 3, cy + i, cx + 16, cy + i);
                    }
                }
            }
        }

        /// <summary>Показать/скрыть пароль.</summary>
        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
        }

        /// <summary>Обработчик кнопки «Войти».</summary>
        private async void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;

            // Валидация ввода
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                ShowError("Введите логин и пароль.");
                return;
            }

            btnLogin.Enabled = false;
            btnLogin.Text = "Проверка...";
            lblError.Visible = false;

            try
            {
                var user = await _employees.AuthenticateAsync(login, password);
                if (user == null)
                {
                    ShowError("Неверный логин или пароль.");
                    return;
                }

                // Успешный вход — сохраняем сессию
                UserSession.CurrentUser = user;
                new AuditRepository().LogAsync(user.EmployeeID, "Вход в систему");
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                ShowError("Ошибка подключения к БД. Проверьте App.config.\n" + ex.Message);
            }
            finally
            {
                btnLogin.Enabled = true;
                btnLogin.Text = "Войти";
            }
        }

        private void ShowError(string text)
        {
            lblError.Text = text;
            lblError.Visible = true;
        }
    }
}
