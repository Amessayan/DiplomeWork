namespace ZAGS_KCHR.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelSidebar;
        private System.Windows.Forms.Panel panelBrand;
        private System.Windows.Forms.Label lblBrandTitle;
        private System.Windows.Forms.Label lblBrandSub;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnBirths;
        private System.Windows.Forms.Button btnParents;
        private System.Windows.Forms.Button btnCertificates;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnUsers;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.Panel panelUser;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblUserRole;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Panel panelContent;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelSidebar = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.panelUser = new System.Windows.Forms.Panel();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblUserRole = new System.Windows.Forms.Label();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.btnUsers = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnCertificates = new System.Windows.Forms.Button();
            this.btnParents = new System.Windows.Forms.Button();
            this.btnBirths = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.panelBrand = new System.Windows.Forms.Panel();
            this.lblBrandTitle = new System.Windows.Forms.Label();
            this.lblBrandSub = new System.Windows.Forms.Label();
            this.panelContent = new System.Windows.Forms.Panel();
            this.panelSidebar.SuspendLayout();
            this.panelUser.SuspendLayout();
            this.panelMenu.SuspendLayout();
            this.panelBrand.SuspendLayout();
            this.SuspendLayout();
            //
            // panelSidebar
            //
            this.panelSidebar.Controls.Add(this.panelMenu);
            this.panelSidebar.Controls.Add(this.btnLogout);
            this.panelSidebar.Controls.Add(this.panelUser);
            this.panelSidebar.Controls.Add(this.panelBrand);
            this.panelSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSidebar.Location = new System.Drawing.Point(0, 0);
            this.panelSidebar.Name = "panelSidebar";
            this.panelSidebar.Size = new System.Drawing.Size(256, 768);
            this.panelSidebar.TabIndex = 0;
            //
            // panelMenu
            //
            this.panelMenu.Controls.Add(this.btnAdmin);
            this.panelMenu.Controls.Add(this.btnUsers);
            this.panelMenu.Controls.Add(this.btnReports);
            this.panelMenu.Controls.Add(this.btnCertificates);
            this.panelMenu.Controls.Add(this.btnParents);
            this.panelMenu.Controls.Add(this.btnBirths);
            this.panelMenu.Controls.Add(this.btnDashboard);
            this.panelMenu.Location = new System.Drawing.Point(0, 130);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(256, 450);
            this.panelMenu.TabIndex = 3;
            //
            // btnDashboard
            //
            this.btnDashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDashboard.Location = new System.Drawing.Point(0, 0);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(256, 52);
            this.btnDashboard.TabIndex = 0;
            this.btnDashboard.Text = "    🏠   Дашборд";
            this.btnDashboard.UseVisualStyleBackColor = true;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            //
            // btnBirths
            //
            this.btnBirths.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBirths.Location = new System.Drawing.Point(0, 52);
            this.btnBirths.Name = "btnBirths";
            this.btnBirths.Size = new System.Drawing.Size(256, 52);
            this.btnBirths.TabIndex = 1;
            this.btnBirths.Text = "    📋   Записи о рождениях";
            this.btnBirths.UseVisualStyleBackColor = true;
            this.btnBirths.Click += new System.EventHandler(this.btnBirths_Click);
            //
            // btnParents
            //
            this.btnParents.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnParents.Location = new System.Drawing.Point(0, 104);
            this.btnParents.Name = "btnParents";
            this.btnParents.Size = new System.Drawing.Size(256, 52);
            this.btnParents.TabIndex = 2;
            this.btnParents.Text = "    👪   Родители";
            this.btnParents.UseVisualStyleBackColor = true;
            this.btnParents.Click += new System.EventHandler(this.btnParents_Click);
            //
            // btnCertificates
            //
            this.btnCertificates.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCertificates.Location = new System.Drawing.Point(0, 156);
            this.btnCertificates.Name = "btnCertificates";
            this.btnCertificates.Size = new System.Drawing.Size(256, 52);
            this.btnCertificates.TabIndex = 3;
            this.btnCertificates.Text = "    📜   Свидетельства";
            this.btnCertificates.UseVisualStyleBackColor = true;
            this.btnCertificates.Click += new System.EventHandler(this.btnCertificates_Click);
            //
            // btnReports
            //
            this.btnReports.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReports.Location = new System.Drawing.Point(0, 208);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(256, 52);
            this.btnReports.TabIndex = 4;
            this.btnReports.Text = "    📊   Отчёты";
            this.btnReports.UseVisualStyleBackColor = true;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            //
            // btnUsers
            //
            this.btnUsers.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnUsers.Location = new System.Drawing.Point(0, 260);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(256, 52);
            this.btnUsers.TabIndex = 5;
            this.btnUsers.Text = "    👤   Пользователи";
            this.btnUsers.UseVisualStyleBackColor = true;
            this.btnUsers.Click += new System.EventHandler(this.btnUsers_Click);
            //
            // btnAdmin
            //
            this.btnAdmin.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAdmin.Location = new System.Drawing.Point(0, 312);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Size = new System.Drawing.Size(256, 52);
            this.btnAdmin.TabIndex = 6;
            this.btnAdmin.Text = "    ⚙   Администрирование";
            this.btnAdmin.UseVisualStyleBackColor = true;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            //
            // btnLogout
            //
            this.btnLogout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnLogout.Location = new System.Drawing.Point(0, 716);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(256, 52);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "    ↩   Выход";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            //
            // panelUser
            //
            this.panelUser.Controls.Add(this.lblUserName);
            this.panelUser.Controls.Add(this.lblUserRole);
            this.panelUser.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelUser.Location = new System.Drawing.Point(0, 652);
            this.panelUser.Name = "panelUser";
            this.panelUser.Size = new System.Drawing.Size(256, 64);
            this.panelUser.TabIndex = 2;
            //
            // lblUserName
            //
            this.lblUserName.AutoEllipsis = true;
            this.lblUserName.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Location = new System.Drawing.Point(20, 12);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(224, 22);
            this.lblUserName.TabIndex = 0;
            this.lblUserName.Text = "Пользователь";
            //
            // lblUserRole
            //
            this.lblUserRole.AutoSize = true;
            this.lblUserRole.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblUserRole.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(200)))), ((int)(((byte)(150)))));
            this.lblUserRole.Location = new System.Drawing.Point(20, 36);
            this.lblUserRole.Name = "lblUserRole";
            this.lblUserRole.Size = new System.Drawing.Size(40, 15);
            this.lblUserRole.TabIndex = 1;
            this.lblUserRole.Text = "Роль";
            //
            // panelBrand
            //
            this.panelBrand.Controls.Add(this.lblBrandTitle);
            this.panelBrand.Controls.Add(this.lblBrandSub);
            this.panelBrand.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBrand.Location = new System.Drawing.Point(0, 0);
            this.panelBrand.Name = "panelBrand";
            this.panelBrand.Size = new System.Drawing.Size(256, 130);
            this.panelBrand.TabIndex = 0;
            this.panelBrand.Paint += new System.Windows.Forms.PaintEventHandler(this.panelBrand_Paint);
            //
            // lblBrandTitle
            //
            this.lblBrandTitle.AutoSize = true;
            this.lblBrandTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblBrandTitle.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblBrandTitle.ForeColor = System.Drawing.Color.White;
            this.lblBrandTitle.Location = new System.Drawing.Point(84, 28);
            this.lblBrandTitle.Name = "lblBrandTitle";
            this.lblBrandTitle.Size = new System.Drawing.Size(116, 24);
            this.lblBrandTitle.TabIndex = 0;
            this.lblBrandTitle.Text = "ОТДЕЛ ЗАГС";
            //
            // lblBrandSub
            //
            this.lblBrandSub.BackColor = System.Drawing.Color.Transparent;
            this.lblBrandSub.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblBrandSub.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(200)))), ((int)(((byte)(150)))));
            this.lblBrandSub.Location = new System.Drawing.Point(84, 54);
            this.lblBrandSub.Name = "lblBrandSub";
            this.lblBrandSub.Size = new System.Drawing.Size(164, 48);
            this.lblBrandSub.TabIndex = 1;
            this.lblBrandSub.Text = "Управление регистрацией актов";
            //
            // panelContent
            //
            this.panelContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContent.Location = new System.Drawing.Point(256, 0);
            this.panelContent.Name = "panelContent";
            this.panelContent.Size = new System.Drawing.Size(1024, 768);
            this.panelContent.TabIndex = 1;
            //
            // MainForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1280, 768);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.panelSidebar);
            this.MinimumSize = new System.Drawing.Size(1100, 680);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ЗАГС: Управление регистрацией актов — КЧР";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panelSidebar.ResumeLayout(false);
            this.panelUser.ResumeLayout(false);
            this.panelUser.PerformLayout();
            this.panelMenu.ResumeLayout(false);
            this.panelBrand.ResumeLayout(false);
            this.panelBrand.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}
