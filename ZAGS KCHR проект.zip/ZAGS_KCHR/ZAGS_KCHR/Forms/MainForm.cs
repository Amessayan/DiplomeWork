using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ZAGS_KCHR.Forms.Views;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Forms
{
    /// <summary>
    /// Главное окно приложения. Содержит боковое меню (UI Layer) и
    /// область контента, в которую подгружаются разделы-представления.
    /// </summary>
    public partial class MainForm : Form
    {
        private Button _activeMenuButton;

        public MainForm()
        {
            InitializeComponent();
            ApplyStyle();
            SetupForRole();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Отображаем имя текущего пользователя
            lblUserName.Text = UserSession.CurrentUser?.FullName ?? "—";
            lblUserRole.Text = UserSession.CurrentUser?.Role ?? "";

            // По умолчанию открываем дашборд
            OpenView(new DashboardView(), btnDashboard);
        }

        private void ApplyStyle()
        {
            panelSidebar.BackColor = AppTheme.Bordeaux;
            panelContent.BackColor = AppTheme.Beige;

            // Настраиваем кнопки меню
            foreach (Control c in panelMenu.Controls)
            {
                if (c is Button btn) StyleMenuButton(btn);
            }
            StyleMenuButton(btnLogout);
        }

        /// <summary>Скрывает пункты администрирования для обычных сотрудников.</summary>
        private void SetupForRole()
        {
            bool isAdmin = UserSession.IsAdmin;
            btnUsers.Visible = isAdmin;
            btnAdmin.Visible = isAdmin;
        }

        /// <summary>Стилизует кнопку бокового меню.</summary>
        private void StyleMenuButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = AppTheme.Bordeaux;
            btn.ForeColor = AppTheme.White;
            btn.Font = AppTheme.MenuFont;
            btn.TextAlign = ContentAlignment.MiddleLeft;
            btn.Padding = new Padding(24, 0, 0, 0);
            btn.Cursor = Cursors.Hand;
            btn.FlatAppearance.MouseOverBackColor = AppTheme.BordeauxDark;
        }

        /// <summary>Подсвечивает активный пункт меню.</summary>
        private void SetActiveMenu(Button btn)
        {
            if (_activeMenuButton != null)
            {
                _activeMenuButton.BackColor = AppTheme.Bordeaux;
                _activeMenuButton.ForeColor = AppTheme.White;
            }
            _activeMenuButton = btn;
            if (btn != null)
            {
                btn.BackColor = AppTheme.Beige;
                btn.ForeColor = AppTheme.Bordeaux;
            }
        }

        /// <summary>Загружает выбранное представление в область контента.</summary>
        private void OpenView(UserControl view, Button menuButton)
        {
            SetActiveMenu(menuButton);
            panelContent.Controls.Clear();
            view.Dock = DockStyle.Fill;
            panelContent.Controls.Add(view);
        }

        // --- Обработчики пунктов меню ---

        private void btnDashboard_Click(object sender, EventArgs e)
            => OpenView(new DashboardView(), btnDashboard);

        private void btnBirths_Click(object sender, EventArgs e)
            => OpenView(new BirthsView(), btnBirths);

        private void btnParents_Click(object sender, EventArgs e)
            => OpenView(new ParentsView(), btnParents);

        private void btnCertificates_Click(object sender, EventArgs e)
            => OpenView(new CertificatesView(), btnCertificates);

        private void btnReports_Click(object sender, EventArgs e)
            => OpenView(new ReportsView(), btnReports);

        private void btnUsers_Click(object sender, EventArgs e)
            => OpenView(new UsersView(), btnUsers);

        private void btnAdmin_Click(object sender, EventArgs e)
            => OpenView(new AdminView(), btnAdmin);

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Выйти из системы?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                UserSession.Clear();
                Application.Restart();
            }
        }

        /// <summary>Отрисовка эмблемы и заголовка в шапке сайдбара.</summary>
        private void panelBrand_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int cx = 42, cy = 44;
            using (var goldPen = new Pen(AppTheme.Gold, 2.5f))
            using (var whiteBrush = new SolidBrush(Color.White))
            {
                g.DrawEllipse(goldPen, cx - 26, cy - 26, 52, 52);
                g.FillRectangle(whiteBrush, cx - 13, cy - 9, 26, 18);
                using (var linePen = new Pen(AppTheme.Bordeaux, 1f))
                {
                    g.DrawLine(linePen, cx, cy - 9, cx, cy + 9);
                    for (int i = -5; i <= 5; i += 4)
                    {
                        g.DrawLine(linePen, cx - 10, cy + i, cx - 2, cy + i);
                        g.DrawLine(linePen, cx + 2, cy + i, cx + 10, cy + i);
                    }
                }
            }
        }
    }
}
