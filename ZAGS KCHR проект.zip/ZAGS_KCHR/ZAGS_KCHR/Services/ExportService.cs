using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Services
{
    /// <summary>
    /// Сервис экспорта данных: Excel (через OpenXML/CSV-совместимый формат),
    /// CSV и резервная копия SQL (BACKUP DATABASE).
    /// </summary>
    public class ExportService
    {
        /// <summary>
        /// Экспортирует список записей о рождении в CSV-файл (открывается Excel).
        /// Используется кодировка UTF-8 с BOM для корректной кириллицы.
        /// </summary>
        public void ExportBirthsToCsv(IEnumerable<BirthRecord> records, string filePath)
        {
            var sb = new StringBuilder();
            // Заголовки
            sb.AppendLine("№;ФИО ребёнка;Дата рождения;Время;Место рождения;Пол;" +
                          "Вес (г);Рост (см);ФИО матери;ФИО отца;Свидетельство;Дата регистрации");

            int i = 1;
            foreach (var r in records)
            {
                sb.AppendLine(string.Join(";", new[]
                {
                    i.ToString(),
                    Q(r.ChildFullName),
                    r.BirthDate.ToString("dd.MM.yyyy"),
                    r.BirthTime.HasValue ? r.BirthTime.Value.ToString(@"hh\:mm") : "",
                    Q(r.BirthPlace),
                    Q(r.Gender),
                    r.Weight?.ToString(CultureInfo.InvariantCulture) ?? "",
                    r.Height?.ToString(CultureInfo.InvariantCulture) ?? "",
                    Q(r.MotherName),
                    Q(r.FatherName),
                    Q(r.CertificateFullNumber),
                    r.RegistrationDate.ToString("dd.MM.yyyy")
                }));
                i++;
            }

            // BOM нужен, чтобы Excel правильно распознал UTF-8
            File.WriteAllText(filePath, sb.ToString(), new UTF8Encoding(true));
        }

        /// <summary>
        /// Экспортирует записи в формат Excel XML (SpreadsheetML),
        /// который открывается в MS Excel без дополнительных библиотек.
        /// </summary>
        public void ExportBirthsToExcel(IEnumerable<BirthRecord> records, string filePath)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sb.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
            sb.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" " +
                          "xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">");
            sb.AppendLine("<Styles>");
            sb.AppendLine("<Style ss:ID=\"hdr\"><Font ss:Bold=\"1\" ss:Color=\"#FFFFFF\"/>" +
                          "<Interior ss:Color=\"#7A1626\" ss:Pattern=\"Solid\"/></Style>");
            sb.AppendLine("</Styles>");
            sb.AppendLine("<Worksheet ss:Name=\"Рождения\"><Table>");

            // Шапка
            string[] headers = { "№", "ФИО ребёнка", "Дата рождения", "Время", "Место рождения",
                                 "Пол", "Вес (г)", "Рост (см)", "ФИО матери", "ФИО отца",
                                 "Свидетельство", "Дата регистрации" };
            sb.Append("<Row>");
            foreach (var h in headers)
                sb.Append($"<Cell ss:StyleID=\"hdr\"><Data ss:Type=\"String\">{X(h)}</Data></Cell>");
            sb.AppendLine("</Row>");

            int i = 1;
            foreach (var r in records)
            {
                sb.Append("<Row>");
                AddCell(sb, i.ToString(), true);
                AddCell(sb, r.ChildFullName);
                AddCell(sb, r.BirthDate.ToString("dd.MM.yyyy"));
                AddCell(sb, r.BirthTime?.ToString(@"hh\:mm") ?? "");
                AddCell(sb, r.BirthPlace);
                AddCell(sb, r.Gender);
                AddCell(sb, r.Weight?.ToString(CultureInfo.InvariantCulture) ?? "", true);
                AddCell(sb, r.Height?.ToString(CultureInfo.InvariantCulture) ?? "", true);
                AddCell(sb, r.MotherName);
                AddCell(sb, r.FatherName);
                AddCell(sb, r.CertificateFullNumber);
                AddCell(sb, r.RegistrationDate.ToString("dd.MM.yyyy"));
                sb.AppendLine("</Row>");
                i++;
            }

            sb.AppendLine("</Table></Worksheet></Workbook>");
            File.WriteAllText(filePath, sb.ToString(), new UTF8Encoding(true));
        }

        /// <summary>
        /// Создаёт резервную копию базы данных средствами SQL Server (BACKUP DATABASE).
        /// Путь должен быть доступен для записи учётной записи SQL Server.
        /// </summary>
        public async Task BackupDatabaseAsync(string backupFilePath)
        {
            string sql = $@"BACKUP DATABASE [ZAGS_KCHR_DB]
                            TO DISK = @path WITH FORMAT, INIT,
                            NAME = N'ZAGS_KCHR_DB-Full Backup';";
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text,
                new SqlParameter("@path", backupFilePath));
        }

        /// <summary>
        /// Восстанавливает базу данных из резервной копии.
        /// </summary>
        public async Task RestoreDatabaseAsync(string backupFilePath)
        {
            // Восстановление требует эксклюзивного доступа — переводим в single user
            string sql = $@"USE master;
                            ALTER DATABASE [ZAGS_KCHR_DB] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                            RESTORE DATABASE [ZAGS_KCHR_DB] FROM DISK = @path WITH REPLACE;
                            ALTER DATABASE [ZAGS_KCHR_DB] SET MULTI_USER;";
            await DatabaseHelper.ExecuteNonQueryAsync(sql, CommandType.Text,
                new SqlParameter("@path", backupFilePath));
        }

        // --- Вспомогательные методы ---

        private static void AddCell(StringBuilder sb, string value, bool number = false)
        {
            string type = number && !string.IsNullOrEmpty(value) ? "Number" : "String";
            sb.Append($"<Cell><Data ss:Type=\"{type}\">{X(value)}</Data></Cell>");
        }

        /// <summary>Экранирует значение для CSV (кавычки и точки с запятой).</summary>
        private static string Q(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            if (s.Contains(";") || s.Contains("\"") || s.Contains("\n"))
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }

        /// <summary>Экранирует значение для XML.</summary>
        private static string X(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;")
                    .Replace("\"", "&quot;");
        }
    }
}
