using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Services
{
    /// <summary>
    /// Сервис печати свидетельства о рождении.
    /// Использует System.Drawing.Printing для формирования документа,
    /// который можно отправить на принтер или сохранить в PDF
    /// (через виртуальный принтер "Microsoft Print to PDF").
    /// </summary>
    public class PrintService
    {
        private BirthRecord _record;

        /// <summary>Показывает диалог предпросмотра свидетельства.</summary>
        public void PreviewCertificate(BirthRecord record)
        {
            _record = record;
            using (var doc = CreateDocument())
            using (var preview = new PrintPreviewDialog
            {
                Document = doc,
                Width = 900,
                Height = 700,
                Text = "Предпросмотр свидетельства о рождении"
            })
            {
                preview.ShowDialog();
            }
        }

        /// <summary>Печатает свидетельство с выбором принтера.</summary>
        public void PrintCertificate(BirthRecord record)
        {
            _record = record;
            using (var doc = CreateDocument())
            using (var dlg = new PrintDialog { Document = doc })
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                    doc.Print();
            }
        }

        private PrintDocument CreateDocument()
        {
            var doc = new PrintDocument();
            doc.DocumentName = "Свидетельство о рождении";
            doc.PrintPage += Doc_PrintPage;
            return doc;
        }

        /// <summary>Отрисовка страницы свидетельства.</summary>
        private void Doc_PrintPage(object sender, PrintPageEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            var bordeaux = AppTheme.Bordeaux;
            var gold = AppTheme.Gold;
            var dark = AppTheme.TextDark;

            float left = e.MarginBounds.Left;
            float width = e.MarginBounds.Width;
            float y = e.MarginBounds.Top;

            // Рамка документа
            using (var borderPen = new Pen(gold, 3))
                g.DrawRectangle(borderPen, e.MarginBounds.Left - 10, e.MarginBounds.Top - 10,
                                e.MarginBounds.Width + 20, e.MarginBounds.Height + 20);

            // Шапка
            using (var titleFont = new Font("Times New Roman", 22, FontStyle.Bold))
            using (var brush = new SolidBrush(bordeaux))
            {
                DrawCentered(g, "СВИДЕТЕЛЬСТВО О РОЖДЕНИИ", titleFont, brush, left, width, ref y);
            }
            y += 8;
            using (var subFont = new Font("Times New Roman", 13, FontStyle.Italic))
            using (var brush = new SolidBrush(dark))
            {
                DrawCentered(g, "Управление ЗАГС Карачаево-Черкесской Республики", subFont, brush, left, width, ref y);
            }
            y += 30;

            // Разделитель
            using (var pen = new Pen(gold, 1.5f))
                g.DrawLine(pen, left, y, left + width, y);
            y += 25;

            // Тело документа
            using (var labelFont = new Font("Times New Roman", 13, FontStyle.Regular))
            using (var valueFont = new Font("Times New Roman", 13, FontStyle.Bold))
            using (var brush = new SolidBrush(dark))
            {
                string fio = $"{_record.ChildLastName} {_record.ChildFirstName} {_record.ChildMiddleName}".Trim();
                DrawField(g, "Ребёнок:", fio, labelFont, valueFont, brush, left, ref y);
                DrawField(g, "Пол:", _record.Gender, labelFont, valueFont, brush, left, ref y);
                DrawField(g, "Дата рождения:", _record.BirthDate.ToString("dd MMMM yyyy") + " г.",
                          labelFont, valueFont, brush, left, ref y);
                if (_record.BirthTime.HasValue)
                    DrawField(g, "Время рождения:", _record.BirthTime.Value.ToString(@"hh\:mm"),
                              labelFont, valueFont, brush, left, ref y);
                DrawField(g, "Место рождения:", _record.BirthPlace ?? "—",
                          labelFont, valueFont, brush, left, ref y);
                y += 10;
                DrawField(g, "Мать:", _record.MotherName ?? "—", labelFont, valueFont, brush, left, ref y);
                DrawField(g, "Отец:", _record.FatherName ?? "—", labelFont, valueFont, brush, left, ref y);
                y += 20;

                DrawField(g, "Серия и номер:", _record.CertificateFullNumber,
                          labelFont, valueFont, brush, left, ref y);
                DrawField(g, "Дата выдачи:",
                          (_record.CertIssueDate ?? DateTime.Today).ToString("dd.MM.yyyy"),
                          labelFont, valueFont, brush, left, ref y);
                DrawField(g, "Кем выдано:", _record.CertIssuedBy ?? "Управление ЗАГС КЧР",
                          labelFont, valueFont, brush, left, ref y);
            }

            // Подпись внизу
            y = e.MarginBounds.Bottom - 60;
            using (var pen = new Pen(dark, 1))
            {
                g.DrawLine(pen, left + width - 250, y, left + width - 40, y);
            }
            using (var signFont = new Font("Times New Roman", 10, FontStyle.Italic))
            using (var brush = new SolidBrush(AppTheme.TextGray))
            {
                g.DrawString("(подпись руководителя)", signFont, brush, left + width - 230, y + 5);
                g.DrawString("М.П.", signFont, brush, left + 40, y + 5);
            }

            e.HasMorePages = false;
        }

        private void DrawCentered(Graphics g, string text, Font font, Brush brush,
                                  float left, float width, ref float y)
        {
            var size = g.MeasureString(text, font);
            g.DrawString(text, font, brush, left + (width - size.Width) / 2, y);
            y += size.Height;
        }

        private void DrawField(Graphics g, string label, string value, Font labelFont,
                               Font valueFont, Brush brush, float left, ref float y)
        {
            g.DrawString(label, labelFont, brush, left, y);
            g.DrawString(value, valueFont, brush, left + 200, y);
            y += 32;
        }
    }
}
