using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ZAGS_KCHR.Models;
using ZAGS_KCHR.Repositories;
using ZAGS_KCHR.Utils;

namespace ZAGS_KCHR.Services
{
    /// <summary>
    /// Слой бизнес-логики (Business Logic Layer) для записей о рождении.
    /// Выполняет валидацию данных и координирует работу репозиториев.
    /// </summary>
    public class BirthService
    {
        private readonly BirthRecordRepository _births = new BirthRecordRepository();
        private readonly CertificateRepository _certs = new CertificateRepository();
        private readonly AuditRepository _audit = new AuditRepository();

        /// <summary>Поиск/фильтрация записей.</summary>
        public Task<List<BirthRecord>> SearchAsync(
            string search, DateTime? from, DateTime? to, string gender)
            => _births.SearchAsync(search, from, to, gender);

        /// <summary>
        /// Проверяет корректность данных записи. Возвращает текст ошибки или null.
        /// </summary>
        public string Validate(BirthRecord b)
        {
            if (b == null) return "Нет данных.";
            if (string.IsNullOrWhiteSpace(b.ChildLastName)) return "Укажите фамилию ребёнка.";
            if (string.IsNullOrWhiteSpace(b.ChildFirstName)) return "Укажите имя ребёнка.";
            if (string.IsNullOrWhiteSpace(b.Gender)) return "Укажите пол ребёнка.";
            if (b.BirthDate > DateTime.Today) return "Дата рождения не может быть в будущем.";
            if (b.BirthDate < new DateTime(1900, 1, 1)) return "Некорректная дата рождения.";
            if (b.Weight.HasValue && (b.Weight < 100 || b.Weight > 9000))
                return "Вес должен быть в диапазоне 100–9000 г.";
            if (b.Height.HasValue && (b.Height < 20 || b.Height > 80))
                return "Рост должен быть в диапазоне 20–80 см.";
            return null;
        }

        /// <summary>Сохраняет запись (создаёт новую или обновляет существующую).</summary>
        public async Task<int> SaveAsync(BirthRecord b)
        {
            string error = Validate(b);
            if (error != null) throw new ArgumentException(error);

            if (b.BirthID == 0)
            {
                b.EmployeeID = UserSession.CurrentUser?.EmployeeID;
                int id = await _births.AddAsync(b);
                await _audit.LogAsync(b.EmployeeID,
                    $"Создана запись о рождении: {b.ChildFullName}");
                return id;
            }
            else
            {
                await _births.UpdateAsync(b);
                await _audit.LogAsync(UserSession.CurrentUser?.EmployeeID,
                    $"Изменена запись о рождении: {b.ChildFullName}");
                return b.BirthID;
            }
        }

        /// <summary>Удаляет запись.</summary>
        public async Task DeleteAsync(BirthRecord b)
        {
            await _births.DeleteAsync(b.BirthID);
            await _audit.LogAsync(UserSession.CurrentUser?.EmployeeID,
                $"Удалена запись о рождении: {b.ChildFullName}");
        }

        /// <summary>
        /// Формирует свидетельство для записи: генерирует номер,
        /// создаёт запись в Certificates и привязывает к рождению.
        /// </summary>
        public async Task<Certificate> GenerateCertificateAsync(BirthRecord b)
        {
            if (b == null || b.BirthID == 0)
                throw new ArgumentException("Сначала сохраните запись о рождении.");

            string number = await _certs.GenerateNextNumberAsync();
            var cert = new Certificate
            {
                Series = "I-МЮ",
                Number = number,
                IssueDate = DateTime.Today,
                IssuedBy = "Управление ЗАГС КЧР"
            };
            cert.CertificateID = await _certs.AddAsync(cert);

            await _births.AttachCertificateAsync(b.BirthID, cert.CertificateID);
            await _audit.LogAsync(UserSession.CurrentUser?.EmployeeID,
                $"Сформировано свидетельство {cert.FullNumber} для {b.ChildFullName}");

            // Обновляем объект записи, чтобы UI сразу показал данные
            b.CertificateID = cert.CertificateID;
            b.CertSeries = cert.Series;
            b.CertNumber = cert.Number;
            b.CertIssueDate = cert.IssueDate;
            b.CertIssuedBy = cert.IssuedBy;
            return cert;
        }
    }
}
