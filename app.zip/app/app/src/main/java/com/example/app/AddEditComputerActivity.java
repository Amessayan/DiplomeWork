package com.example.app;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.example.app.db.DatabaseHelper;
import com.example.app.model.Computer;

import java.util.List;

public class AddEditComputerActivity extends AppCompatActivity {

    private TextInputEditText etInventory, etName, etProcessor, etRam,
            etStorage, etMonitor, etOs, etNotes;
    private AutoCompleteTextView spinnerStatus, spinnerCategory;
    private CardView cardCharacteristics;
    private DatabaseHelper db;
    private long cabinetId = -1;
    private long computerId = -1;
    private boolean isEdit = false;

    private static final String[] STATUSES = { "Работает", "Неисправен", "На ремонте" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_computer);

        cabinetId = getIntent().getLongExtra("cabinet_id", -1);
        computerId = getIntent().getLongExtra("computer_id", -1);
        isEdit = computerId != -1;

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(isEdit ? "Редактировать технику" : "Добавить технику");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        db = new DatabaseHelper(this);

        etInventory = findViewById(R.id.etInventory);
        etName = findViewById(R.id.etName);
        etProcessor = findViewById(R.id.etProcessor);
        etRam = findViewById(R.id.etRam);
        etStorage = findViewById(R.id.etStorage);
        etMonitor = findViewById(R.id.etMonitor);
        etOs = findViewById(R.id.etOs);
        etNotes = findViewById(R.id.etNotes);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        cardCharacteristics = findViewById(R.id.cardCharacteristics);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnAddCategory = findViewById(R.id.btnAddCategory);

        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, STATUSES);
        spinnerStatus.setAdapter(statusAdapter);
        spinnerStatus.setText(STATUSES[0], false);

        loadCategories();

        btnAddCategory.setOnClickListener(v -> showAddCategoryDialog());

        if (isEdit) {
            etInventory.setText(getIntent().getStringExtra("computer_inventory"));
            etName.setText(getIntent().getStringExtra("computer_name"));
            etProcessor.setText(getIntent().getStringExtra("computer_processor"));
            etRam.setText(getIntent().getStringExtra("computer_ram"));
            etStorage.setText(getIntent().getStringExtra("computer_storage"));
            etMonitor.setText(getIntent().getStringExtra("computer_monitor"));
            etOs.setText(getIntent().getStringExtra("computer_os"));
            etNotes.setText(getIntent().getStringExtra("computer_notes"));
            String status = getIntent().getStringExtra("computer_status");
            if (status != null)
                spinnerStatus.setText(status, false);
            String category = getIntent().getStringExtra("computer_category");
            if (category != null)
                spinnerCategory.setText(category, false);
        }

        spinnerCategory.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateCharacteristicsVisibility(s.toString().trim());
            }
        });
        updateCharacteristicsVisibility(spinnerCategory.getText().toString().trim());

        btnSave.setOnClickListener(v -> saveComputer());
    }

    private void updateCharacteristicsVisibility(String category) {
        String catLower = category.toLowerCase();
        if (catLower.contains("компьютер") || catLower.contains("ноутбук") ||
                catLower.contains("моноблок") || catLower.contains("пк") || category.isEmpty()) {
            cardCharacteristics.setVisibility(View.VISIBLE);
        } else {
            cardCharacteristics.setVisibility(View.GONE);
        }
    }

    private void loadCategories() {
        List<String> cats = db.getAllCategories();
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_dropdown_item_1line, cats);
        spinnerCategory.setAdapter(catAdapter);
        if (spinnerCategory.getText().toString().isEmpty() && !cats.isEmpty()) {
            spinnerCategory.setText(cats.get(0), false);
        }
    }

    private void showAddCategoryDialog() {
        EditText etNewCat = new EditText(this);
        etNewCat.setHint("Название категории");
        etNewCat.setPadding(48, 24, 48, 24);

        new MaterialAlertDialogBuilder(this)
                .setTitle("Новая категория")
                .setView(etNewCat)
                .setPositiveButton("Добавить", (d, w) -> {
                    String name = etNewCat.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Введите название", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (db.categoryExists(name)) {
                        Toast.makeText(this, "Такая категория уже есть", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    db.addCategory(name);
                    loadCategories();
                    spinnerCategory.setText(name, false);
                    Toast.makeText(this, "Категория добавлена", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void saveComputer() {
        String name = etName.getText() != null ? etName.getText().toString().trim() : "";

        if (name.isEmpty()) {
            Toast.makeText(this, "Введите название / модель техники", Toast.LENGTH_SHORT).show();
            return;
        }

        String inventory = etInventory.getText() != null ? etInventory.getText().toString().trim() : "";
        String category = spinnerCategory.getText().toString().trim();
        String processor = etProcessor.getText() != null ? etProcessor.getText().toString().trim() : "";
        String ram = etRam.getText() != null ? etRam.getText().toString().trim() : "";
        String storage = etStorage.getText() != null ? etStorage.getText().toString().trim() : "";
        String monitor = etMonitor.getText() != null ? etMonitor.getText().toString().trim() : "";
        String os = etOs.getText() != null ? etOs.getText().toString().trim() : "";
        String status = spinnerStatus.getText().toString().trim();
        String notes = etNotes.getText() != null ? etNotes.getText().toString().trim() : "";

        if (status.isEmpty())
            status = STATUSES[0];
        if (category.isEmpty())
            category = "Прочее";

        if (isEdit) {
            Computer computer = new Computer(computerId, cabinetId, inventory, name,
                    category, processor, ram, storage, monitor, os, status, notes);
            db.updateComputer(computer);
            Toast.makeText(this, "Техника обновлена", Toast.LENGTH_SHORT).show();
        } else {
            Computer computer = new Computer(cabinetId, inventory, name,
                    category, processor, ram, storage, monitor, os, status, notes);
            db.addComputer(computer);
            Toast.makeText(this, "Техника добавлена", Toast.LENGTH_SHORT).show();
        }

        finish();
    }
}