package com.example.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.model.Cabinet;

import java.util.List;

public class CabinetAdapter extends RecyclerView.Adapter<CabinetAdapter.ViewHolder> {

    private final Context context;
    private final List<Cabinet> cabinets;
    private final boolean isTeacher;
    private final OnCabinetListener listener;

    public interface OnCabinetListener {
        void onCabinetClick(Cabinet cabinet);

        void onEditCabinet(Cabinet cabinet);

        void onDeleteCabinet(Cabinet cabinet);
    }

    public CabinetAdapter(Context context, List<Cabinet> cabinets, boolean isTeacher, OnCabinetListener listener) {
        this.context = context;
        this.cabinets = cabinets;
        this.isTeacher = isTeacher;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cabinet, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Cabinet cabinet = cabinets.get(position);
        holder.tvCabinetNumber.setText("Кабинет " + cabinet.getNumber());
        holder.tvDescription.setText(
                (cabinet.getDescription() != null && !cabinet.getDescription().isEmpty())
                        ? cabinet.getDescription()
                        : "Нет описания");
        holder.tvComputerCount.setText("Техники: " + cabinet.getComputerCount());

        holder.itemView.setOnClickListener(v -> listener.onCabinetClick(cabinet));
        if (isTeacher) {
            holder.btnEdit.setVisibility(View.GONE);
            holder.btnDelete.setVisibility(View.GONE);
        } else {
            holder.btnEdit.setVisibility(View.VISIBLE);
            holder.btnDelete.setVisibility(View.VISIBLE);
            holder.btnEdit.setOnClickListener(v -> listener.onEditCabinet(cabinet));
            holder.btnDelete.setOnClickListener(v -> listener.onDeleteCabinet(cabinet));
        }
    }

    @Override
    public int getItemCount() {
        return cabinets.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvCabinetNumber, tvDescription, tvComputerCount;
        ImageButton btnEdit, btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvCabinetNumber = itemView.findViewById(R.id.tvCabinetNumber);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvComputerCount = itemView.findViewById(R.id.tvComputerCount);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}