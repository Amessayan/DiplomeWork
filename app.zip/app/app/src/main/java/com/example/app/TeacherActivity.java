package com.example.app;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.example.app.adapter.TeacherComputerAdapter;
import com.example.app.db.DatabaseHelper;
import com.example.app.model.Computer;

import java.util.List;

public class TeacherActivity extends AppCompatActivity implements TeacherComputerAdapter.OnReportListener {

    private DatabaseHelper db;
    private TeacherComputerAdapter adapter;
    private List<Computer> computerList;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Вся техника");
        }

        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerTeacher);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadComputers();
    }

    private void loadComputers() {
        computerList = db.getAllComputers();
        adapter = new TeacherComputerAdapter(this, computerList, db, this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onReport(Computer computer) {
        EditText etText = new EditText(this);
        etText.setHint("Опишите проблему");
        etText.setPadding(48, 24, 48, 24);
        etText.setMinLines(3);
        etText.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        etText.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);

        new MaterialAlertDialogBuilder(this)
                .setTitle("Сообщить о проблеме")
                .setMessage(computer.getCategory() + ": " + computer.getName())
                .setView(etText)
                .setPositiveButton("Отправить", (d, w) -> {
                    String text = etText.getText().toString().trim();
                    if (text.isEmpty()) {
                        Toast.makeText(this, "Введите описание проблемы", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String cabNumber = db.getCabinetNumber(computer.getCabinetId());
                    db.addMessage(computer.getId(), computer.getName(), cabNumber,
                            computer.getCategory(), text);
                    Toast.makeText(this, "Сообщение отправлено лаборанту", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("Выход")
                    .setMessage("Вы уверены, что хотите выйти?")
                    .setPositiveButton("Выйти", (d, w) -> {
                        android.content.Intent intent = new android.content.Intent(this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadComputers();
    }
}
