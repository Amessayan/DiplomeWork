package com.example.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.db.DatabaseHelper;
import com.example.app.model.Computer;

import java.util.List;

public class TeacherComputerAdapter extends RecyclerView.Adapter<TeacherComputerAdapter.ViewHolder> {

    private final Context context;
    private final List<Computer> computers;
    private final DatabaseHelper db;
    private final OnReportListener listener;

    public interface OnReportListener {
        void onReport(Computer computer);
    }

    public TeacherComputerAdapter(Context context, List<Computer> computers,
            DatabaseHelper db, OnReportListener listener) {
        this.context = context;
        this.computers = computers;
        this.db = db;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_teacher_computer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Computer c = computers.get(position);
        holder.tvName.setText(c.getName());
        holder.tvCategory.setText(str(c.getCategory()));
        holder.tvCabinet.setText("Кабинет: " + db.getCabinetNumber(c.getCabinetId()));
        holder.tvInventory.setText("Инв. №: " + str(c.getInventoryNumber()));
        holder.tvStatus.setText(c.getStatus());

        switch (c.getStatus()) {
            case "Работает":
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_working);
                break;
            case "Неисправен":
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_broken);
                break;
            default:
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_repair);
                break;
        }

        holder.btnReport.setOnClickListener(v -> listener.onReport(c));
    }

    private String str(String val) {
        return (val != null && !val.isEmpty()) ? val : "—";
    }

    @Override
    public int getItemCount() {
        return computers.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCategory, tvCabinet, tvInventory, tvStatus;
        Button btnReport;

        ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvComputerName);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvCabinet = itemView.findViewById(R.id.tvCabinet);
            tvInventory = itemView.findViewById(R.id.tvInventory);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            btnReport = itemView.findViewById(R.id.btnReport);
        }
    }
}
