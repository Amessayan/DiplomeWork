package com.example.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.model.Computer;

import java.util.List;

public class ComputerAdapter extends RecyclerView.Adapter<ComputerAdapter.ViewHolder> {

    private final Context context;
    private final List<Computer> computers;
    private final OnComputerListener listener;

    public interface OnComputerListener {
        void onEditComputer(Computer computer);

        void onDeleteComputer(Computer computer);
    }

    public ComputerAdapter(Context context, List<Computer> computers, OnComputerListener listener) {
        this.context = context;
        this.computers = computers;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_computer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Computer c = computers.get(position);
        holder.tvName.setText(c.getName());
        holder.tvCategory.setText(str(c.getCategory()));
        holder.tvInventory.setText("Инв. №: " + str(c.getInventoryNumber()));
        holder.tvProcessor.setText("CPU: " + str(c.getProcessor()));
        holder.tvRam.setText("ОЗУ: " + str(c.getRam()));
        holder.tvStorage.setText("Накоп.: " + str(c.getStorage()));
        holder.tvMonitor.setText("Монитор: " + str(c.getMonitor()));
        holder.tvOs.setText("ОС: " + str(c.getOs()));
        holder.tvStatus.setText(c.getStatus());

        switch (c.getStatus()) {
            case "Работает":
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_working);
                break;
            case "Неисправен":
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_broken);
                break;
            default:
                holder.tvStatus.setBackgroundResource(R.drawable.bg_status_repair);
                break;
        }

        boolean isPC = isComputer(c.getCategory());
        holder.layoutSpecs.setVisibility(isPC ? View.VISIBLE : View.GONE);

        holder.btnEdit.setOnClickListener(v -> listener.onEditComputer(c));
        holder.btnDelete.setOnClickListener(v -> listener.onDeleteComputer(c));
    }

    private String str(String val) {
        return (val != null && !val.isEmpty()) ? val : "—";
    }

    private boolean isComputer(String category) {
        if (category == null)
            return false;
        String catLower = category.toLowerCase();
        return catLower.contains("компьютер") || catLower.contains("ноутбук") ||
                catLower.contains("моноблок") || catLower.contains("пк");
    }

    @Override
    public int getItemCount() {
        return computers.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCategory, tvInventory, tvProcessor, tvRam, tvStorage, tvMonitor, tvOs, tvStatus;
        View layoutSpecs;
        ImageButton btnEdit, btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvComputerName);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvInventory = itemView.findViewById(R.id.tvInventory);
            tvProcessor = itemView.findViewById(R.id.tvProcessor);
            tvRam = itemView.findViewById(R.id.tvRam);
            tvStorage = itemView.findViewById(R.id.tvStorage);
            tvMonitor = itemView.findViewById(R.id.tvMonitor);
            tvOs = itemView.findViewById(R.id.tvOs);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            layoutSpecs = itemView.findViewById(R.id.layoutSpecs);
            btnEdit = itemView.findViewById(R.id.btnEditComputer);
            btnDelete = itemView.findViewById(R.id.btnDeleteComputer);
        }
    }
}