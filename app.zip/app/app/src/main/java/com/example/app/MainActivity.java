package com.example.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.example.app.adapter.CabinetAdapter;
import com.example.app.db.DatabaseHelper;
import com.example.app.model.Cabinet;

import java.util.List;

public class MainActivity extends AppCompatActivity implements CabinetAdapter.OnCabinetListener {

    private DatabaseHelper db;
    private CabinetAdapter adapter;
    private List<Cabinet> cabinetList;
    private RecyclerView recyclerView;
    private View tvEmpty;
    private TextView tvUnreadBadge;
    private boolean isTeacher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        db = new DatabaseHelper(this);

        android.content.SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        isTeacher = "teacher".equals(prefs.getString("ROLE", "lab"));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(isTeacher ? "Кабинеты (Учитель)" : "Кабинеты (Лаборант)");
        }

        recyclerView = findViewById(R.id.recyclerCabinets);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvUnreadBadge = findViewById(R.id.tvUnreadBadge);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FloatingActionButton fab = findViewById(R.id.fabAddCabinet);
        View btnMessages = findViewById(R.id.btnMessages);

        if (isTeacher) {
            fab.setVisibility(View.GONE);
            btnMessages.setVisibility(View.GONE);
            tvUnreadBadge.setVisibility(View.GONE);
        } else {
            fab.setOnClickListener(v -> showCabinetDialog(null));
            btnMessages.setOnClickListener(v -> {
                startActivity(new Intent(this, MessagesActivity.class));
            });
        }

        loadCabinets();
    }

    private void loadCabinets() {
        cabinetList = db.getAllCabinets();
        adapter = new CabinetAdapter(this, cabinetList, isTeacher, this);
        recyclerView.setAdapter(adapter);
        tvEmpty.setVisibility(cabinetList.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(cabinetList.isEmpty() ? View.GONE : View.VISIBLE);

        if (!isTeacher) {
            int unread = db.getUnreadCount();
            if (unread > 0) {
                tvUnreadBadge.setVisibility(View.VISIBLE);
                tvUnreadBadge.setText(String.valueOf(unread));
            } else {
                tvUnreadBadge.setVisibility(View.GONE);
            }
        }
    }

    private void showCabinetDialog(Cabinet existing) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_cabinet, null);
        TextInputEditText etNumber = dialogView.findViewById(R.id.etCabinetNumber);
        TextInputEditText etDesc = dialogView.findViewById(R.id.etCabinetDescription);

        if (existing != null) {
            etNumber.setText(existing.getNumber());
            etDesc.setText(existing.getDescription());
        }

        new MaterialAlertDialogBuilder(this)
                .setTitle(existing == null ? "Добавить кабинет" : "Редактировать кабинет")
                .setView(dialogView)
                .setPositiveButton("Сохранить", (dialog, which) -> {
                    String number = etNumber.getText() != null ? etNumber.getText().toString().trim() : "";
                    String desc = etDesc.getText() != null ? etDesc.getText().toString().trim() : "";

                    if (number.isEmpty()) {
                        Toast.makeText(this, "Введите номер кабинета", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (existing == null) {
                        Cabinet cabinet = new Cabinet(number, desc);
                        db.addCabinet(cabinet);
                        Toast.makeText(this, "Кабинет добавлен", Toast.LENGTH_SHORT).show();
                    } else {
                        existing.setNumber(number);
                        existing.setDescription(desc);
                        db.updateCabinet(existing);
                        Toast.makeText(this, "Кабинет обновлён", Toast.LENGTH_SHORT).show();
                    }
                    loadCabinets();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    public void onCabinetClick(Cabinet cabinet) {
        Intent intent = new Intent(this, CabinetDetailActivity.class);
        intent.putExtra("cabinet_id", cabinet.getId());
        intent.putExtra("cabinet_number", cabinet.getNumber());
        startActivity(intent);
    }

    @Override
    public void onEditCabinet(Cabinet cabinet) {
        showCabinetDialog(cabinet);
    }

    @Override
    public void onDeleteCabinet(Cabinet cabinet) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Удалить кабинет?")
                .setMessage("Кабинет «" + cabinet.getNumber() + "» и все его компьютеры будут удалены.")
                .setPositiveButton("Удалить", (dialog, which) -> {
                    db.deleteCabinet(cabinet.getId());
                    loadCabinets();
                    Toast.makeText(this, "Кабинет удалён", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("Выход")
                    .setMessage("Вы уверены, что хотите выйти?")
                    .setPositiveButton("Выйти", (d, w) -> {
                        startActivity(new Intent(this, LoginActivity.class));
                        finish();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCabinets();
    }
}