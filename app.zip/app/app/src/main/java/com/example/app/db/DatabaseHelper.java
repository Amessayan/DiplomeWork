package com.example.app.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.app.model.Cabinet;
import com.example.app.model.Computer;
import com.example.app.model.Message;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "tech_accounting.db";
    private static final int DB_VERSION = 2;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_CABINETS = "cabinets";
    private static final String TABLE_COMPUTERS = "computers";
    private static final String TABLE_CATEGORIES = "categories";
    private static final String TABLE_MESSAGES = "messages";

    private static final String COL_USER_ID = "id";
    private static final String COL_USER_LOGIN = "login";
    private static final String COL_USER_PASSWORD = "password";
    private static final String COL_USER_ROLE = "role";

    private static final String COL_CABINET_ID = "id";
    private static final String COL_CABINET_NUMBER = "number";
    private static final String COL_CABINET_DESCRIPTION = "description";

    private static final String COL_CAT_ID = "id";
    private static final String COL_CAT_NAME = "name";
    private static final String COL_CAT_BUILTIN = "is_builtin";

    private static final String COL_COMP_ID = "id";
    private static final String COL_COMP_CABINET_ID = "cabinet_id";
    private static final String COL_COMP_INVENTORY = "inventory_number";
    private static final String COL_COMP_NAME = "name";
    private static final String COL_COMP_CATEGORY = "category";
    private static final String COL_COMP_PROCESSOR = "processor";
    private static final String COL_COMP_RAM = "ram";
    private static final String COL_COMP_STORAGE = "storage";
    private static final String COL_COMP_MONITOR = "monitor";
    private static final String COL_COMP_OS = "os";
    private static final String COL_COMP_STATUS = "status";
    private static final String COL_COMP_NOTES = "notes";

    private static final String COL_MSG_ID = "id";
    private static final String COL_MSG_COMP_ID = "computer_id";
    private static final String COL_MSG_COMP_NAME = "computer_name";
    private static final String COL_MSG_CABINET = "cabinet_number";
    private static final String COL_MSG_CATEGORY = "category";
    private static final String COL_MSG_TEXT = "text";
    private static final String COL_MSG_TIME = "timestamp";
    private static final String COL_MSG_READ = "is_read";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USER_LOGIN + " TEXT NOT NULL UNIQUE, " +
                COL_USER_PASSWORD + " TEXT NOT NULL, " +
                COL_USER_ROLE + " TEXT NOT NULL DEFAULT 'laborant')");

        db.execSQL("CREATE TABLE " + TABLE_CABINETS + " (" +
                COL_CABINET_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CABINET_NUMBER + " TEXT NOT NULL, " +
                COL_CABINET_DESCRIPTION + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_CATEGORIES + " (" +
                COL_CAT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CAT_NAME + " TEXT NOT NULL UNIQUE, " +
                COL_CAT_BUILTIN + " INTEGER NOT NULL DEFAULT 0)");

        db.execSQL("CREATE TABLE " + TABLE_COMPUTERS + " (" +
                COL_COMP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_COMP_CABINET_ID + " INTEGER NOT NULL, " +
                COL_COMP_INVENTORY + " TEXT, " +
                COL_COMP_NAME + " TEXT NOT NULL, " +
                COL_COMP_CATEGORY + " TEXT DEFAULT 'Прочее', " +
                COL_COMP_PROCESSOR + " TEXT, " +
                COL_COMP_RAM + " TEXT, " +
                COL_COMP_STORAGE + " TEXT, " +
                COL_COMP_MONITOR + " TEXT, " +
                COL_COMP_OS + " TEXT, " +
                COL_COMP_STATUS + " TEXT DEFAULT 'Работает', " +
                COL_COMP_NOTES + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_MESSAGES + " (" +
                COL_MSG_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_MSG_COMP_ID + " INTEGER, " +
                COL_MSG_COMP_NAME + " TEXT, " +
                COL_MSG_CABINET + " TEXT, " +
                COL_MSG_CATEGORY + " TEXT, " +
                COL_MSG_TEXT + " TEXT NOT NULL, " +
                COL_MSG_TIME + " TEXT, " +
                COL_MSG_READ + " INTEGER NOT NULL DEFAULT 0)");

        ContentValues laborant = new ContentValues();
        laborant.put(COL_USER_LOGIN, "laborant");
        laborant.put(COL_USER_PASSWORD, "laborant");
        laborant.put(COL_USER_ROLE, "laborant");
        db.insert(TABLE_USERS, null, laborant);

        ContentValues teacher = new ContentValues();
        teacher.put(COL_USER_LOGIN, "teacher");
        teacher.put(COL_USER_PASSWORD, "teacher");
        teacher.put(COL_USER_ROLE, "teacher");
        db.insert(TABLE_USERS, null, teacher);

        String[] builtins = { "Компьютер", "Принтер", "Проектор", "Прочее" };
        for (String cat : builtins) {
            ContentValues cv = new ContentValues();
            cv.put(COL_CAT_NAME, cat);
            cv.put(COL_CAT_BUILTIN, 1);
            db.insert(TABLE_CATEGORIES, null, cv);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MESSAGES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMPUTERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CABINETS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public boolean checkUser(String login, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null,
                COL_USER_LOGIN + "=? AND " + COL_USER_PASSWORD + "=?",
                new String[] { login, password }, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public String getUserRole(String login) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[] { COL_USER_ROLE },
                COL_USER_LOGIN + "=?", new String[] { login }, null, null, null);
        String role = "laborant";
        if (cursor.moveToFirst()) {
            role = cursor.getString(0);
        }
        cursor.close();
        return role;
    }

    public List<String> getAllCategories() {
        List<String> cats = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COL_CAT_NAME + " FROM " + TABLE_CATEGORIES +
                " ORDER BY " + COL_CAT_BUILTIN + " DESC, " + COL_CAT_NAME + " ASC", null);
        if (cursor.moveToFirst()) {
            do {
                cats.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return cats;
    }

    public boolean categoryExists(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_CATEGORIES, null,
                COL_CAT_NAME + "=?", new String[] { name }, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public void addCategory(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_CAT_NAME, name);
        cv.put(COL_CAT_BUILTIN, 0);
        db.insert(TABLE_CATEGORIES, null, cv);
        db.close();
    }

    public long addCabinet(Cabinet cabinet) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_CABINET_NUMBER, cabinet.getNumber());
        values.put(COL_CABINET_DESCRIPTION, cabinet.getDescription());
        long id = db.insert(TABLE_CABINETS, null, values);
        db.close();
        return id;
    }

    public List<Cabinet> getAllCabinets() {
        List<Cabinet> cabinets = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT c.id, c.number, c.description, COUNT(comp.id) AS computer_count " +
                        "FROM cabinets c LEFT JOIN computers comp ON comp.cabinet_id = c.id " +
                        "GROUP BY c.id ORDER BY CAST(c.number AS INTEGER) ASC",
                null);
        if (cursor.moveToFirst()) {
            do {
                Cabinet cab = new Cabinet(
                        cursor.getLong(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getInt(3));
                cabinets.add(cab);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return cabinets;
    }

    public int updateCabinet(Cabinet cabinet) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_CABINET_NUMBER, cabinet.getNumber());
        values.put(COL_CABINET_DESCRIPTION, cabinet.getDescription());
        int rows = db.update(TABLE_CABINETS, values, COL_CABINET_ID + "=?",
                new String[] { String.valueOf(cabinet.getId()) });
        db.close();
        return rows;
    }

    public void deleteCabinet(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_COMPUTERS, COL_COMP_CABINET_ID + "=?", new String[] { String.valueOf(id) });
        db.delete(TABLE_CABINETS, COL_CABINET_ID + "=?", new String[] { String.valueOf(id) });
        db.close();
    }

    public long addComputer(Computer computer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_COMP_CABINET_ID, computer.getCabinetId());
        values.put(COL_COMP_INVENTORY, computer.getInventoryNumber());
        values.put(COL_COMP_NAME, computer.getName());
        values.put(COL_COMP_CATEGORY, computer.getCategory());
        values.put(COL_COMP_PROCESSOR, computer.getProcessor());
        values.put(COL_COMP_RAM, computer.getRam());
        values.put(COL_COMP_STORAGE, computer.getStorage());
        values.put(COL_COMP_MONITOR, computer.getMonitor());
        values.put(COL_COMP_OS, computer.getOs());
        values.put(COL_COMP_STATUS, computer.getStatus());
        values.put(COL_COMP_NOTES, computer.getNotes());
        long id = db.insert(TABLE_COMPUTERS, null, values);
        db.close();
        return id;
    }

    public List<Computer> getComputersByCabinet(long cabinetId) {
        List<Computer> computers = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_COMPUTERS, null,
                COL_COMP_CABINET_ID + "=?", new String[] { String.valueOf(cabinetId) },
                null, null, COL_COMP_ID + " ASC");
        if (cursor.moveToFirst()) {
            do {
                computers.add(cursorToComputer(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return computers;
    }

    public List<Computer> getAllComputers() {
        List<Computer> computers = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT comp.*, cab.number as cab_num FROM " + TABLE_COMPUTERS +
                        " comp LEFT JOIN " + TABLE_CABINETS + " cab ON comp.cabinet_id = cab.id " +
                        "ORDER BY cab.number ASC, comp.name ASC",
                null);
        if (cursor.moveToFirst()) {
            do {
                computers.add(cursorToComputer(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return computers;
    }

    public String getCabinetNumber(long cabinetId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_CABINETS, new String[] { COL_CABINET_NUMBER },
                COL_CABINET_ID + "=?", new String[] { String.valueOf(cabinetId) }, null, null, null);
        String number = "";
        if (cursor.moveToFirst())
            number = cursor.getString(0);
        cursor.close();
        return number;
    }

    private Computer cursorToComputer(Cursor cursor) {
        return new Computer(
                cursor.getLong(cursor.getColumnIndexOrThrow(COL_COMP_ID)),
                cursor.getLong(cursor.getColumnIndexOrThrow(COL_COMP_CABINET_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_INVENTORY)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_NAME)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_CATEGORY)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_PROCESSOR)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_RAM)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_STORAGE)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_MONITOR)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_OS)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_STATUS)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_COMP_NOTES)));
    }

    public int updateComputer(Computer computer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_COMP_INVENTORY, computer.getInventoryNumber());
        values.put(COL_COMP_NAME, computer.getName());
        values.put(COL_COMP_CATEGORY, computer.getCategory());
        values.put(COL_COMP_PROCESSOR, computer.getProcessor());
        values.put(COL_COMP_RAM, computer.getRam());
        values.put(COL_COMP_STORAGE, computer.getStorage());
        values.put(COL_COMP_MONITOR, computer.getMonitor());
        values.put(COL_COMP_OS, computer.getOs());
        values.put(COL_COMP_STATUS, computer.getStatus());
        values.put(COL_COMP_NOTES, computer.getNotes());
        int rows = db.update(TABLE_COMPUTERS, values, COL_COMP_ID + "=?",
                new String[] { String.valueOf(computer.getId()) });
        db.close();
        return rows;
    }

    public void deleteComputer(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_COMPUTERS, COL_COMP_ID + "=?", new String[] { String.valueOf(id) });
        db.close();
    }

    public void addMessage(long computerId, String computerName, String cabinetNumber,
            String category, String text) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_MSG_COMP_ID, computerId);
        cv.put(COL_MSG_COMP_NAME, computerName);
        cv.put(COL_MSG_CABINET, cabinetNumber);
        cv.put(COL_MSG_CATEGORY, category);
        cv.put(COL_MSG_TEXT, text);
        cv.put(COL_MSG_TIME, new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(new Date()));
        cv.put(COL_MSG_READ, 0);
        db.insert(TABLE_MESSAGES, null, cv);
        db.close();
    }

    public List<Message> getAllMessages() {
        List<Message> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_MESSAGES +
                " ORDER BY " + COL_MSG_READ + " ASC, " + COL_MSG_ID + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                list.add(new Message(
                        cursor.getLong(cursor.getColumnIndexOrThrow(COL_MSG_ID)),
                        cursor.getLong(cursor.getColumnIndexOrThrow(COL_MSG_COMP_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_COMP_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_CABINET)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_CATEGORY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_TEXT)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_TIME)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_READ)) == 1));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public int getUnreadCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_MESSAGES +
                " WHERE " + COL_MSG_READ + "=0", null);
        int count = 0;
        if (cursor.moveToFirst())
            count = cursor.getInt(0);
        cursor.close();
        return count;
    }

    public void markAllRead() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_MSG_READ, 1);
        db.update(TABLE_MESSAGES, cv, COL_MSG_READ + "=0", null);
        db.close();
    }
}