package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.example.app.adapter.ComputerAdapter;
import com.example.app.adapter.TeacherComputerAdapter;
import com.example.app.db.DatabaseHelper;
import com.example.app.model.Computer;

import java.util.List;
import android.widget.EditText;

public class CabinetDetailActivity extends AppCompatActivity
        implements ComputerAdapter.OnComputerListener, TeacherComputerAdapter.OnReportListener {

    private DatabaseHelper db;
    private ComputerAdapter adapter;
    private List<Computer> computerList;
    private RecyclerView recyclerView;
    private View tvEmpty;
    private long cabinetId;
    private String cabinetNumber;
    private boolean isTeacher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cabinet_detail);

        cabinetId = getIntent().getLongExtra("cabinet_id", -1);
        cabinetNumber = getIntent().getStringExtra("cabinet_number");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Кабинет " + cabinetNumber);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerComputers);
        tvEmpty = findViewById(R.id.tvEmpty);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        android.content.SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        isTeacher = "teacher".equals(prefs.getString("ROLE", "lab"));

        FloatingActionButton fab = findViewById(R.id.fabAddComputer);
        if (isTeacher) {
            fab.setVisibility(View.GONE);
        } else {
            fab.setOnClickListener(v -> {
                Intent intent = new Intent(this, AddEditComputerActivity.class);
                intent.putExtra("cabinet_id", cabinetId);
                startActivity(intent);
            });
        }

        loadComputers();
    }

    private void loadComputers() {
        computerList = db.getComputersByCabinet(cabinetId);
        if (isTeacher) {
            TeacherComputerAdapter tAdapter = new TeacherComputerAdapter(this, computerList, db, this);
            recyclerView.setAdapter(tAdapter);
        } else {
            adapter = new ComputerAdapter(this, computerList, this);
            recyclerView.setAdapter(adapter);
        }
        tvEmpty.setVisibility(computerList.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(computerList.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onEditComputer(Computer computer) {
        Intent intent = new Intent(this, AddEditComputerActivity.class);
        intent.putExtra("cabinet_id", cabinetId);
        intent.putExtra("computer_id", computer.getId());
        intent.putExtra("computer_inventory", computer.getInventoryNumber());
        intent.putExtra("computer_name", computer.getName());
        intent.putExtra("computer_category", computer.getCategory());
        intent.putExtra("computer_processor", computer.getProcessor());
        intent.putExtra("computer_ram", computer.getRam());
        intent.putExtra("computer_storage", computer.getStorage());
        intent.putExtra("computer_monitor", computer.getMonitor());
        intent.putExtra("computer_os", computer.getOs());
        intent.putExtra("computer_status", computer.getStatus());
        intent.putExtra("computer_notes", computer.getNotes());
        startActivity(intent);
    }

    @Override
    public void onDeleteComputer(Computer computer) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Удалить технику?")
                .setMessage("«" + computer.getName() + "» будет удалена безвозвратно.")
                .setPositiveButton("Удалить", (dialog, which) -> {
                    db.deleteComputer(computer.getId());
                    loadComputers();
                    Toast.makeText(this, "Техника удалена", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    public void onReport(Computer computer) {
        EditText etText = new EditText(this);
        etText.setHint("Опишите проблему");
        etText.setPadding(48, 24, 48, 24);
        etText.setMinLines(3);
        etText.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        etText.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);

        new MaterialAlertDialogBuilder(this)
                .setTitle("Сообщить о проблеме")
                .setMessage(computer.getCategory() + ": " + computer.getName())
                .setView(etText)
                .setPositiveButton("Отправить", (d, w) -> {
                    String text = etText.getText().toString().trim();
                    if (text.isEmpty()) {
                        Toast.makeText(this, "Введите описание проблемы", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String cabNumber = db.getCabinetNumber(computer.getCabinetId());
                    db.addMessage(computer.getId(), computer.getName(), cabNumber,
                            computer.getCategory(), text);
                    Toast.makeText(this, "Сообщение отправлено лаборанту", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadComputers();
    }
}