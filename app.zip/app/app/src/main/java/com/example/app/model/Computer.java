package com.example.app.model;

public class Computer {
    private long id;
    private long cabinetId;
    private String inventoryNumber;
    private String name;
    private String category;
    private String processor;
    private String ram;
    private String storage;
    private String monitor;
    private String os;
    private String status;
    private String notes;

    public Computer(long id, long cabinetId, String inventoryNumber, String name, String category,
            String processor, String ram, String storage, String monitor,
            String os, String status, String notes) {
        this.id = id;
        this.cabinetId = cabinetId;
        this.inventoryNumber = inventoryNumber;
        this.name = name;
        this.category = category;
        this.processor = processor;
        this.ram = ram;
        this.storage = storage;
        this.monitor = monitor;
        this.os = os;
        this.status = status;
        this.notes = notes;
    }

    public Computer(long cabinetId, String inventoryNumber, String name, String category,
            String processor, String ram, String storage, String monitor,
            String os, String status, String notes) {
        this.cabinetId = cabinetId;
        this.inventoryNumber = inventoryNumber;
        this.name = name;
        this.category = category;
        this.processor = processor;
        this.ram = ram;
        this.storage = storage;
        this.monitor = monitor;
        this.os = os;
        this.status = status;
        this.notes = notes;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getCabinetId() {
        return cabinetId;
    }

    public void setCabinetId(long cabinetId) {
        this.cabinetId = cabinetId;
    }

    public String getInventoryNumber() {
        return inventoryNumber;
    }

    public void setInventoryNumber(String v) {
        this.inventoryNumber = v;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String v) {
        this.processor = v;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String v) {
        this.storage = v;
    }

    public String getMonitor() {
        return monitor;
    }

    public void setMonitor(String v) {
        this.monitor = v;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}