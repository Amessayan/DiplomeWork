package com.example.app.model;

public class Message {
    private long id;
    private long computerId;
    private String computerName;
    private String cabinetNumber;
    private String category;
    private String text;
    private String timestamp;
    private boolean isRead;

    public Message(long id, long computerId, String computerName, String cabinetNumber,
            String category, String text, String timestamp, boolean isRead) {
        this.id = id;
        this.computerId = computerId;
        this.computerName = computerName;
        this.cabinetNumber = cabinetNumber;
        this.category = category;
        this.text = text;
        this.timestamp = timestamp;
        this.isRead = isRead;
    }

    public long getId() {
        return id;
    }

    public long getComputerId() {
        return computerId;
    }

    public String getComputerName() {
        return computerName;
    }

    public String getCabinetNumber() {
        return cabinetNumber;
    }

    public String getCategory() {
        return category;
    }

    public String getText() {
        return text;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public boolean isRead() {
        return isRead;
    }

    public void setRead(boolean read) {
        isRead = read;
    }
}
