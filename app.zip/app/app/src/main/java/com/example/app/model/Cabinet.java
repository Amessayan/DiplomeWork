package com.example.app.model;

public class Cabinet {
    private long id;
    private String number;
    private String description;
    private int computerCount;

    public Cabinet(long id, String number, String description, int computerCount) {
        this.id = id;
        this.number = number;
        this.description = description;
        this.computerCount = computerCount;
    }

    public Cabinet(String number, String description) {
        this.number = number;
        this.description = description;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getComputerCount() { return computerCount; }
    public void setComputerCount(int computerCount) { this.computerCount = computerCount; }
}