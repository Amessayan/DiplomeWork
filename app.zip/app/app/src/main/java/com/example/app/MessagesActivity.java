package com.example.app;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.adapter.MessageAdapter;
import com.example.app.db.DatabaseHelper;
import com.example.app.model.Message;

import java.util.List;

public class MessagesActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private MessageAdapter adapter;
    private List<Message> messageList;
    private RecyclerView recyclerView;
    private View tvEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messages);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Сообщения от преподавателя");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerMessages);
        tvEmpty = findViewById(R.id.tvEmpty);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db.markAllRead();
        loadMessages();
    }

    private void loadMessages() {
        messageList = db.getAllMessages();
        adapter = new MessageAdapter(this, messageList);
        recyclerView.setAdapter(adapter);
        tvEmpty.setVisibility(messageList.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(messageList.isEmpty() ? View.GONE : View.VISIBLE);
    }
}
