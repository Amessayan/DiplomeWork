package com.example.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.model.Message;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {

    private final Context context;
    private final List<Message> messages;

    public MessageAdapter(Context context, List<Message> messages) {
        this.context = context;
        this.messages = messages;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_message, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Message m = messages.get(position);
        holder.tvDevice.setText(m.getCategory() + ": " + m.getComputerName());
        holder.tvCabinet.setText("Кабинет " + m.getCabinetNumber());
        holder.tvText.setText(m.getText());
        holder.tvTime.setText(m.getTimestamp());

        if (!m.isRead()) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.msg_unread_bg));
        } else {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent));
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDevice, tvCabinet, tvText, tvTime;

        ViewHolder(View itemView) {
            super(itemView);
            tvDevice = itemView.findViewById(R.id.tvDevice);
            tvCabinet = itemView.findViewById(R.id.tvCabinet);
            tvText = itemView.findViewById(R.id.tvText);
            tvTime = itemView.findViewById(R.id.tvTime);
        }
    }
}
